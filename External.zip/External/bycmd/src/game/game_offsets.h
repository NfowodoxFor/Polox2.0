#pragma once

#include <cstdint>

// ============================================================================
//  Oxide Survival Island — IL2CPP offsets (derived from dump.cs on desktop)
//  Module: libil2cpp.so  (~209 MB). All *_RVA values are image-relative
//  (lib + RVA). Offsets re-verified against Dump14 (updated build).
// ============================================================================

namespace game_offsets {

// ---- Player list ----------------------------------------------------------
// PlayerManager : NetworkBehaviour  (TypeInfo = Il2CppClass RVA)
// Real RVA for the current build: 0xD18B560 (user-confirmed).
// This is a TypeInfo *slot*: the qword stored there points at the Il2CppClass
// (each following type sits +8). So class = *(u64*)(lib + 0xD18B560).
inline constexpr std::uint64_t PLAYER_MANAGER_TYPEINFO_RVA = 0xD18B560;

// Fallback class discovery: scan for a qword == lib+PLAYER_MANAGER_METHOD_RVA
// (MethodInfo), then read the Il2CppClass from MethodInfo+{0x18,0x20,0x28,0x30}.
// OLD value was 0x611ab01 (PlayerManager.YNj). TODO: актуальное RVA метода
// текущей версии из dump.cs. 0 = fallback disabled.
inline constexpr std::uint64_t PLAYER_MANAGER_METHOD_RVA = 0;

// PlayerManager static fields (offsets WITHIN the static-fields struct):
//   sleepingPlayerList  (PQ<PlayerManager>) @ 0x0
//   activePlayerList    (PQ<PlayerManager>) @ 0x8
//   clientPlayerList    (List<PlayerManager>, readonly) @ 0x10   <-- use this
//   serverName (string) @ 0x18
inline constexpr std::uint64_t PLAYER_MANAGER_STATIC_FIELDS_LIST     = 0x10; // clientPlayerList
inline constexpr std::uint64_t PLAYER_MANAGER_STATIC_FIELDS_ACTIVE   = 0x8;  // activePlayerList (PQ, fallback)
inline constexpr std::uint64_t PLAYER_MANAGER_STATIC_FIELDS_SLEEPING = 0x0;   // sleepingPlayerList (PQ, fallback)

// PlayerManager instance fields (Dump14, TypeDefIndex 9016):
//   public Transform worldCameraRoot;   // 0x68  (main camera root transform)
//   public Vector3  lastTickPosition;   // 0x1c8 (world position, network tick)
//   NOTE: old All\dump had this at 0x1D0 — the game updated and the field
//   shifted; Dump14 is the authoritative current build.
inline constexpr std::uint64_t PLAYER_WORLDCAMERA_ROOT = 0x68;
inline constexpr std::uint64_t PLAYER_POSITION          = 0x1E0; // real world position (Vector3) — verified live

inline constexpr bool          PLAYER_LIST_FIRST_IS_LOCAL = true; // players[0] = local

// Health is read via the vitals chain (player.hpp), not a raw field. Dump14 has
// NO plain `health` float on PlayerManager (0x380 is a SyncVar delegate). Kept
// only as documentation of the old (wrong) assumption.
inline constexpr std::uint64_t PLAYER_HEALTH_OFFSET = 0; // unused

// ---- Camera / UniversalCameraData (URP) -----------------------------------
// Camera : Behaviour  (TypeInfo = Il2CppClass RVA)
// Slot RVA confirmed by user from script.json: "UnityEngine.Camera_TypeInfo"
// Address 219692344 = 0xD183D38 (same scheme as PLAYER_MANAGER 0xD18B560: the
// qword at lib+slot IS the Il2CppClass*). Old 0xcefcaa8 produced an EMPTY slot
// (raw=0) so name-scans wrongly picked a fake Camera. Camera.get_main() method
// RVA keeps for reference only (needs a remote call; not used).
inline constexpr std::uint64_t CAMERA_TYPEINFO_RVA = 0xD183D38;
// Camera.get_main() method RVA (returns main Camera*). NOT a pointer — needs a
// remote call to invoke; we currently resolve the Camera via its Il2CppClass
// static fields. RVA verified in dump.cs (line 1432963).
inline constexpr std::uint64_t CAMERA_GET_MAIN_METHOD_RVA    = 0xBF537B2;
inline constexpr std::uint64_t CAMERA_GET_CURRENT_METHOD_RVA = 0xBF5382B; // Camera.get_current()
inline constexpr std::uint64_t CAMERA_WORLD_TO_SCREEN_RVA    = 0xBF52D41; // Camera.WorldToScreenPoint(Vector3)

// UniversalCameraData : ContextItem  (the live view/proj matrices live here)
//   private Matrix4x4 m_ViewMatrix;        // 0x10
//   private Matrix4x4 m_ProjectionMatrix;   // 0x50
//   public Camera camera;                   // 0xd0  (back-reference -> Camera)
//   internal int pixelWidth;                // 0x158
//   internal int pixelHeight;               // 0x15c
//   public Vector3 worldSpaceCameraPos;     // 0x1dc
inline constexpr std::uint64_t UCD_VIEW_MATRIX      = 0x10;
inline constexpr std::uint64_t UCD_PROJECTION_MATRIX = 0x50;
inline constexpr std::uint64_t UCD_CAMERA_REF       = 0xd0;
inline constexpr std::uint64_t UCD_PIXEL_WIDTH      = 0x158;
inline constexpr std::uint64_t UCD_PIXEL_HEIGHT     = 0x15c;

// Native UnityEngine.Camera (the object m_CachedPtr points to) — live matrices
// and screen size. Dump14 is IL2CPP x86-64: the matrices sit at proj = +0x140,
// view = +0x2F8 (separate fields, NOT contiguous), stored COLUMN-MAJOR — matches
// the oxide_esp x86-64 reference (config.h) and player.hpp camera_vp. Screen size
// @ 0x4A0 / 0x4A4.
inline constexpr std::uint64_t CAMERA_VIEW_MATRIX       = 0x2F8;
inline constexpr std::uint64_t CAMERA_PROJECTION_MATRIX = 0x140;
inline constexpr std::uint64_t CAMERA_SCREEN_WIDTH      = 0x4A0;
inline constexpr std::uint64_t CAMERA_SCREEN_HEIGHT     = 0x4A4;

// ---- Generic IL2CPP object layout -----------------------------------------
// UnityEngine.Object.m_CachedPtr (native object pointer) at 0x10
inline constexpr std::uint64_t MANAGED_CACHED_PTR   = 0x10;
// Component.m_GameObject (GameObject*) at 0x10
inline constexpr std::uint64_t TRANSFORM_GAMEOBJECT = 0x10;
// Il2CppList<T>:  items (T* array) @ 0x10,  size (int32) @ 0x18
inline constexpr std::uint64_t IL2CPP_LIST_ITEMS = 0x10;
inline constexpr std::uint64_t IL2CPP_LIST_SIZE  = 0x18;
// Il2CppArray<T>: first element @ 0x20 (after klass/monitor/bounds/capacity)
inline constexpr std::uint64_t IL2CPP_ARRAY_FIRST_ELEMENT = 0x20;

// Il2CppClass -> static_fields pointer: confirmed offset for this build = 0x58
// (reference cheat: pmStatic = *(pmClass + 0x58)). NOT 0xB8.
inline constexpr std::uint64_t IL2CPP_CLASS_STATIC_FIELDS = 0x58;
inline constexpr std::uint64_t STATIC_FIELDS_PROBES[] = { 0x58 };

// Camera object scan window for the embedded UniversalCameraData (by camera back-ref).
inline constexpr std::uint64_t UCD_SCAN_FROM = 0x10;
inline constexpr std::uint64_t UCD_SCAN_TO   = 0x400;

// ---- Matrix math -----------------------------------------------------------
inline constexpr bool MATRICES_ARE_COLUMN_MAJOR = true; // native Camera matrices are column-major (x86-64)
inline constexpr bool PROJECTION_TIMES_VIEW     = true;  // clip = P * V
inline constexpr float PLAYER_HEIGHT            = 1.8f;

} // namespace game_offsets
