#pragma once

#include "game.hpp"
#include "../other/vector3.h"
#include "../ui/theme/theme.hpp"
#include "imgui.h"
#include <cmath>

inline bool world_to_screen(const Vector3& pos, const matrix& m, ImVec2& out) noexcept {
    // row-major view-projection (Gandon): out = (vp * world)
    float sx = m.m11 * pos.x + m.m12 * pos.y + m.m13 * pos.z + m.m14;
    float sy = m.m21 * pos.x + m.m22 * pos.y + m.m23 * pos.z + m.m24;
    float sw = m.m41 * pos.x + m.m42 * pos.y + m.m43 * pos.z + m.m44;

    if (sw <= 0.0001f) {
        out = ImVec2(-10000.f, -10000.f);
        return false;
    }

    float iw = 1.f / sw;
    float nx = sx * iw;
    float ny = sy * iw;

    out.x = (nx + 1.f) * 0.5f * g_sw;
    out.y = (1.f - ny) * 0.5f * g_sh;

    return true;
}

inline float calculate_distance(const Vector3& a, const Vector3& b) noexcept {
    float dx = a.x - b.x;
    float dy = a.y - b.y;
    float dz = a.z - b.z;
    return sqrtf(dx * dx + dy * dy + dz * dz);
}
