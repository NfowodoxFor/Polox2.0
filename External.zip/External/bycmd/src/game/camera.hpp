#pragma once
#include "../other/memory.hpp"
#include "../other/vector3.h"
#include "game_offsets.h"
#include "../ui/log.hpp"
#include <cstdint>
#include <cmath>
#include <vector>
#include <cstring>
#include <ctime>
#include <algorithm>

// ESP camera/matrix logic — Dump14 (IL2CPP x86-64), offsets verified in dump.cs.
// Native Unity Camera: projection @ +0x140, view @ +0x2F8 (separate fields),
// matrices are COLUMN-MAJOR (matches oxide_esp x86-64 reference config.h and
// player.hpp camera_vp). view-projection = Projection * View.
// Pointers are absolute (no relative-pointer relocation); rp() is a no-op in this build.

namespace camera {

struct Mat4 { float m[16]; };
struct Vec2 { float x, y; };

// runtime state
inline float g_sw = 0, g_sh = 0;
inline uint64_t g_view_addr = 0, g_proj_addr = 0;
inline uint64_t g_cam_view_off = game_offsets::CAMERA_VIEW_MATRIX;
inline uint64_t g_cam_proj_off = game_offsets::CAMERA_PROJECTION_MATRIX;
inline int g_order = 1;        // 1 => Projection * View
inline int g_trans = 0;        // row-major, no transpose
inline bool g_valid = false;
inline uint64_t g_valid_t = 0;
inline uint64_t g_dbg_camobj = 0;
inline uint64_t g_dbg_struct = 0;
inline int g_dbg_best = 0;
inline int g_dbg_cands = 0;

inline uint64_t g_managed_camera = 0;
inline uint64_t g_camera_scan_attempt = 0;
inline bool g_ucd_hit = false;      // last camera resolve used a UniversalCameraData instance

// matrix offsets inside the native Camera (mutable; validated at runtime against
// candidate pairs — the reference cheat's 0x2F8/0x140 and the legacy 0x10/0x50).
inline uint64_t g_projection_matrix_offset = game_offsets::CAMERA_PROJECTION_MATRIX;
inline uint64_t g_view_matrix_offset       = game_offsets::CAMERA_VIEW_MATRIX;

// ---- row-major matrix access (MATRICES_ARE_COLUMN_MAJOR = false) ----
inline bool g_matrices_column_major = game_offsets::MATRICES_ARE_COLUMN_MAJOR;
inline float mat_get(const Mat4& M, int r, int c) {
    size_t i = g_matrices_column_major ? (size_t)c * 4 + r : (size_t)r * 4 + c;
    return M.m[i];
}
inline bool matrix_is_finite(const Mat4& M) {
    bool nz = false;
    for (float v : M.m) {
        if (!std::isfinite(v) || fabsf(v) > 1e6f) return false;
        if (fabsf(v) > 1e-6f) nz = true;
    }
    return nz;
}
inline Mat4 mat_mul(const Mat4& a, const Mat4& b) {
    Mat4 r{};
    for (int row = 0; row < 4; ++row)
        for (int col = 0; col < 4; ++col) {
            float v = 0;
            for (int k = 0; k < 4; ++k) v += mat_get(a, row, k) * mat_get(b, k, col);
            size_t idx = g_matrices_column_major ? (size_t)col * 4 + row : (size_t)row * 4 + col;
            r.m[idx] = v;
        }
    return r;
}

// Extract camera world position from the (world->view) matrix by inverting it.
inline bool camera_position_from_view(const Mat4& view, Vector3& position) {
    double aug[4][8]{};
    for (int row = 0; row < 4; ++row) {
        for (int col = 0; col < 4; ++col) aug[row][col] = mat_get(view, row, col);
        aug[row][row + 4] = 1.0;
    }
    for (int col = 0; col < 4; ++col) {
        int pivot = col;
        for (int row = col + 1; row < 4; ++row)
            if (fabs(aug[row][col]) > fabs(aug[pivot][col])) pivot = row;
        if (!std::isfinite(aug[pivot][col]) || fabs(aug[pivot][col]) < 1e-7) return false;
        if (pivot != col) for (int i = 0; i < 8; ++i) std::swap(aug[pivot][i], aug[col][i]);
        double div = aug[col][col];
        for (int i = 0; i < 8; ++i) aug[col][i] /= div;
        for (int row = 0; row < 4; ++row) {
            if (row == col) continue;
            double f = aug[row][col];
            for (int i = 0; i < 8; ++i) aug[row][i] -= f * aug[col][i];
        }
    }
    double w = aug[3][7];
    if (!std::isfinite(w) || fabs(w) < 1e-7) return false;
    position = { (float)(aug[0][7] / w), (float)(aug[1][7] / w), (float)(aug[2][7] / w) };
    return std::isfinite(position.x) && std::isfinite(position.y) && std::isfinite(position.z);
}

inline Mat4 view_projection();   // forward decl (defined below)

inline bool vec_ok(const Vector3& v) {
    return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z) &&
        (fabsf(v.x) > 0.01f || fabsf(v.y) > 0.01f || fabsf(v.z) > 0.01f) &&
        fabsf(v.x) < 1e6f && fabsf(v.y) < 1e6f && fabsf(v.z) < 1e6f;
}

inline bool w2s(const Mat4& vp, const Vector3& world, float sw, float sh, Vec2& out) {
    float cx = mat_get(vp, 0, 0) * world.x + mat_get(vp, 0, 1) * world.y +
        mat_get(vp, 0, 2) * world.z + mat_get(vp, 0, 3);
    float cy = mat_get(vp, 1, 0) * world.x + mat_get(vp, 1, 1) * world.y +
        mat_get(vp, 1, 2) * world.z + mat_get(vp, 1, 3);
    float cw = mat_get(vp, 3, 0) * world.x + mat_get(vp, 3, 1) * world.y +
        mat_get(vp, 3, 2) * world.z + mat_get(vp, 3, 3);
    if (!std::isfinite(cx) || !std::isfinite(cy) || !std::isfinite(cw) || cw <= 0.001f) return false;
    out.x = ((cx / cw) + 1.0f) * 0.5f * sw;
    out.y = ((-cy / cw) + 1.0f) * 0.5f * sh;
    return std::isfinite(out.x) && std::isfinite(out.y) &&
        out.x >= 0.0f && out.x <= sw && out.y >= 0.0f && out.y <= sh;
}
inline bool w2s(const Vector3& world, Vec2& out) {
    Mat4 vp = view_projection();
    return w2s(vp, world, g_sw, g_sh, out);
}

// ---- camera discovery ----
// Dump14 chain (verified in dump.cs):
//   GameControllerBase static fields (find_gc_static_fields) + O_CAMERA_MGR (0x38)
//     -> CameraManager -> m_Camera (O_CAM_MGR_CAMERA, 0x20) -> m_CachedPtr (0x10)
//     -> native Camera -> view@0x2F8 / proj@0x140.
// Fallback (per-player): fpManager@0x90 -> FPManager.m_WorldCamera@0x20 (Camera).
// We validate candidates by the finite view+proj matrices; screen size is best-effort.
inline uint64_t klass_of(uint64_t obj) { return obj ? rp(rpm<uint64_t>(obj)) : 0; }
inline uint64_t g_matrix_base = 0;

// Try a candidate matrix-address PAIR (view_off, proj_off) and adopt it if the
// matrices look like a real camera (finite + structural: view m44==1, proj m44==0).
inline bool try_matrix_pair(uint64_t base, uint64_t vo, uint64_t po) {
    if (!base) return false;
    Mat4 P = rpm<Mat4>(base + po);
    Mat4 V = rpm<Mat4>(base + vo);
    if (!matrix_is_finite(P) || !matrix_is_finite(V)) return false;
    // structural check (storage-agnostic): view m44==1, proj m44~=0 and m34!=0
    if (fabsf(V.m[15] - 1.f) > 0.05f) return false;
    if (fabsf(P.m[15]) > 0.05f) return false;
    if (fabsf(P.m[11]) < 0.01f) return false;
    return true;
}

// Validate matrices at the CURRENT offsets, else try known candidate pairs and
// adopt the first that passes (0x2F8/0x140 primary = Dump14, then 0x10/0x50 = legacy).
inline bool matrices_ok(uint64_t base) {
    if (!base) return false;
    if (try_matrix_pair(base, g_view_matrix_offset, g_projection_matrix_offset)) return true;
    static const uint64_t Vpairs[][2] = {
        { 0x2F8, 0x140 },   // Dump14 / x86-64 reference (primary)
        { 0x2E0, 0x320 },   // alternate native Camera layout
        { 0x10,  0x50  },   // legacy esp_logic layout
    };
    for (auto& p : Vpairs) {
        if (p[0] == g_view_matrix_offset && p[1] == g_projection_matrix_offset) continue;
        if (try_matrix_pair(base, p[0], p[1])) {
            g_view_matrix_offset = p[0];
            g_projection_matrix_offset = p[1];
            g_matrices_column_major = (p[0] == 0x2F8 || p[0] == 0x2E0);  // column-major layouts
            return true;
        }
    }
    return false;
}

// A candidate is a valid camera if it is (a) a managed Camera whose m_CachedPtr target
// has finite matrices, or (b) already the native camera object with finite matrices.
// NOTE: camClass must be the REAL Camera class (never 0), else the managed->native
// m_CachedPtr deref below can never run and cam stays 0.
inline bool try_camera(uint64_t cand, uint64_t camClass, uint64_t& nativeBase) {
    nativeBase = 0;
    if (!cand) return false;
    uint64_t nat = rp(rpm<uint64_t>(cand + game_offsets::MANAGED_CACHED_PTR));
    if (nat && matrices_ok(nat)) { nativeBase = nat; return true; }
    if (klass_of(cand) == camClass) {
        nat = rp(rpm<uint64_t>(cand + game_offsets::MANAGED_CACHED_PTR));
        if (nat && matrices_ok(nat)) { nativeBase = nat; return true; }
    }
    if (matrices_ok(cand)) { nativeBase = cand; return true; }
    return false;
}
inline bool camera_valid(uint64_t cand, uint64_t camClass) {
    uint64_t nb = 0; return try_camera(cand, camClass, nb);
}

// One-time discovery of the UniversalCameraData pointer inside the native Camera.
// UCD back-references its Camera at +0xd0; matrices live at +0x10 / +0x50 (verified in dump.cs).
inline uint64_t g_ucd_off = game_offsets::UCD_CAMERA_REF;  // 0xd0, HARDCODED
inline uint64_t find_ucd(uint64_t native, uint64_t managed) {
    (void)managed;
    uint64_t u = rp(rp(rpm<uint64_t>(native + game_offsets::UCD_CAMERA_REF)));
    if (u && matrices_ok(u)) return u;
    return 0;
}

inline int g_cam_sf_off = 0;
inline char g_cam_err[96] = "init";

// Camera class static_fields offset is HARDCODED (0xc0) — no scan.
inline int detect_sf_off(uint64_t) { return 0xc0; }

// Validate that a candidate class pointer really is UnityEngine.Camera (matches reference cheat).
inline bool is_camera_class(uint64_t cc) {
    if (!cc) return false;
    uint64_t namePtr = rp(rpm<uint64_t>(cc + 0x10));
    if (!namePtr) return false;
    char buf[16] = { 0 };
    mem_read_n(namePtr, (uint8_t*)buf, 8);
    return strncmp(buf, "Camera", 6) == 0;
}

// Scan the head of a native object (native Camera / UniversalCameraData) for a
// plausible (view, projection) matrix pair. Sets the live matrix offsets/addresses.
inline int native_scan_matrices(uint64_t base);

// Stateful/resumable GC-heap scan for managed Camera instances (real matrix lives
// on the NATIVE object via m_CachedPtr). Defined below camera_resolve.
inline int instance_camera_resolve(uint64_t camClass);

// Heap-scan for a managed UniversalCameraData instance (URP camera). The exact
// field layout comes from dump.cs: m_ViewMatrix@+0x10, m_ProjectionMatrix@+0x50,
// camera backref@+0xd0, pixelWidth@0x158/pixelHeight@0x15c. Matrices are
// COLUMN-major per the x86-64 reference. feetSamples are real player positions
// used to score candidates so the MAIN camera wins over overlay/minimap UCDs.
// anchorCam is the known live managed Camera (from the FP chain): a UCD whose
// camera backref equals it is the MAIN camera by construction (no scoring).
inline int ucd_scan_heap(const std::vector<Vector3>& feetSamples, uint64_t anchorCam = 0);

inline bool camera_resolve(uint64_t camClass) {
    if (!camClass) return false;

    if (g_ucd_hit && g_matrix_base) {
        Mat4 V = rpm<Mat4>(g_view_addr);
        Mat4 P = rpm<Mat4>(g_proj_addr);
        if (matrix_is_finite(V) && matrix_is_finite(P)) return true;
        g_ucd_hit = false;
    }

    auto cam_ok = [camClass](uint64_t c) -> uint64_t {
        if (!c) return 0;
        uint64_t nb = 0;
        if (try_camera(c, camClass, nb)) return nb;
        return 0;
    };
    if (g_managed_camera) { uint64_t nb = cam_ok(g_managed_camera); if (nb) { g_matrix_base = nb; return true; } }

    PlayerList pl = resolve_player_list();
    uint64_t cp = pl.local ? pl.local : (pl.players.empty() ? 0 : pl.players[0]);
    if (cp) {
        uint64_t fp = rp(rpm<uint64_t>(cp + O_FP_MANAGER));
        if (fp) {
            uint64_t cam = rp(rpm<uint64_t>(fp + O_CAM_MGR_CAMERA));
            if (cam) {
                uint64_t nb = cam_ok(cam);
                if (nb) { g_managed_camera = cam; g_matrix_base = nb; return true; }
                uint64_t nat = rp(rpm<uint64_t>(cam + game_offsets::MANAGED_CACHED_PTR));
                if (nat && matrices_ok(nat)) { g_managed_camera = cam; g_matrix_base = nat; return true; }
            }
        }
    }

    std::vector<Vector3> feet;
    if (ucd_scan_heap(feet)) return true;

    uint64_t natBase = instance_camera_resolve(camClass);
    if (natBase) { g_matrix_base = natBase; return true; }
    return false;
}

// ---- instance-based camera discovery (no hardcoded chain offsets) ----
// The Camera Il2CppClass is already resolved by name; every managed Camera
// object on the GC heap starts with that class pointer (klass field @ +0). We
// scan the heap for instances, read the native camera via m_CachedPtr (trying a
// few offsets), then scan the native object header for a (view, projection)
// 4x4 pair using the reference cheat's layout heuristics. This auto-detects the
// matrix offsets (0x10/0x50 as in the reference, or 0x2E0/0x320 as in other
// Unity builds), so no single stale constant can break the ESP.
inline std::vector<std::pair<uint64_t, uint64_t>> cam_heap_ranges() {
    std::vector<std::pair<uint64_t, uint64_t>> out;
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", proc::pid);
    FILE* f = fopen(path, "r");
    if (!f) return out;
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        uint64_t s = 0, e = 0;
        char perm[5]{};
        if (sscanf(line, "%lx-%lx %4s", &s, &e, perm) != 3) continue;
        if (perm[0] != 'r' || perm[1] != 'w') continue;
        if (strstr(line, ".so") || strstr(line, "/system/") || strstr(line, "/vendor/") ||
            strstr(line, "[stack") || strstr(line, "[vdso") || strstr(line, "[vvar") ||
            strstr(line, "/dev/")) continue;
        if (e - s > 0x10000000) continue;   // skip gigantic shared slices
        out.push_back({ s, e });
    }
    fclose(f);
    return out;
}

// ---- UniversalCameraData (URP) heap scan ----
// dump.cs (line 1606072): UniversalCameraData : ContextItem
//   m_ViewMatrix      0x10
//   m_ProjectionMatrix 0x50
//   camera (backref)  0xd0
//   pixelWidth        0x158  pixelHeight 0x15c
// The UCD instance is a MANAGED object on the GC heap whose klass is the
// UniversalCameraData Il2CppClass. We scan heap ranges chunk-wise for that
// klass, then validate the (view@+0x10, proj@+0x50) pair.
//
// Matrices are read as COLUMN-major (per user / x86-64 reference). Universal
// RenderPipeline creates ONE UCD per camera (main + any overlay/minimap), so
// a raw klass match can grab the WRONG camera and the ESP goes crooked. We
// score every candidate by projecting the real player positions (feet/head)
// and keep the UCD that reproduces them on screen best - exactly the reference
// cheat's validation, so the correct camera wins.
// Column-major signatures (reference is_projection/is_view):
//   proj: m[c*4+r] => m11==-1, m15==0, m14!=0, m0>0, m5>0
//   view: m15==1, columns c0=(0,1,2) c1=(4,5,6) c2=(8,9,10) orthonormal
// ucd_pair_ok validates a (view@+0x10, proj@+0x50) pair WITHOUT needing the
// klass — signatures only, at the fixed URP offsets.
inline bool ucd_pair_ok(const Mat4& V, const Mat4& P) {
    if (!matrix_is_finite(V) || !matrix_is_finite(P)) return false;
    if (fabsf(P.m[11] + 1.0f) > 0.01f) return false;
    if (fabsf(P.m[15]) > 0.01f) return false;
    if (fabsf(P.m[14]) < 1e-4f) return false;
    if (P.m[0] <= 0.0f || P.m[5] <= 0.0f) return false;
    if (fabsf(V.m[15] - 1.0f) > 0.01f) return false;
    if (!std::isfinite(V.m[3]) || !std::isfinite(V.m[7]) || !std::isfinite(V.m[11])) return false;
    auto vlen = [](float x, float y, float z) { return sqrtf(x * x + y * y + z * z); };
    auto vdot = [](const Mat4& M, int a, int b) {
        return M.m[a] * M.m[b] + M.m[a + 1] * M.m[b + 1] + M.m[a + 2] * M.m[b + 2];
    };
    float l0 = vlen(V.m[0], V.m[1], V.m[2]);
    float l1 = vlen(V.m[4], V.m[5], V.m[6]);
    float l2 = vlen(V.m[8], V.m[9], V.m[10]);
    if (fabsf(l0 - 1.0f) > 0.05f || fabsf(l1 - 1.0f) > 0.05f || fabsf(l2 - 1.0f) > 0.05f) return false;
    if (fabsf(vdot(V, 0, 4)) > 0.05f || fabsf(vdot(V, 0, 8)) > 0.05f || fabsf(vdot(V, 4, 8)) > 0.05f) return false;
    return true;
}

// Backref-validate the UCD camera pointer (@+0xd0): it must be a managed object
// whose klass name starts with "Camera". Used by the structural scan.
inline bool ucd_cam_ref_ok(uint64_t cam) {
    if (!cam || (cam & 7)) return false;
    uint64_t kam = rpm<uint64_t>(cam);
    if (!kam) return false;
    uint64_t nm = rpm<uint64_t>(kam + 0x10);
    if (!nm) return false;
    uint64_t nabs = (nm >= 0x100000000ULL) ? nm : (proc::lib + nm);
    char s[16] = { 0 };
    if (mem_read_n(nabs, (uint8_t*)s, 15) != 15) return false;
    return strncmp(s, "Camera", 6) == 0;
}

inline int ucd_scan_heap(const std::vector<Vector3>& feetSamples, uint64_t anchorCam) {
    static uint64_t ucdK = 0;
    if (!ucdK) ucdK = resolve_class_rva(0, "UniversalCameraData");
    // If the class can't be resolved by name (current build), fall through to a
    // structural scan: fixed view@+0x10/proj@+0x50 pairs + Camera backref.
    static bool warned = false;
    if (!ucdK && !warned) {
        warned = true;
        logger::f("[esp] ucd klass NOT resolved -> structural scan");
    }
    static int ridx = -1;
    static uint64_t roff = 0;
    static uint64_t class_key = 0;
    static int pid_cache = -1;
    static std::vector<std::pair<uint64_t, uint64_t>> ranges;
    static double last_complete = 0;
    static uint64_t found_inst = 0;      // last validated UCD instance
    const uint64_t CS = 0x40000;

    // Re-validate cached instance each call (cheap): matrices still present & camera backref.
    if (found_inst) {
        Mat4 V = rpm<Mat4>(found_inst + game_offsets::UCD_VIEW_MATRIX);
        Mat4 P = rpm<Mat4>(found_inst + game_offsets::UCD_PROJECTION_MATRIX);
        uint64_t cam = rp(rpm<uint64_t>(found_inst + game_offsets::UCD_CAMERA_REF));
        if (matrix_is_finite(V) && matrix_is_finite(P) && cam) {
            g_managed_camera = cam;
            g_matrix_base = found_inst;
            g_view_addr = found_inst + game_offsets::UCD_VIEW_MATRIX;
            g_proj_addr = found_inst + game_offsets::UCD_PROJECTION_MATRIX;
            g_view_matrix_offset = game_offsets::UCD_VIEW_MATRIX;
            g_projection_matrix_offset = game_offsets::UCD_PROJECTION_MATRIX;
            g_matrices_column_major = true;   // column-major (x86-64 reference)
            g_ucd_hit = true;
            return 1;
        }
        found_inst = 0;   // stale -> rescan
    }

    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    double now = (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;

    if (class_key != ucdK || pid_cache != proc::pid) {
        class_key = ucdK;
        pid_cache = proc::pid;
        ridx = -1; roff = 0; last_complete = 0; found_inst = 0;
        ranges = cam_heap_ranges();
    }
    if (ridx == -1) { ridx = 0; roff = 0; }
    if (ridx >= (int)ranges.size()) {
        if (last_complete != 0 && now - last_complete > 2.0) { ridx = 0; roff = 0; }
        if (last_complete == 0) last_complete = now;
        return 0;
    }

    std::vector<uint8_t> buf(CS);
    double t0 = now;
    while (ridx < (int)ranges.size()) {
        auto& r = ranges[(size_t)ridx];
        uint64_t total = r.second - r.first;
        while (roff < total) {
            uint64_t addr = r.first + roff;
            uint64_t want = (total - roff < CS) ? (total - roff) : CS;
            ssize_t nn = mem_read_n(addr, buf.data(), want);
            roff += CS;
            if (nn <= 0) continue;
            size_t rn = (size_t)nn;
            for (size_t i = 0; i + 0xd8 <= rn; i += 8) {
                uint64_t q = 0;
                memcpy(&q, buf.data() + i, 8);
                if (ucdK) { if (q != ucdK) continue; }
                else {
                    // structural mode: candidate klass field must itself look like
                    // a class/pointer (non-trivial), else skip cheaply
                    if (!q || q == (uint64_t)-1 || q < 0x10000) continue;
                }
                uint64_t inst = addr + i;
                if ((inst & 7) != 0) continue;
                // validate matrices straight from the scanned buffer (no per-candidate
                // rpm<Mat4>: scanning MBs of heap would need millions of preads)
                Mat4 V, P;
                memcpy(&V, buf.data() + i + game_offsets::UCD_VIEW_MATRIX, 64);
                memcpy(&P, buf.data() + i + game_offsets::UCD_PROJECTION_MATRIX, 64);
                if (!ucd_pair_ok(V, P)) continue;
                uint64_t camQ = 0;
                memcpy(&camQ, buf.data() + i + game_offsets::UCD_CAMERA_REF, 8);
                uint64_t cam = rp(camQ);
                if (!cam) continue;
                if (!ucdK && !ucd_cam_ref_ok(cam) && !(anchorCam && cam == anchorCam)) continue;
                // Anchored candidate (UCD.camera == live FP-chain Camera) is the main
                // camera BY CONSTRUCTION — accept immediately, no scoring.
                if (anchorCam && cam == anchorCam) {
                    g_managed_camera = cam;
                    g_matrix_base = inst;
                    g_view_addr = inst + game_offsets::UCD_VIEW_MATRIX;
                    g_proj_addr = inst + game_offsets::UCD_PROJECTION_MATRIX;
                    g_view_matrix_offset = game_offsets::UCD_VIEW_MATRIX;
                    g_projection_matrix_offset = game_offsets::UCD_PROJECTION_MATRIX;
                    g_matrices_column_major = true;   // column-major (x86-64 reference)
                    g_ucd_hit = true;
                    found_inst = inst;
                    logger::f("[esp] UCD anchored: ucd=%llx cam=%llx", (unsigned long long)inst, (unsigned long long)cam);
                    return 1;
                }

                // Score this UCD by projecting the real player positions (feet/head
                // heights must look like players). Prefer the candidate that lands
                // the most players plausibly on screen — skips overlay/minimap UCDs.
                Mat4 vp;
                {
                    g_matrices_column_major = true;
                    vp = mat_mul(P, V);
                }
                int score = 0;
                for (const auto& feet : feetSamples) {
                    if (!vec_ok(feet)) continue;
                    Vector3 head{ feet.x, feet.y + game_offsets::PLAYER_HEIGHT, feet.z };
                    Vec2 fs{}, hs{};
                    float sw = g_sw, sh = g_sh;
                    if (sw <= 0) sw = 1280.0f;
                    if (sh <= 0) sh = 720.0f;
                    if (w2s(vp, feet, sw, sh, fs) && w2s(vp, head, sw, sh, hs)) {
                        float hgt = fabsf(fs.y - hs.y);
                        if (hgt >= 2.0f && hgt <= sh * 1.5f) ++score;
                    }
                }
                if (!feetSamples.empty() && score <= 0) continue;
                if (score > g_dbg_best) g_dbg_best = score;
                // keep the BEST-scoring candidate (last valid wins ties)
                // screen size sanity from UCD (pixelWidth/Height)
                int32_t pw = rpm<int32_t>(inst + game_offsets::UCD_PIXEL_WIDTH);
                int32_t ph = rpm<int32_t>(inst + game_offsets::UCD_PIXEL_HEIGHT);
                if (pw >= 100 && pw <= 10000 && ph >= 100 && ph <= 10000) { g_sw = (float)pw; g_sh = (float)ph; }
                found_inst = inst;
                g_managed_camera = cam;
                g_matrix_base = inst;
                g_view_addr = inst + game_offsets::UCD_VIEW_MATRIX;
                g_proj_addr = inst + game_offsets::UCD_PROJECTION_MATRIX;
                g_view_matrix_offset = game_offsets::UCD_VIEW_MATRIX;
                g_projection_matrix_offset = game_offsets::UCD_PROJECTION_MATRIX;
                g_matrices_column_major = true;   // column-major (x86-64 reference)
                g_ucd_hit = true;
                return 1;
            }
            clock_gettime(CLOCK_MONOTONIC, &ts);
            now = (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
            if (now - t0 > 0.3) return 0;   // continue next frame
        }
        ridx++;
        roff = 0;
    }
    last_complete = now;
    return 0;
}

inline bool mat_viewish(const Mat4& V) {
    if (!matrix_is_finite(V)) return false;
    if (fabsf(V.m[15] - 1.f) > 0.05f) return false;              // m44 == 1
    if (fabsf(V.m[3]) > 0.01f || fabsf(V.m[7]) > 0.01f || fabsf(V.m[11]) > 0.01f) return false;
    if (fabsf(V.m[5]) < 1e-3f || fabsf(V.m[10]) < 1e-3f) return false;
    return true;
}
inline bool mat_projish(const Mat4& P) {
    if (!matrix_is_finite(P)) return false;
    if (fabsf(P.m[15]) > 0.05f) return false;                    // projection m44 ~ 0
    if (fabsf(P.m[11]) < 0.01f) return false;                    // depth scale (m34)
    if (fabsf(P.m[0]) < 1e-3f || fabsf(P.m[5]) < 1e-3f) return false;
    return true;
}

// Scan the head of a native object (native Camera / UniversalCameraData) for a
// plausible (view, projection) matrix pair. Sets the live matrix offsets/addresses.
inline int native_scan_matrices(uint64_t base) {
    if (!base || (base & 7)) return 0;
    const size_t WIN = 0x400;
    std::vector<uint8_t> buf(WIN);
    ssize_t n = mem_read_n(base, buf.data(), WIN);
    if (n <= 0) return 0;
    static const int64_t pd[] = { -0x1B8, -0x140, 0x140, -0x100, 0x100, -0x180, 0x180,
                                  -0xC0, 0xC0, -0x200, 0x200, -0x80, 0x80, -0x40, 0x40,
                                  0x38, 0x48, 0x58, 0x60, -0x30, 0x30 };
    for (size_t vo = 0; vo + 64 <= (size_t)n; vo += 4) {
        if (vo & 7) continue;
        Mat4 V;
        memcpy(&V, buf.data() + vo, 64);
        if (!mat_viewish(V)) continue;
        for (int64_t d : pd) {
            int64_t po = (int64_t)vo + d;
            if (po < 0 || po + 64 > (int64_t)n) continue;
            Mat4 P;
            memcpy(&P, buf.data() + po, 64);
            if (!mat_projish(P)) continue;
            g_view_addr = base + vo;
            g_proj_addr = base + po;
            g_view_matrix_offset = (uint64_t)vo;
            g_projection_matrix_offset = (uint64_t)po;
            g_matrix_base = base;
            return 1;
        }
    }
    return 0;
}

// Stateful/resumable heap scan for Camera instances; never stalls a frame.
inline int instance_camera_resolve(uint64_t camClass) {
    if (!camClass) return 0;
    static int ridx = -1;
    static uint64_t roff = 0;
    static uint64_t class_key = 0;
    static int pid_cache = -1;
    static std::vector<std::pair<uint64_t, uint64_t>> ranges;
    static double last_complete = 0;
    const uint64_t CS = 0x40000;

    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    double now = (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;

    if (class_key != camClass || pid_cache != proc::pid) {
        class_key = camClass;
        pid_cache = proc::pid;
        ridx = -1;
        roff = 0;
        last_complete = 0;
        ranges = cam_heap_ranges();
    }
    if (ridx == -1) { ridx = 0; roff = 0; }
    if (ridx >= (int)ranges.size()) {
        if (last_complete != 0 && now - last_complete > 2.0) { ridx = 0; roff = 0; }
        if (last_complete == 0) last_complete = now;
        return 0;
    }

    std::vector<uint8_t> buf(CS);
    double t0 = now;
    while (ridx < (int)ranges.size()) {
        auto& r = ranges[(size_t)ridx];
        uint64_t total = r.second - r.first;
        while (roff < total) {
            uint64_t addr = r.first + roff;
            uint64_t want = (total - roff < CS) ? (total - roff) : CS;
            ssize_t nn = mem_read_n(addr, buf.data(), want);
            roff += CS;
            if (nn <= 0) continue;
            size_t rn = (size_t)nn;
            for (size_t i = 0; i + 8 <= rn; i += 8) {
                uint64_t q = 0;
                memcpy(&q, buf.data() + i, 8);
                if (q != camClass) continue;
                uint64_t inst = addr + i;
                for (uint64_t co : { 0x10ULL, 0x18ULL, 0x20ULL, 0x28ULL }) {
                    uint64_t nat = rp(rpm<uint64_t>(inst + co));
                    if (!nat || (nat & 7)) continue;
                    if (native_scan_matrices(nat)) {
                        g_managed_camera = inst;
                        g_dbg_camobj = 1;
                        logger::f("[esp] camera instance: %llx native=%llx view+0x%x proj+0x%x",
                            (unsigned long long)inst, (unsigned long long)nat,
                            (unsigned int)g_view_matrix_offset,
                            (unsigned int)g_projection_matrix_offset);
                        return 1;
                    }
                    uint64_t ucd = rp(rpm<uint64_t>(nat + game_offsets::UCD_CAMERA_REF));
                    if ((ucd & 7) == 0 && native_scan_matrices(ucd)) {
                        g_managed_camera = inst;
                        g_dbg_camobj = 1;
                        logger::f("[esp] camera UCD: inst=%llx ucd=%llx view+0x%x proj+0x%x",
                            (unsigned long long)inst, (unsigned long long)ucd,
                            (unsigned int)g_view_matrix_offset,
                            (unsigned int)g_projection_matrix_offset);
                        return 1;
                    }
                }
            }
            clock_gettime(CLOCK_MONOTONIC, &ts);
            now = (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
            if (now - t0 > 0.3) return 0;   // continue next frame
        }
        ridx++;
        roff = 0;
    }
    last_complete = now;
    return 0;
}

inline uint64_t get_camera_native() {
    // pointer model is set by resolve_player_list() (it probes the real static_fields offset),
    // so we do NOT call rp_detect here (it would overwrite the correct model with a 0xc0 read).
    // Resolve the Camera Il2CppClass. PRIMARY: read the TypeInfo SLOT directly.
    // The slot is `UnityEngine_Camera_c*` => lib+slot = Il2CppClass* (same scheme as
    // PlayerManager, Dump14 script.json). IMPORTANT: the slot is ONLY valid on the
    // REATTACHED base (refmem::g_base = base[1]); the plain proc::lib mapping
    // (base[0]) yields a garbage value for the same RVA (as the REFDIAG shows for PM:
    // base[0] slot=20029257 vs base[1] slot=73b581814500). So read the slot from
    // refmem::g_base FIRST, then proc::lib as fallback, and validate by class name.
    // A slot class whose name does not read cleanly is still accepted as a candidate
    // (the ReadString mangling seen for PM proves name reads are unreliable here);
    // try_camera() / klass_of() do the real validation against live matrix pairs.
    auto slot_is_class = [](uint64_t v) { return v >= 0x100000000ULL && (v & 7) == 0; };
    uint64_t camClass = 0;
    uint64_t camSlotAddr = 0;
    if (refmem::g_base) {
        camSlotAddr = refmem::g_base + game_offsets::CAMERA_TYPEINFO_RVA;
        uint64_t r1 = rpm<uint64_t>(camSlotAddr);
        if (slot_is_class(r1)) camClass = r1;
    }
    if (!camClass) {
        camSlotAddr = proc::lib + game_offsets::CAMERA_TYPEINFO_RVA;
        uint64_t r0 = rpm<uint64_t>(camSlotAddr);
        if (slot_is_class(r0)) camClass = r0;
    }
    if (!camClass) camClass = resolve_class_rva(game_offsets::CAMERA_TYPEINFO_RVA, "Camera");

    static bool g_cam_diag_done = false;
    if (!g_cam_diag_done) {
        g_cam_diag_done = true;
        uint64_t s0v = refmem::g_base ? refmem::g_base + game_offsets::CAMERA_TYPEINFO_RVA : 0;
        uint64_t r0v = s0v ? rpm<uint64_t>(s0v) : 0;
        uint64_t s1v = proc::lib + game_offsets::CAMERA_TYPEINFO_RVA;
        uint64_t r1v = rpm<uint64_t>(s1v);
        snprintf(g_cam_diag, sizeof(g_cam_diag),
            "use%llx ref@%llx=%llx lib@%llx=%llx cls=%llx rprel=%d",
            (unsigned long long)camSlotAddr, (unsigned long long)s0v, (unsigned long long)r0v,
            (unsigned long long)s1v, (unsigned long long)r1v,
            (unsigned long long)camClass, (int)g_rp_rel);
    }

    bool found = camera_resolve(camClass);

    g_dbg_camobj = g_managed_camera ? 1 : 0;
    if (!g_managed_camera) {
        g_valid = false; g_dbg_struct = 1;
        snprintf(g_cam_err, sizeof(g_cam_err), "no cam obj sf=%d", g_cam_sf_off);
        return 0;
    }

    uint64_t base = 0;
    if (g_ucd_hit) {
        // URP path: matrices already found on the UniversalCameraData instance.
        base = g_matrix_base;
        g_view_addr = base + g_view_matrix_offset;
        g_proj_addr = base + g_projection_matrix_offset;
    } else {
        uint64_t realClass = rp(rpm<uint64_t>(g_managed_camera));
        if (!try_camera(g_managed_camera, realClass, base)) {
            // native camera present but no matrices there -> grab UniversalCameraData
            uint64_t nat = rp(rpm<uint64_t>(g_managed_camera + game_offsets::MANAGED_CACHED_PTR));
            if (nat) {
                uint64_t ucd = find_ucd(nat, g_managed_camera);
                if (ucd && matrices_ok(ucd)) base = ucd;
            }
        }
    }
    if (!base) {
        g_valid = false; g_dbg_struct = 1;
        uint64_t nat = rp(rpm<uint64_t>(g_managed_camera + game_offsets::MANAGED_CACHED_PTR));
        snprintf(g_cam_err, sizeof(g_cam_err), "no matrix nat=%llx ucd=%llx",
            (unsigned long long)nat, (unsigned long long)g_ucd_off);
        return 0;
    }

    g_matrix_base = base;
    g_view_addr = base + g_view_matrix_offset;
    g_proj_addr = base + g_projection_matrix_offset;
    g_cam_view_off = g_view_matrix_offset;
    g_cam_proj_off = g_projection_matrix_offset;

    // screen size: native Camera @ +0x4A0/0x4A4, else UCD @ +0x158/0x15C, else fallback
    int32_t w1 = rpm<int32_t>(base + game_offsets::CAMERA_SCREEN_WIDTH);
    int32_t h1 = rpm<int32_t>(base + game_offsets::CAMERA_SCREEN_HEIGHT);
    int32_t w2 = rpm<int32_t>(base + game_offsets::UCD_PIXEL_WIDTH);
    int32_t h2 = rpm<int32_t>(base + game_offsets::UCD_PIXEL_HEIGHT);
    if (w1 >= 100 && w1 <= 10000 && h1 >= 100 && h1 <= 10000) { g_sw = (float)w1; g_sh = (float)h1; }
    else if (w2 >= 100 && w2 <= 10000 && h2 >= 100 && h2 <= 10000) { g_sw = (float)w2; g_sh = (float)h2; }
    else { g_sw = g_screen_w; g_sh = g_screen_h; }

    g_valid = true;
    g_valid_t = (uint64_t)time(nullptr);
    snprintf(g_cam_err, sizeof(g_cam_err), "OK base=%llx sw=%d",
        (unsigned long long)base, (int)g_sw);
    return base;
}

inline Mat4 view_matrix() { return rpm<Mat4>(g_view_addr); }
inline Mat4 view_projection() {
    Mat4 P = rpm<Mat4>(g_proj_addr);
    Mat4 V = rpm<Mat4>(g_view_addr);
    return game_offsets::PROJECTION_TIMES_VIEW ? mat_mul(P, V) : mat_mul(V, P);
}

inline bool resolve(const std::vector<Vector3>& samples) {
    uint64_t now = (uint64_t)time(nullptr);
    // Once the camera is resolved (native Camera via a chain, or UCD fallback),
    // revalidate the cached matrices cheaply each frame (2 short reads) instead of
    // re-running the full camera discovery — no more periodic heap-rescan lag spikes.
    if (g_valid && g_matrix_base && g_view_addr && g_proj_addr) {
        Mat4 V = rpm<Mat4>(g_view_addr);
        Mat4 P = rpm<Mat4>(g_proj_addr);
        if (matrix_is_finite(V) && matrix_is_finite(P)) {
            g_valid_t = now;
            return true;
        }
        g_ucd_hit = false;   // stale -> full re-derive below
    }

    uint64_t native = get_camera_native();
    if (!native || !g_valid) return false;

    // diagnostics: how many real player positions project in front of the camera
    Mat4 vp = view_projection();
    int front = 0;
    for (const auto& w : samples) {
        float cw = mat_get(vp, 3, 0) * w.x + mat_get(vp, 3, 1) * w.y +
            mat_get(vp, 3, 2) * w.z + mat_get(vp, 3, 3);
        if (cw > 0.001f) front++;
    }
    g_dbg_best = front;
    return true;
}

// ---- Aimbot: write look rotation (m_CameraTargetRot quaternion) ----
struct Quat { float x, y, z, w; };
inline Quat quat_from_to(const Vector3& a, const Vector3& b) {
    Vector3 cr{
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x
    };
    float d = a.x * b.x + a.y * b.y + a.z * b.z;
    float w = 1.f + d;
    Quat q;
    if (w < 1e-6f) {
        if (fabsf(a.x) > fabsf(a.z)) q = { 0.f, a.z, -a.y, 0.f };
        else                         q = { -a.y, 0.f, a.x, 0.f };
    } else {
        q = { cr.x, cr.y, cr.z, w };
    }
    float n = sqrtf(q.x * q.x + q.y * q.y + q.z * q.z + q.w * q.w);
    q.x /= n; q.y /= n; q.z /= n; q.w /= n;
    return q;
}
inline bool write_aim(uint64_t localPlayer, const Vector3& campos, const Vector3& target, uint64_t rotOff) {
    uint64_t ml = rpm<uint64_t>(localPlayer + 0x70);   // mouseLook
    if (!ml || (ml & 7)) return false;
    Vector3 dir = { target.x - campos.x, target.y - campos.y, target.z - campos.z };
    float len = sqrtf(dir.x * dir.x + dir.y * dir.y + dir.z * dir.z);
    if (len < 1e-4f) return false;
    dir.x /= len; dir.y /= len; dir.z /= len;
    Quat q = quat_from_to({ 0.f, 0.f, -1.f }, dir);
    wpm<Quat>(ml + rotOff, q);
    return true;
}

} // namespace camera
