#pragma once

#include "../other/memory.hpp"
#include "game_offsets.h"
#include "../ui/log.hpp"

inline float g_screen_w = 1920.f, g_screen_h = 1080.f;
#include "../protect/oxorany.hpp"
#include <stdint.h>
#include <cstdio>
#include <cstring>
#include <vector>
#include <string>
#include <unordered_map>
#include <ctime>
#include <cmath>
#include <dirent.h>
#include <cctype>

inline double scan_clock() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

struct matrix {
    float m11, m12, m13, m14;
    float m21, m22, m23, m24;
    float m31, m32, m33, m34;
    float m41, m42, m43, m44;
};

namespace offsets {
    // RVA of a unique static method, used as a runtime "seed" to locate the
    // PlayerManager Il2CppClass WITHOUT the (encrypted) metadata or any RVA.
    // From dump.cs: public static PlayerManager YNj(string) -> RVA 0x611ab01.
    inline uint64_t player_manager_method = oxorany(0x611ab01);
    // static field slot of clientPlayerList inside PlayerManager
    inline uint64_t client_player_list = oxorany(0x10);
}

// Diagnostics
inline uint64_t g_dbg_kD = 0;          // discovered PlayerManager Il2CppClass
inline uint64_t g_dbg_kD2 = 0;         // discovered GameControllerBase Il2CppClass
inline int g_pm_sf_off = 0x88;         // static_fields offset within Il2CppClass
inline uint64_t g_dbg_cls_cam = 0;     // discovered UnityEngine.Camera class
inline uint64_t g_dbg_field_off = 0;   // class offset where static_fields ptr was found
inline uint64_t g_dbg_sf = 0;          // PlayerManager static_fields pointer
inline uint64_t g_dbg_mod_start = 0, g_dbg_mod_end = 0;
inline uint64_t g_dbg_meta = 0;        // metadata string table located (1) or not (0)
inline uint64_t g_dbg_saddr = 0;       // address of the class-name string found
inline int g_dbg_strcount = 0;         // # of class-name strings found across mappings
inline int g_dbg_refcount = 0;         // # of qword references to that string found
inline int g_dbg_named = 0;            // # of name-back-pointing classes tried
inline int g_dbg_sfok = 0;             // # of those whose static_fields block matched
// Block-layout diagnostic (reads the known static_fields block, no scanning)
inline uint64_t g_dbg_blk = 0;
inline uint64_t g_dbg_lst[3] = {0,0,0};
inline uint64_t g_dbg_litems[3] = {0,0,0};
inline int      g_dbg_lcnt[3] = {0,0,0};
inline int      g_dbg_lcnt2[3] = {0,0,0};
inline uint64_t g_dbg_lelem0[3] = {0,0,0};
inline uint64_t g_dbg_raw[2][9] = {{0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0}};
// Structural-scan diagnostics
inline uint64_t g_dbg_hranges = 0;     // heap ranges scanned
inline uint64_t g_dbg_hbytes = 0;      // heap bytes actually read
inline uint64_t g_dbg_objs = 0;        // managed-object candidates (klass in lib range)
inline uint64_t g_dbg_lists = 0;       // passed List(items/count) check
inline uint64_t g_dbg_elems = 0;       // passed element-same-class check
inline uint64_t g_dbg_struct = 0;      // passed structural signature
inline uint64_t g_dbg_cam = 0;         // camera matrix candidates found
inline uint64_t g_dbg_probe = 0;       // qwords in lib range in first heap probe
inline long g_dbg_rv = 0;              // raw process_vm_readv result on first heap read
inline int g_dbg_err = 0;             // errno on first heap read
// Player-list resolution deep diagnostics
inline uint64_t g_dbg_pm = 0;         // PlayerManager class address
inline uint64_t g_dbg_sf80 = 0;       // raw rpm(pm + 0x80) static_fields probe
inline int g_dbg_maxn = 0;            // max player count found across full scan
inline int g_dbg_mgr = 0;             // PlayerManager instances found
inline int g_dbg_maxoff = 0;           // class offset where maxn was found
inline int g_dbg_maxbo = 0;            // block field offset where maxn was found
inline uint64_t g_dbg_sf88 = 0;        // raw rpm(pm + 0x88) static_fields probe
inline uint32_t g_dbg_sfsize = 0;      // raw rpm(pm + 0x90) static_fields_size
inline char g_dbg_name[32] = {0};      // klass name read from pm+0x10
inline char g_dbg_ns[48] = {0};        // klass namespace read from pm+0x18
inline char g_pm_err[200] = {0};       // raw PlayerManager slot/class diagnostics
inline char g_cam_diag[200] = {0};     // raw Camera slot/class diagnostics
inline uint64_t g_class_cache[5] = {0, 0, 0, 0, 0};  // [0]=PlayerManager, [1]=Camera, [2]=GameControllerBase, [3]=CameraManager, [4]=UniversalCameraData
inline bool   g_class_done[5] = {false, false, false, false, false};
inline int    g_class_found[5] = {-1, -1, -1, -1, -1};   // -1 not scanned, 0 not found, 1 found
inline char   g_cls_diag[5][64] = {{0},{0},{0},{0},{0}};
inline int g_dbg_n0 = 0;                // players found in sleepingPlayerList
inline int g_dbg_n1 = 0;                // players found in activePlayerList
inline int g_dbg_n2 = 0;                // players found in clientPlayerList
inline uint64_t g_dbg_local = 0;        // local player pointer
inline int g_dbg_camok = 0;             // camera native resolved (1) or not (0)
inline int g_static_fields_off = 0;      // detected Il2CppClass -> static_fields pointer offset
inline uint64_t g_sv_last_name = 0;       // last resolved typeinfo name ptr (log throttle)

// Read a C string from a remote pointer (for class-name diagnostics).
inline void read_cstr(uint64_t addr, char* out, int n) noexcept {
    out[0] = 0;
    if (!addr) return;
    // Read in a single shot; on partial reads keep what we got and stop at the first
    // NUL so the caller never sees a truncated/garbage name.
    ssize_t rd = mem_read_n(addr, out, (size_t)n - 1);
    if (rd <= 0) return;
    for (ssize_t i = 0; i < rd; i++) {
        if (out[i] == 0) { out[i] = 0; return; }
    }
    out[rd] = 0;
}

// All readable mappings of the target process (excludes stacks/vdso/vvar).
inline std::vector<std::pair<uint64_t, uint64_t>> get_all_mappings() {
    std::vector<std::pair<uint64_t, uint64_t>> ranges;
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", proc::pid);
    FILE* f = fopen(path, "r");
    if (!f) return ranges;
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        uint64_t s = 0, e = 0; char perm[5]{};
        if (sscanf(line, "%lx-%lx %4s", &s, &e, perm) != 3) continue;
        if (perm[0] != 'r') continue;
        if (strstr(line, "[stack") || strstr(line, "[vdso") ||
            strstr(line, "[vvar") || strstr(line, "[vsyscall")) continue;
        ranges.push_back({ s, e });
    }
    fclose(f);
    return ranges;
}

// Byte-scan a [start,end) range for a byte pattern (handles chunk boundaries).
inline uint64_t find_bytes(const uint8_t* pat, size_t plen, uint64_t start, uint64_t end) {
    if (plen == 0 || start >= end) return 0;
    const size_t chunksz = 0x40000;
    std::vector<uint8_t> buf(chunksz + plen);
    for (uint64_t base = start; base < end; base += chunksz) {
        uint64_t remaining = end - base;
        size_t want = (size_t)(remaining < chunksz ? remaining : chunksz) + plen - 1;
        if (want > buf.size()) want = buf.size();
        ssize_t n = mem_read(base, buf.data(), want);
        if (n < (ssize_t)plen) continue;
        size_t rn = (size_t)n;
        size_t limit = rn - plen + 1;
        for (size_t i = 0; i < limit; i++) {
            if (memcmp(buf.data() + i, pat, plen) == 0) return base + i;
        }
    }
    return 0;
}

// Scan ALL process mappings for a null-terminated string (covers libil2cpp.so
// AND global-metadata.dat where IL2CPP stores class names). Cached per target.
inline uint64_t find_string(const char* target) {
    static std::unordered_map<std::string, uint64_t> cache;
    std::string key(target);
    auto it = cache.find(key);
    if (it != cache.end()) return it->second;
    uint64_t result = 0;
    size_t tlen = strlen(target);
    if (tlen > 0 && tlen <= 64) {
        auto ranges = get_all_mappings();
        std::vector<uint8_t> buf(0x40000);
        for (auto& r : ranges) {
            uint64_t total = r.second ? (r.second - r.first) : 0;
            for (uint64_t off = 0; off < total; off += 0x40000) {
                uint64_t addr = r.first + off;
                uint64_t chunklen = total - off; if (chunklen > 0x40000) chunklen = 0x40000;
                ssize_t n = mem_read(addr, buf.data(), chunklen);
                if (n <= 0) continue;
                size_t rn = (size_t)n;
                for (size_t i = 0; i + tlen < rn; i++) {
                    if (memcmp(buf.data() + i, target, tlen) == 0 && buf.data()[i + tlen] == 0) {
                        result = addr + i; goto done;
                    }
                }
            }
        }
    }
done:
    cache[key] = result;
    return result;
}

// Locate the decrypted IL2CPP metadata string table in live RAM by its header
// magic (same way Gandon's Il2CppGG does it). Returns the string-table span.
inline bool find_metadata_string_table(uint64_t& s, uint64_t& e) {
    static const uint8_t magic[8] = {0xAF, 0x1B, 0xB1, 0xFA, 0x27, 0x00, 0x00, 0x00};
    auto ranges = get_all_mappings();
    for (auto& r : ranges) {
        uint64_t hit = find_bytes(magic, 8, r.first, r.second);
        while (hit) {
            uint32_t ver = rpm<uint32_t>(hit + 0x4);
            uint64_t so = rpm<uint32_t>(hit + 0x18);
            uint64_t ss = rpm<uint32_t>(hit + 0x1C);
            if (ver >= 1 && ver <= 60 && so > 0x10 && so < 0x10000000 &&
                ss > 0x100 && ss < 0x10000000) {
                uint64_t st = hit + so;
                uint8_t b; if (mem_read(st, &b, 1) == 1) { s = st; e = st + ss; return true; }
            }
            uint64_t prev = hit;
            hit = find_bytes(magic, 8, prev + 1, r.second);
        }
    }
    return false;
}

// Find a null-terminated string within a known [s,e) byte range.
inline uint64_t find_string_in_range(const char* target, uint64_t s, uint64_t e) {
    size_t tlen = strlen(target);
    if (tlen == 0 || tlen > 64) return 0;
    const size_t chunksz = 0x40000;
    std::vector<uint8_t> buf(chunksz);
    for (uint64_t base = s; base < e; base += chunksz) {
        uint64_t remaining = e - base;
        size_t want = (size_t)(remaining < chunksz ? remaining : chunksz);
        ssize_t n = mem_read(base, buf.data(), want);
        if (n <= 0) continue;
        size_t rn = (size_t)n;
        for (size_t i = 0; i + tlen < rn; i++) {
            if (memcmp(buf.data() + i, target, tlen) == 0 && buf.data()[i + tlen] == 0)
                return base + i;
        }
    }
    return 0;
}

// Full address span of libil2cpp.so (all its /proc/pid/maps segments).
inline bool get_module_bounds(const char* lib, uint64_t& start, uint64_t& end) {
    start = end = 0;
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", proc::pid);
    FILE* f = fopen(path, "r");
    if (!f) return false;
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        if (!strstr(line, lib)) continue;
        uint64_t s = 0, e = 0; char perm[5]{};
        if (sscanf(line, "%lx-%lx %4s", &s, &e, perm) != 3) continue;
        if (start == 0 || s < start) start = s;
        if (e > end) end = e;
    }
    fclose(f);
    return start != 0 && end != 0;
}

// Local matrix sanity check (avoids depending on player.hpp).
inline bool mok(const matrix& m) noexcept {
    const float* f = reinterpret_cast<const float*>(&m);
    for (int i = 0; i < 16; i++) {
        if (!std::isfinite(f[i]) || std::fabs(f[i]) > 1e6f) return false;
    }
    return true;
}

// Readable heap-like mappings (managed objects / GC heap live here), excluding
// shared libraries, system, APK and stack. Used by structural discovery so we
// never have to read the (unreadable) metadata table.
inline std::vector<std::pair<uint64_t, uint64_t>> get_heap_ranges() {
    std::vector<std::pair<uint64_t, uint64_t>> out;
    char path[64]; snprintf(path, sizeof(path), "/proc/%d/maps", proc::pid);
    FILE* f = fopen(path, "r"); if (!f) return out;
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        uint64_t s = 0, e = 0; char perm[5]{};
        if (sscanf(line, "%lx-%lx %4s", &s, &e, perm) != 3) continue;
        if (perm[0] != 'r' || perm[1] != 'w') continue;
        if (strstr(line, ".so") || strstr(line, ".apk") ||
            strstr(line, "/system/") || strstr(line, "/vendor/")) continue;
        if (strstr(line, "[stack") || strstr(line, "[vdso") || strstr(line, "[vvar")) continue;
        out.push_back({ s, e });
    }
    fclose(f); return out;
}

// All readable mappings (r--/rw-/r-x/rwx), excluding stack/vdso/vvar. Used to
// locate the class names, which live in the global-metadata.dat mapping rather
// than inside libil2cpp.so. One-time, cached by caller.
inline std::vector<std::pair<uint64_t, uint64_t>> get_all_ranges() {
    std::vector<std::pair<uint64_t, uint64_t>> out;
    char path[256]; snprintf(path, sizeof(path), "/proc/%d/maps", (int)proc::pid);
    FILE* f = fopen(path, "r"); if (!f) return out;
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        uint64_t s = 0, e = 0; char perm[5]{};
        if (sscanf(line, "%lx-%lx %4s", &s, &e, perm) != 3) continue;
        if (perm[0] != 'r') continue;
        if (strstr(line, "[stack") || strstr(line, "[vdso") || strstr(line, "[vvar")) continue;
        out.push_back({ s, e });
    }
    fclose(f); return out;
}

// Readable mappings whose path contains `sub` (used to target global-metadata.dat).
inline std::vector<std::pair<uint64_t, uint64_t>> get_named_ranges(const char* sub) {
    std::vector<std::pair<uint64_t, uint64_t>> out;
    char path[256]; snprintf(path, sizeof(path), "/proc/%d/maps", (int)proc::pid);
    FILE* f = fopen(path, "r"); if (!f) return out;
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        uint64_t s = 0, e = 0; char perm[5]{};
        if (sscanf(line, "%lx-%lx %4s", &s, &e, perm) != 3) continue;
        if (perm[0] != 'r') continue;
        if (strstr(line, "[stack") || strstr(line, "[vdso") || strstr(line, "[vvar")) continue;
        if (strstr(line, sub)) out.push_back({ s, e });
    }
    fclose(f); return out;
}

// 100%-structural discovery of the player list. Scan the heap for a managed
// List<T> whose elements all share one Il2CppClass (in libil2cpp.so range) and
// whose elements expose the expected sub-object structure:
//   Transform @0x68, Vitals @0xC8, Model @0x150, Animator @0x198.
// No class names and no hardcoded RVAs are used. Heavily instrumented so we
// ---- PlayerManager discovery (name-based, exactly like Gandon) ----
// The Il2CppClass for Oxide.PlayerManager lives inside libil2cpp.so; its `name`
// field (class+0x10) points to the string "PlayerManager" (also in libil2cpp.so).
// So: find the string, find the qword that references it (the name field), and
// class = reference_address - 0x10. Then read its static_fields block and the
// static field clientPlayerList @ +0x10 to get List<PlayerManager>.
inline std::vector<uint64_t> scan_string(uint64_t start, uint64_t end, const char* str, double budget) {
    std::vector<uint64_t> out;
    size_t len = strlen(str);
    if (len == 0 || end <= start) return out;
    const size_t chunksz = 0x40000;
    std::vector<uint8_t> buf(chunksz);
    double t0 = scan_clock();
    for (uint64_t base = start; base + len <= end; base += chunksz) {
        uint64_t want = std::min<uint64_t>(chunksz, end - base);
        if (want < len) break;
        ssize_t n = mem_read_n(base, buf.data(), want);
        if (n >= (ssize_t)len) {
            size_t rn = (size_t)n;
            for (size_t i = 0; i + len <= rn; i++)
                if (memcmp(buf.data() + i, str, len) == 0) out.push_back(base + i);
        }
        if (budget > 0 && scan_clock() - t0 > budget) break;
    }
    return out;
}

inline std::vector<uint64_t> scan_qword(uint64_t start, uint64_t end, uint64_t target, double budget) {
    std::vector<uint64_t> out;
    if (end <= start) return out;
    const size_t chunksz = 0x40000;
    std::vector<uint8_t> buf(chunksz);
    double t0 = scan_clock();
    for (uint64_t base = start; base + 8 <= end; base += chunksz) {
        uint64_t want = std::min<uint64_t>(chunksz, end - base);
        if (want < 8) break;
        ssize_t n = mem_read_n(base, buf.data(), want);
        if (n >= 8) {
            size_t rn = (size_t)n;
            for (size_t i = 0; i + 8 <= rn; i += 8) {
                uint64_t v = 0; memcpy(&v, buf.data() + i, 8);
                if (v == target) out.push_back(base + i);
            }
        }
        if (budget > 0 && scan_clock() - t0 > budget) break;
    }
    return out;
}

// Locate the static_fields pointer inside an Il2CppClass by scanning its struct
// for a qword that points to a readable block holding the PlayerManager lists
// (PQ`1/List`1 at +0x0/+0x8, serverName string at +0x18). Returns the offset of
// that qword within the class, or 0 if not found.
inline int find_gc_static_fields(uint64_t klass, uint64_t libS, uint64_t libE);
inline int find_static_fields(uint64_t klass, uint64_t libS, uint64_t libE) {
    for (uint64_t off = 0x00; off <= 0xE8; off += 8) {
        uint64_t sf = rpm<uint64_t>(klass + off);
        if (!sf || sf < 0x10000 || (sf & 7)) continue;
        uint8_t t[8]; if (mem_read_n(sf, t, 8) != 8) continue;
        bool good = false;
        uint8_t lt[8];
        for (uint64_t lo : { 0x0ULL, 0x8ULL, 0x10ULL }) {
            uint64_t lst = rpm<uint64_t>(sf + lo);
            if (!lst || (lst & 7)) continue;
            if (mem_read_n(lst, lt, 8) != 8) continue;
            uint64_t arr = rpm<uint64_t>(lst + 0x10);
            int cnt = rpm<int>(lst + 0x18);
            if (cnt < 0 || cnt > 512) { arr = rpm<uint64_t>(lst + 0x20); cnt = rpm<int>(lst + 0x18); }
            // IL2CPP arrays live in the heap, so just require a plausible count and
            // (when non-empty) a readable array pointer.
            if (cnt >= 0 && cnt <= 512 && (cnt == 0 || (arr && (arr & 7) == 0 && mem_read_n(arr, lt, 8) == 8)))
                good = true;
        }
        if (!good) {
            uint64_t sn = rpm<uint64_t>(sf + 0x18);
            if (sn && (sn & 7) == 0) { char b[4]{}; read_cstr(sn, b, sizeof(b)); if (b[0]) good = true; }
        }
        if (good) return (int)off;
    }
    return 0;
}

// Shared name-based Il2CppClass finder. Class names live in the global-metadata.dat
// mapping (not libil2cpp.so), and the class struct itself may live in any module,
// so we scan EVERY readable mapping for both the string and the pointer that
// references it. `sf_ok` validates the static_fields block of a candidate class.
// Fully static Il2CppClass RVAs taken from dump.cs (TypeInfo lines; VA==RVA so the
// image base is 0, i.e. these are already module-relative offsets). No runtime scan
// is performed — the class address is simply lib_base + rva.
// ---- Static offsets, all sourced from dump.cs (TypeInfo lines / field offsets) ----
static const uint64_t PM_RVA = 0xD18B560;   // PLAYER_MANAGER_TYPEINFO_RVA (slot; Oxide.PlayerManager, Dump14 script.json)
static const uint64_t GC_RVA = 0xD186A98;   // GameControllerBase TypeInfo slot (Oxide.GameControllerBase, 219703960, user-confirmed) — @lib slot = Il2CppClass*
static const uint64_t CAM_RVA = 0xD183D38;  // UnityEngine.Camera_TypeInfo slot (219692344, user-confirmed) — @lib slot = Il2CppClass*

// Il2CppClass -> static_fields pointer offset. This varies by Unity version; it is now
// auto-detected at runtime (discover_pm_sf_off: the class qword that resolves to a heap
// block holding managed references). The value below is only a hint / last-known candidate
// (Unity 6 commonly uses 0xc0). Detection supersedes it.
static const uint64_t IL2CPP_CLASS_STATIC_FIELDS = 0xc0;  // Il2CppClass -> static_fields (detected at runtime)

// PlayerManager static_fields block: the three player collections (PQ`1 = PriorityQueue).
static const uint64_t SF_SLEEPING   = 0x00;   // sleepingPlayerList
static const uint64_t SF_ACTIVE     = 0x08;   // activePlayerList
static const uint64_t SF_CLIENT     = 0x10;   // clientPlayerList

// PlayerManager instance fields (AUTHORITATIVE — user-provided config).
static const uint64_t O_TRANSFORM   = 0x68;   // Transform (worldCameraRoot) -> world pos
static const uint64_t O_TRANSFORM_WORLD = 0x90; // Transform world position (Vector3)
static const uint64_t O_FP_MANAGER  = 0x90;   // fpManager (player-relative)
static const uint64_t O_VITALS      = 0xC8;   // vitals
static const uint64_t O_PLAYER_POS  = 0x1E0;  // real world position (Vector3) — verified live
static const uint64_t O_LOOK_ANGLE  = 0x1B0;  // lookAngle
static const uint64_t O_MOUSELOOK   = 0x70;   // mouseLook (camera chain)
static const uint64_t O_TEAM        = 0x120;
static const uint64_t O_CHARACTER   = 0x150;
static const uint64_t O_USERID      = 0x278;
static const uint64_t O_TEAMNAME    = 0x280;
static const uint64_t O_IMMORTAL    = 0x2B1;  // isImmortal
static const uint64_t O_OBSERVED    = 0x318;  // observedPlayer

// GameControllerBase static_fields: local player + camera manager.
static const uint64_t O_LOCAL_PLAYER = 0x10;  // <LZp>  (PlayerManager / local player)
static const uint64_t O_CAMERA_MGR   = 0x38;  // <LZD>  (CameraManager)

// CameraManager -> managed Camera (single hop, Dump14).
static const uint64_t O_CAM_MGR_CAMERA = 0x20;  // CameraManager.m_Camera

// MouseLook -> Camera -> native Camera (static chain).
static const uint64_t O_ML_CAM       = 0x20;  // MouseLook.cam : Camera
static const uint64_t O_CAM_CACHEDPTR = 0x10;  // Camera.m_CachedPtr -> native Camera

// Camera matrices — Unity 6 (Oxide) reference: proj@0x140, view@0x2F8 (col-major).
static const uint64_t CAMERA_VIEW_MATRIX = 0x2F8;
static const uint64_t CAMERA_PROJECTION_MATRIX = 0x140;

// PQ`1 (PriorityQueue) backing layout. dump.cs shows its fields as 0x0 (placeholder),
// so these are the layout confirmed from the live object: PQ`1.Dsk (EI`1, the backing
// List`1) sits at +0x20; EI`1 = List`1 with _items @ +0x10 and _size @ +0x18.
static const uint64_t PQ_BACKING_OFF  = 0x20;  // PQ`1.Dsk = EI`1
static const uint64_t LIST_ITEMS_OFF  = 0x10;  // List`1._items
static const uint64_t LIST_SIZE_OFF   = 0x18;  // List`1._size
static const uint64_t ARRAY_ELEMS_OFF = 0x20;  // Il2CppArray element[0]
// IL2CPP standard container layout (authoritative, given by user)
static const uint64_t IL2CPP_LIST_ITEMS = 0x10;          // List`1._items
static const uint64_t IL2CPP_LIST_SIZE  = 0x18;          // List`1._size
static const uint64_t IL2CPP_ARRAY_FIRST_ELEMENT = 0x20; // Il2CppArray element[0]

inline uint64_t find_player_manager_class() {
    uint64_t pm = proc::lib + PM_RVA;
    g_dbg_kD = pm;
    g_dbg_mod_start = proc::lib;
    g_dbg_mod_end = proc::lib + 0xD200000;   // approx libil2cpp size
    return pm;
}

inline uint64_t find_game_controller_base_class() {
    uint64_t gc = proc::lib + GC_RVA;
    g_dbg_kD2 = gc;
    return gc;
}

inline bool validate_player_list(uint64_t list, uint64_t pm) {
    if (!list) return false;
    uint64_t items = rpm<uint64_t>(list + 0x10);
    int32_t count = rpm<int32_t>(list + 0x18);
    if (!items || count < 0 || count > 512) return false;
    int chk = 0;
    for (int i = 0; i < count && chk < 4; i++) {
        uint64_t p = rpm<uint64_t>(items + 0x20 + (uint64_t)i * 8);
        if (!p) continue;
        if (rpm<uint64_t>(p) != pm) return false;
        chk++;
    }
    return chk > 0;
}

// A managed object whose class is System.Collections.Generic.List`1.
inline bool is_managed_list(uint64_t list) {
    if (!list) return false;
    uint64_t klass = rpm<uint64_t>(list);
    if (!klass) return false;
    uint64_t name = rpm<uint64_t>(klass + 0x10);
    uint64_t ns = rpm<uint64_t>(klass + 0x18);
    if (!name || !ns) return false;
    char nm[32]{}; read_cstr(name, nm, sizeof(nm));
    char nz[48]{}; read_cstr(ns, nz, sizeof(nz));
    return strcmp(nm, "List`1") == 0 && strcmp(nz, "System.Collections.Generic") == 0;
}

struct PlayerList {
    uint64_t list = 0;       // non-zero when players resolved (for check_lib)
    int count = 0;
    std::vector<uint64_t> players;  // PlayerManager instance pointers (all players)
    uint64_t local = 0;      // local player (GameControllerBase.static_fields + 0x10)
    uint64_t camNative = 0;  // native Camera* from local player's mouseLook chain
};

// ---- GameControllerBase: holds static singleton fields we need ----
//   static PlayerManager  <TRu> @ 0x10  (local player)
//   static CameraManager  <TRR> @ 0x38  (camera manager)
// Find the static_fields block of a class whose block holds a non-null pointer
// at +0x10 and +0x38 (GameControllerBase: local PlayerManager + CameraManager).
inline int find_gc_static_fields(uint64_t klass, uint64_t libS, uint64_t libE) {
    for (uint64_t off = 0x00; off <= 0xE8; off += 8) {
        uint64_t sf = rpm<uint64_t>(klass + off);
        if (!sf || sf < 0x10000 || (sf & 7)) continue;
        uint8_t t[8]; if (mem_read_n(sf, t, 8) != 8) continue;
        uint64_t a = rpm<uint64_t>(sf + 0x10);
        uint64_t b = rpm<uint64_t>(sf + 0x38);
        if (a && (a & 7) == 0 && b && (b & 7) == 0) return (int)off;
    }
    return 0;
}

inline uint64_t find_game_controller_base_class();

// IL2CPP pointer model is game/version dependent: object references read from memory may be
// ABSOLUTE (real virtual addresses) or RVA (offsets from libil2cpp.so base). We auto-detect
// once by reading the Il2CppClass's self-pointer (its first field): in the absolute model it
// equals pm (≈ lib + PM_RVA); in the RVA model it equals the small PM_RVA. g_rp_rel selects.
inline bool g_rp_rel = false;
// Base for relative pointers. In this build the TypeInfo slot and class fields store
// SMALL values (e.g. 0x20029257) that are offsets from a base B, NOT from lib (lib+value
// lands past module end). B is derived once: B = addr("PlayerManager") - nameRaw, where
// nameRaw is the slot's +0x10 field. rp() then resolves as B + value.
inline uint64_t g_rp_base = 0;
// Detect whether object references are stored ABSOLUTE (real pointers) or as image-relative
// RVAs (value + lib). We no longer trust a hard-coded TypeInfo RVA (it shifts every build);
// instead we inspect the PlayerManager Il2CppClass (pm, already resolved by name scan) and look
// at its static_fields slot: that pointer must point to a heap block (outside libil2cpp). If the
// raw stored qword is >= 4GB it is already absolute; if it is a small offset it is an RVA. We
// confirm by checking the candidate block actually holds managed references (heap pointers).
// Pointer model is now HARDCODED to absolute (typical Android IL2CPP). We only read the
// PlayerManager static_fields slot at the fixed 0xc0 offset to report the raw value; there
// is NO runtime scan. If the player list comes back empty, resolve_player_list() flips to
// RVA once as a single safety net.
inline void rp_detect(uint64_t pm) {
    if (!proc::lib || !pm) { g_rp_rel = false; return; }
    uint64_t v = rpm<uint64_t>(pm + IL2CPP_CLASS_STATIC_FIELDS);
    if (v >= 0x100000000ULL) g_rp_rel = false;   // stored qword is a real VA
    else if (v > 0x1000)     g_rp_rel = true;    // small value => image-relative RVA
    else                     g_rp_rel = false;   // default: absolute
    logger::f("[esp] model: pm=%llx sf@0xc0=%llx => rprel=%d",
        (unsigned long long)pm, (unsigned long long)v, (int)g_rp_rel);
}
inline uint64_t rp(uint64_t v) {
    if (!v) return 0;
    if (g_rp_base) return g_rp_base + v;
    return g_rp_rel ? (proc::lib + v) : v;
}

// A managed Il2CppClass has its own first qword point back to itself (klass self-reference),
// and the type name lives at +0x10. Validate/resolve a class from a TypeInfo RVA slot, which
// may store the Il2CppClass* directly OR an Il2CppType* whose klass field (+0) is the class.
inline bool class_name_matches(uint64_t cc, const char* name) {
    if (!cc) return false;
    uint64_t namePtr = rp(rpm<uint64_t>(cc + 0x10));
    if (!namePtr) return false;
    char buf[48] = { 0 };
    mem_read_n(namePtr, (uint8_t*)buf, (uint32_t)strlen(name));
    return strncmp(buf, name, strlen(name)) == 0;
}

// This il2cpp build stores an Il2CppType (type-index) in the TypeInfo slot, NOT a direct
// Il2CppClass pointer, so name-by-pointer resolution from the slot fails. Instead locate the
// class by scanning the module for its name string, then find the Il2CppClass whose +0x10
// (name field) references that string. Works for both RVA and absolute pointer models.
inline bool is_valid_name(const char* s) {
    for (int i = 0; i < 15; i++) {
        if (!s[i]) return i > 0;
        uint8_t c = (uint8_t)s[i];
        if (c < 0x20 || c > 0x7e) return false;
    }
    return true;
}

inline uint64_t find_class_by_name_range(const char* name, int idx, uint64_t libS, uint64_t libE, char* diag, uint64_t diagSz) {
    size_t nl = strlen(name);
    if (!libE || libE <= libS) libE = libS + 0x60000000;   // fallback: scan up to 1.5GB
    uint64_t sz = libE - libS;
    if (sz > 0x80000000) sz = 0x80000000;          // hard cap 2GB
    snprintf(diag, diagSz, "sz=%llx end=%llx", (unsigned long long)sz, (unsigned long long)(libE - libS));
    const uint32_t CH = 0x4000;
    // 1) collect ALL occurrences of the name string (the class-name one may not be the first)
    uint64_t occ[64]; uint64_t rva[64]; int noc = 0;
    for (uint64_t o = 0; o + 8 <= sz; o += CH) {
        uint8_t buf[CH];
        ssize_t got = mem_read_n(libS + o, buf, CH);
        if (got <= 0) continue;
        uint32_t n = (uint32_t)got;
        for (uint32_t i = 0; i + nl + 1 <= n; i++) {
            if (buf[i] == name[0] && memcmp(buf + i, name, nl) == 0 && buf[i + nl] == 0) {
                if (noc < 32) { occ[noc] = libS + o + i; rva[noc] = (libS + o + i) - libS; noc++; }
            }
        }
    }
    if (!noc) {
        snprintf(diag, diagSz, "noStr sz=%llx", (unsigned long long)sz);
        return 0;
    }
    // 2) back-ref scan: a qword referencing an occurrence, validated as a real Il2CppClass
    //    (its namespace field at +0x18 must be a readable printable string, e.g. "Oxide").
    uint64_t foundCand = 0; uint64_t foundNm = 0;
    bool firstMatch = false;
    for (uint64_t o = 0; o + 8 <= sz; o += CH) {
        uint8_t buf[CH];
        ssize_t got = mem_read_n(libS + o, buf, CH);
        if (got <= 0) continue;
        uint32_t n = (uint32_t)got;
        for (uint32_t i = 0; i + 8 <= n; i += 8) {
            uint64_t q; memcpy(&q, buf + i, 8);
            for (int j = 0; j < noc; j++) {
                if (q == occ[j] || q == rva[j]) {
                    uint64_t cand = (libS + o + i) - 0x10;
                    uint64_t nr = rpm<uint64_t>(cand + 0x18);
                    uint64_t nsp1 = rp(nr), nsp2 = nr;     // try RVA and absolute
                    if (!firstMatch) {
                        char s1[16] = { 0 }, s2[16] = { 0 };
                        if (nsp1) mem_read_n(nsp1, (uint8_t*)s1, 15);
                        if (nsp2) mem_read_n(nsp2, (uint8_t*)s2, 15);
                        snprintf(diag, diagSz,
                            "occ=%d cand=%llx nr=%llx n1='%s' n2='%s'",
                            j, (unsigned long long)cand, (unsigned long long)nr, s1, s2);
                        firstMatch = true;
                    }
                    // PRIMARY check: the class name field (+0x10) must point at `name`.
                    uint64_t nmPtr = rpm<uint64_t>(cand + 0x10);
                    uint64_t nmAbs = (nmPtr >= 0x100000000ULL) ? nmPtr : (libS + nmPtr);
                    char nmchk[32] = { 0 };
                    if (nmAbs >= libS && nmAbs < libE &&
                        mem_read_n(nmAbs, (uint8_t*)nmchk, (uint32_t)nl) == (ssize_t)nl &&
                        strncmp(nmchk, name, nl) == 0) {
                        foundCand = cand; foundNm = occ[j]; goto ncl_done;
                    }
                    // FALLBACK: namespace field (+0x18) is a readable printable string
                    for (int t = 0; t < 2; t++) {
                        uint64_t nsp = (t == 0) ? nsp1 : nsp2;
                        if (!nsp) continue;
                        char tmp[16] = { 0 };
                        if (mem_read_n(nsp, (uint8_t*)tmp, 15) == 15 && is_valid_name(tmp)) {
                            foundCand = cand; foundNm = occ[j]; goto ncl_done;
                        }
                    }
                }
            }
        }
    }
ncl_done:
    if (foundCand) {
        snprintf(diag, diagSz, "ok nm=%llx", (unsigned long long)foundNm);
    } else {
        if (!firstMatch) snprintf(diag, diagSz, "noRef occ=%d sz=%llx", noc, (unsigned long long)sz);
        return 0;
    }
    return foundCand;
}

inline uint64_t find_class_by_name(const char* name, int idx) {
    if (idx >= 0 && g_class_done[idx]) return g_class_cache[idx];   // scan at most ONCE
    if (idx >= 0) g_class_done[idx] = true;
    char* diag = g_cls_diag[idx];
    // IMPORTANT: after REATTACH the runtime lives at refmem::g_base (the 2nd libil2cpp
    // mapping, base[1]); proc::lib may be a stale earlier mapping whose copies of the
    // class structs are not the ones referenced by live instances. Prefer the reattached
    // base's scan first, fall back to proc::lib.
    uint64_t bases[4] = { refmem::g_base, proc::lib, 0, 0 };
    uint64_t ends[4] = { 0, proc::lib_end, 0, 0 };
    if (!ends[0]) ends[0] = refmem::g_base ? (refmem::g_base + 0x10000000ULL) : 0;  // 256MB span
    if (ends[1] && ends[1] <= bases[1]) ends[1] = bases[1] + 0x10000000ULL;
    int nb = 2;
    for (int bi = 0; bi < nb; bi++) {
        if (!bases[bi]) continue;
        if (bi > 0 && bases[bi] == bases[0]) continue;
        if (bi == 1 && bases[1] == bases[0] && ends[1] == ends[0]) continue;
        uint64_t c = find_class_by_name_range(name, idx, bases[bi], ends[bi], diag, 64);
        if (c) {
            g_class_cache[idx] = c; g_class_found[idx] = 1;
            logger::f("[cls] '%s' resolved cand=%llx (dbase=%llx) '%s'", name, (unsigned long long)c,
                (unsigned long long)bases[bi], diag);
            return c;
        }
        snprintf(diag, 64, "base%dx %s", bi, diag);
    }
    g_class_found[idx] = 0;
    logger::f("[cls] '%s' NOT resolved (%s)", name, diag);
    return 0;
}

inline uint64_t resolve_class_rva(uint64_t rva, const char* name) {
    int idx = 0;
    if (name && strcmp(name, "Camera") == 0) idx = 1;
    else if (name && strcmp(name, "GameControllerBase") == 0) idx = 2;
    else if (name && strcmp(name, "CameraManager") == 0) idx = 3;
    else if (name && strcmp(name, "UniversalCameraData") == 0) idx = 4;
    uint64_t c = find_class_by_name(name, idx);     // robust: scan for the name string
    if (c) return c;
    // fallback to slot-based resolution (legacy layouts)
    uint64_t raw = rpm<uint64_t>(proc::lib + rva);
    uint64_t a = rp(raw);
    if (!a) a = proc::lib + rva;
    if (class_name_matches(a, name)) return a;
    uint64_t k = rp(rpm<uint64_t>(a));
    if (k && class_name_matches(k, name)) return k;
    if (class_name_matches(proc::lib + rva, name)) return proc::lib + rva;
    return 0;
}

// (camera resolution uses the fixed fpManager/mouseLook chains above — no scanning)


// Detect the Il2CppClass.static_fields offset. The static_fields member is a HEAP pointer
// (the block lives outside libil2cpp.so, unlike most other qwords in the class), so we use
// that as a strong discriminator and scan a wide range (Unity 6 puts it well past 0xE8).
// We accept the slot whose block holds, at +0x00/+0x08/+0x10/+0x18, a plausible managed
// object/list pointer (also outside lib) with a sane element count. Returns the offset
// (stored in g_static_fields_off / g_dbg_field_off) or 0 if none matched.
// Detect Il2CppClass.static_fields offset. The static_fields member is the ONLY qword
// in the runtime Il2CppClass whose stored pointer resolves to a HEAP address (the per-class
// static block lives outside libil2cpp.so); every other field (image/name/type handles/...)
// stays inside the library. So we scan the class, take every candidate qword that resolves
// outside lib, and pick the one whose block contains the most managed references (heap
// pointers = the PlayerManager lists / serverName). Robust across Unity versions/ABIs.
// static_fields offset is now HARDCODED to 0xc0 (IL2CPP_CLASS_STATIC_FIELDS) — no scan.
inline int discover_pm_sf_off(uint64_t) { return (int)IL2CPP_CLASS_STATIC_FIELDS; }

// The three PlayerManager collections are MIXED types:
//   sleepingPlayerList / activePlayerList = PQ`1  (PriorityQueue)
//   clientPlayerList                      = List`1
// Traverse robustly: a collection object may be a List`1 directly, an Il2CppArray
// directly, or a PQ`1 whose backing (List`1/array) sits at any reference field.
// Every candidate container is validated against real player positions, so there is
// no memory-wide scan — only the known object's own fields are read.
struct GVec3 { float x, y, z; };
inline bool g_pos_ok(float x, float y, float z);
inline GVec3 get_player_position(uint64_t p);
// Enumerate players out of any container-like object. We accept a candidate container
// if its FIRST element's class pointer (+0) equals the PlayerManager Il2CppClass (pm) —
// a hard, position-independent check that filters out every non-player object. The
// backing may be List`1 / Queue`1 (items @+0x10, size @+0x18 or @+0x20), a raw array,
// or a Dictionary<,PlayerManager> (values @ entry+0x10). Stride 8/16/0x18 covers all.
// Enumerate a List`1 / Il2CppArray container: _items (array) @ +0x10, _size @ +0x18,
// elements @ array+0x20. If _items is not a valid array, the object itself is treated
// as a raw Il2CppArray (max_length @ +0x18, elements @ +0x20). Every element is kept
// only if its class (+0) is PlayerManager. Fixed offsets only — no scanning.
inline void enum_list(uint64_t list, uint64_t pm, std::vector<uint64_t>& out) {
    if (!list) return;
    uint64_t items = rpm<uint64_t>(list + IL2CPP_LIST_ITEMS);   // +0x10
    int size = rpm<int>(list + IL2CPP_LIST_SIZE);                // +0x18
    if (!items || size <= 0 || size > 1024) {
        int ml = rpm<int>(list + IL2CPP_LIST_SIZE);              // raw array max_length
        if (ml > 0 && ml <= 1024) { items = list; size = ml; }
        else return;
    }
    for (int i = 0; i < size; i++) {
        uint64_t p = rpm<uint64_t>(items + IL2CPP_ARRAY_FIRST_ELEMENT + (uint64_t)i * 8);
        if (p) {
            uint64_t k = rpm<uint64_t>(p);   // klass field: absolute ptr OR rva
            if (k == pm || k == PM_RVA || k == (pm - proc::lib)) out.push_back(p);
        }
    }
}
// sleepingPlayerList / activePlayerList are PQ`1 whose backing (Dsk = EI`1) sits at a
// reference field (offset varies by Unity version). Try the likely candidates; enum_list
// validates each element by its class, so a wrong backing yields nothing and is skipped.
inline void enum_pq(uint64_t pq, uint64_t pm, std::vector<uint64_t>& out) {
    if (!pq) return;
    for (uint64_t bo : { 0x18ULL, 0x20ULL, 0x28ULL }) {
        uint64_t backing = rpm<uint64_t>(pq + bo);
        if (backing) {
            size_t before = out.size();
            enum_list(backing, pm, out);
            if (out.size() > before) return;   // working backing found
        }
    }
}
inline void collect_players_list(uint64_t field, uint64_t pm, std::vector<uint64_t>& out) {
    enum_list(rp(rpm<uint64_t>(field)), pm, out);
}

// Walk local player -> camera -> native Camera object. Tries both known chains:
//   mouseLook @ +0x70  -> cam @ +0x20 -> m_CachedPtr @ +0x10
//   fpManager @ +0x90  -> cam @ +0x20 -> m_CachedPtr @ +0x10
// Walk local player -> camera -> native Camera object, fixed offsets only:
//   fpManager @ +0x90 -> cam @ +0x20 -> m_CachedPtr @ +0x10
//   mouseLook @ +0x70 -> cam @ +0x20 -> m_CachedPtr @ +0x10
// Native Camera* candidates from a player. Two possible layouts (from dump.cs):
//   hZD (fpManager) -> OrbitCamera (hZd) @ +0x20 -> Camera @ +0x20 -> m_CachedPtr @ +0x10
//   fpManager (hZd) -> Camera @ +0x20 -> m_CachedPtr @ +0x10   (single hop)
// and the mouseLook @ +0x70 -> Camera @ +0x20 path. For every camera-ish value we emit
// both the managed-Camera->native (via m_CachedPtr @ +0x10) and the value as-is (in case
// it is already the native Camera*). The caller keeps the one with finite matrices.
inline void camera_native_candidates(uint64_t player, std::vector<uint64_t>& out) {
    if (!player || (player & 7)) return;
    auto push = [&](uint64_t v) {
        if (!v) return;
        out.push_back(rp(rpm<uint64_t>(v + O_CAM_CACHEDPTR))); // managed Camera -> native
        out.push_back(v);                                       // already native Camera
    };
    uint64_t fp = rp(rpm<uint64_t>(player + O_FP_MANAGER));     // fpManager
    if (fp) {
        uint64_t orbit = rp(rpm<uint64_t>(fp + O_ML_CAM));      // fp -> OrbitCamera/hZd @0x20
        if (orbit) push(rp(rpm<uint64_t>(orbit + O_ML_CAM)));   // hZd -> Camera @0x20 (2-hop)
        push(orbit);                                            // orbit itself may be the Camera (1-hop)
    }
    uint64_t ml = rp(rpm<uint64_t>(player + O_MOUSELOOK));      // mouseLook
    if (ml) push(rp(rpm<uint64_t>(ml + O_ML_CAM)));
}

inline bool matrix_finite(uint64_t addr) {
    if (!addr || (addr & 7)) return false;
    for (int i = 0; i < 16; i++) {
        float f = rpm<float>(addr + (uint64_t)i * 4);
        if (!std::isfinite(f) || std::fabs(f) > 1e6f) return false;
    }
    return true;
}

// Pick the first native Camera* whose projection+view matrices are finite.
inline uint64_t camera_native_pick(uint64_t player) {
    std::vector<uint64_t> cands;
    camera_native_candidates(player, cands);
    for (uint64_t c : cands) {
        if (!c || (c & 7)) continue;
        if (matrix_finite(c + CAMERA_PROJECTION_MATRIX) &&
            matrix_finite(c + CAMERA_VIEW_MATRIX)) return c;
    }
    return 0;
}

inline bool g_pos_ok(float x, float y, float z) {
    return std::isfinite(x) && std::isfinite(y) && std::isfinite(z) &&
           (fabsf(x) > 0.01f || fabsf(y) > 0.01f || fabsf(z) > 0.01f) &&
           fabsf(x) < 1e6f && fabsf(y) < 1e6f && fabsf(z) < 1e6f;
}
    // World position of a PlayerManager. Primary: lastTickPosition (Vector3 @ 0x1C8),
// the player's synced world position (reference PM_POSITION). Fallback: worldCameraRoot
// Transform's world position (Transform @ 0x68 -> world pos @ 0x68 inside the Transform).
inline GVec3 get_player_position(uint64_t p) {
    GVec3 r{ 0, 0, 0 };
    if (!p) return r;
    GVec3 w = rpm<GVec3>(p + game_offsets::PLAYER_POSITION);   // lastTickPosition @ 0x1C8 (Dump14)
    if (g_pos_ok(w.x, w.y, w.z)) return w;
    uint64_t t = rpm<uint64_t>(p + game_offsets::PLAYER_WORLDCAMERA_ROOT);   // Transform @ 0x68
    if (t) {
        GVec3 wc = rpm<GVec3>(t + 0x90);   // Transform.m_LocalPosition (reference cheat)
        if (g_pos_ok(wc.x, wc.y, wc.z)) return wc;
        GVec3 wv = rpm<GVec3>(t + 0x68);   // Transform world position
        if (g_pos_ok(wv.x, wv.y, wv.z)) return wv;
    }
    return r;
}

// ============================================================================
// Reference cheat (esp_logic.cpp) — working reader ported 1:1. The old version
// worked, only the RVAs are stale for the current build. Logic:
//   (1) TypeInfo slot candidate, VALIDATED by class name ("PlayerManager"/"Oxide")
//       or by finding a validated static-fields block;
//   (2) fallback find_class_by_method: scan for a qword == lib+METHOD_RVA
//       (the MethodInfo), classes at MethodInfo+{0x18,0x20,0x28,0x30};
//   (3) static_fields discovered by scanning class+0x80..0x200 against a
//       validated List (items+size by element class == pm_class);
//   (4) player list read from *(sf + 0x10), elements enumerated from array.
// ============================================================================

inline uint64_t rd_ref(uint64_t a) { return refmem::read_mem<uint64_t>(a); }

inline std::string ref_str(uint64_t addr) {
    std::string s;
    if (!addr) return s;
    char b[96];
    memset(b, 0, sizeof(b));
    ssize_t n = mem_read_n(addr, b, sizeof(b) - 1);
    if (n <= 0) return s;
    b[sizeof(b) - 1] = 0;
    s = b;
    return s;
}
inline bool ref_str_eq(uint64_t addr, const char* exp) { return ref_str(addr) == exp; }

inline bool is_pm_class(uint64_t klass) {
    if (!klass) return false;
    uint64_t name = rd_ref(klass + 0x10);
    uint64_t ns   = rd_ref(klass + 0x18);
    return ref_str_eq(name, "PlayerManager") && ref_str_eq(ns, "Oxide");
}

inline bool pm_list_ok(uint64_t list, uint64_t pm_class) {
    if (!list || !pm_class) return false;
    uint64_t items = rd_ref(list + game_offsets::IL2CPP_LIST_ITEMS);
    int32_t count = refmem::read_mem<int32_t>(list + game_offsets::IL2CPP_LIST_SIZE);
    if (!items || count < 0 || count > 512) return false;
    int checked = 0;
    for (int32_t i = 0; i < count && checked < 4; i++) {
        uint64_t p = rd_ref(items + game_offsets::IL2CPP_ARRAY_FIRST_ELEMENT + (uint64_t)i * 8);
        if (!p) continue;
        if (rd_ref(p) != pm_class) return false;
        checked++;
    }
    return count == 0 || checked > 0;
}

inline uint64_t find_pm_static_fields(uint64_t pm_class) {
    if (!pm_class) return 0;
    for (uint64_t off = 0x80; off <= 0x200; off += 8) {
        uint64_t sf = rd_ref(pm_class + off);
        if (!sf) continue;
        uint64_t list = rd_ref(sf + game_offsets::PLAYER_MANAGER_STATIC_FIELDS_LIST);
        if (pm_list_ok(list, pm_class)) return sf;
    }
    return 0;
}

struct RefRange { uint64_t s, e; };

inline std::vector<RefRange> ref_method_ranges() {
    std::vector<RefRange> v;
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", proc::pid);
    FILE* f = fopen(path, "r");
    if (!f) return v;
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        uint64_t s = 0, e = 0;
        char perm[5];
        if (sscanf(line, "%lx-%lx %4s", &s, &e, perm) != 3) continue;
        if (perm[0] != 'r' || perm[2] == 'x') continue;
        if (e - s < 0x1000 || e - s > 0x20000000) continue;
        bool il   = strstr(line, "libil2cpp.so");
        bool anon = strstr(line, "/") == nullptr &&
            strstr(line, "[stack") == nullptr &&
            strstr(line, "[vdso") == nullptr &&
            strstr(line, "[vvar") == nullptr;
        if (il || anon) v.push_back({ s, e });
    }
    fclose(f);
    return v;
}

inline uint64_t find_pm_class_by_method(uint64_t method_rva) {
    if (!refmem::g_base || !method_rva) return 0;
    uint64_t method_ptr = refmem::g_base + method_rva;
    auto ranges = ref_method_ranges();
    const size_t cs = 0x20000;
    std::vector<uint8_t> buf(cs);
    const uint64_t clsoff[] = { 0x18, 0x20, 0x28, 0x30 };
    for (auto& rg : ranges) {
        for (uint64_t a = rg.s; a < rg.e; a += cs) {
            size_t remain = (size_t)(rg.e - a);
            size_t want = remain < cs ? remain : cs;
            ssize_t n = mem_read_n(a, buf.data(), want);
            if (n <= 0) continue;
            for (size_t i = 0; i + 8 <= (size_t)n; i += 8) {
                uint64_t v = 0;
                memcpy(&v, buf.data() + i, 8);
                if (v != method_ptr) continue;
                uint64_t mi = a + i;
                for (uint64_t o : clsoff) {
                    uint64_t k = rd_ref(mi + o);
                    if (!k) continue;
                    if (ref_str_eq(rd_ref(k + 0x10), "PlayerManager") &&
                        ref_str_eq(rd_ref(k + 0x18), "Oxide")) return k;
                }
            }
        }
    }
    return 0;
}

inline PlayerList resolve_player_list() noexcept {
    PlayerList R;

    refmem::open_mem();
    if (!refmem::g_base) refmem::g_base = refmem::get_base_lib();
    if (!refmem::g_base) refmem::g_base = proc::lib;
    uint64_t base = refmem::g_base;
    if (!base) return R;

    static bool g_ref_diag = false;
    if (!g_ref_diag) {
        g_ref_diag = true;
        {
            char cmdline[256] = { 0 };
            char cp[64];
            snprintf(cp, sizeof(cp), "/proc/%d/cmdline", proc::pid);
            FILE* cf = fopen(cp, "r");
            if (cf) {
                size_t nb = fread(cmdline, 1, sizeof(cmdline) - 1, cf);
                fclose(cf);
                cmdline[nb] = 0;
            }
            logger::f("[esp] REFDIAG: our pid=%d cmd='%s' lib=%llx",
                proc::pid, cmdline, (unsigned long long)base);
        }

        int best_pid = 0;
        uint64_t best_base = 0, best_slot = 0;
        (void)best_slot;
        DIR* d2 = opendir("/proc");
        if (d2) {
            struct dirent* de;
            while ((de = readdir(d2))) {
                if (de->d_type != DT_DIR) continue;
                int pid = 0;
                bool num = true;
                for (const char* c = de->d_name; *c; c++) {
                    if (*c < '0' || *c > '9') { num = false; break; }
                    pid = pid * 10 + (*c - '0');
                }
                if (!num) continue;
                char mp[64];
                snprintf(mp, sizeof(mp), "/proc/%d/maps", pid);
                FILE* mf = fopen(mp, "r");
                if (!mf) continue;
                std::vector<uint64_t> bases;
                {
                    char line[512];
                    while (fgets(line, sizeof(line), mf)) {
                        if (!strstr(line, "libil2cpp.so")) continue;
                        uint64_t s = 0, e = 0, off = 0;
                        char perm[5];
                        if (sscanf(line, "%lx-%lx %4s %lx", &s, &e, perm, &off) != 4) continue;
                        if (off == 0) bases.push_back(s);
                    }
                }
                fclose(mf);
                if (bases.empty()) continue;

                char mm[64];
                snprintf(mm, sizeof(mm), "/proc/%d/mem", pid);
                int mfd = open(mm, O_RDONLY);
                if (mfd < 0) {
                    logger::f("[esp]   pid=%d libil2cpp x%zu bases FAIL(openmem)",
                        pid, bases.size());
                    continue;
                }
                for (size_t bi = 0; bi < bases.size(); bi++) {
                    uint64_t pbase = bases[bi];
                    uint64_t slotv = 0, np = 0, nsp = 0;
                    char nm[40] = "", ns2[48] = "";
                    bool rok = false;
                    if (pread(mfd, &slotv, 8, (off_t)(pbase + game_offsets::PLAYER_MANAGER_TYPEINFO_RVA)) == 8) {
                        rok = true;
                        if (pread(mfd, &np, 8, (off_t)(slotv + 0x10)) == 8 && np) {
                            ssize_t rn = pread(mfd, nm, sizeof(nm) - 1, (off_t)np);
                            if (rn > 0) nm[rn] = 0;
                        }
                        if (pread(mfd, &nsp, 8, (off_t)(slotv + 0x18)) == 8 && nsp) {
                            ssize_t rn = pread(mfd, ns2, sizeof(ns2) - 1, (off_t)nsp);
                            if (rn > 0) ns2[rn] = 0;
                        }
                    }
                    logger::f("[esp]   pid=%d base[%zu]=%llx slot=%llx name='%s' ns='%s' %s",
                        pid, bi, (unsigned long long)pbase, (unsigned long long)slotv,
                        nm, ns2, rok ? "OK" : "FAIL");
                    if (strcmp(nm, "PlayerManager") == 0 && strcmp(ns2, "Oxide") == 0 && !best_pid) {
                        best_pid = pid;
                        best_base = pbase;
                        best_slot = slotv;
                    }
                }
                close(mfd);
            }
            closedir(d2);
        }

        if (best_pid) {
            if (best_pid != proc::pid || best_base != base) {
                logger::f("[esp] REATTACH pid=%d base=%llx slot=%llx",
                    best_pid, (unsigned long long)best_base, (unsigned long long)best_slot);
                proc::pid = best_pid;
                refmem::g_base = best_base;
                refmem::open_mem();
                base = best_base;
            } else {
                logger::f("[esp] our pid/base is correct");
            }
        } else {
            logger::f("[esp] NO process has a valid PlayerManager slot (stale offsets or mem denied)");
        }
    }

    uint64_t cand = refmem::read_mem<uint64_t>(base + game_offsets::PLAYER_MANAGER_TYPEINFO_RVA);
    uint64_t pm = 0;
    std::string why;

    if (cand) {
        char cn[40], cn2[56];
        char* pname = cn; char* pns = cn2;
        mem_read_n(cand + 0x10, &cn, sizeof(cn) - 1); cn[sizeof(cn) - 1] = 0;
        mem_read_n(cand + 0x18, &cn2, sizeof(cn2) - 1); cn2[sizeof(cn2) - 1] = 0;
        uint64_t name_ptr = rd_ref(cand + 0x10);
        uint64_t ns_ptr   = rd_ref(cand + 0x18);
        {
            static double sv_last = 0;
            double sv_now = (double)time(nullptr);
            if (sv_now - sv_last > 5.0 || name_ptr != g_sv_last_name) {
                g_sv_last_name = name_ptr;
                sv_last = sv_now;
                logger::f("[esp] slotval=%llx: name[%llx]='%s' ns[%llx]='%s'",
                    (unsigned long long)cand, (unsigned long long)name_ptr, cn,
                    (unsigned long long)ns_ptr, cn2);
            }
        }
        if (is_pm_class(cand))       { pm = cand; why = "typeinfo(name)"; }
        else if (find_pm_static_fields(cand)) { pm = cand; why = "typeinfo(sf)"; }
        else why = "typeinfo rejected";
        (void)pname; (void)pns;
    } else {
        why = "typeinfo empty";
    }

    if (!pm && game_offsets::PLAYER_MANAGER_METHOD_RVA != 0) {
        uint64_t k = find_pm_class_by_method(game_offsets::PLAYER_MANAGER_METHOD_RVA);
        if (k) { pm = k; why = "method"; }
        else why = "method scan failed";
    }

    static double rs_last = 0;
    {
        double rs_now = (double)time(nullptr);
        if (rs_now - rs_last > 5.0) {
            rs_last = rs_now;
            logger::f("[esp] resolve: base=%llx slot=%llx pm=%llx (%s)",
                (unsigned long long)base, (unsigned long long)cand,
                (unsigned long long)pm, why.c_str());
        }
    }
    if (!pm) {
        if (game_offsets::PLAYER_MANAGER_METHOD_RVA == 0)
            snprintf(g_pm_err, sizeof(g_pm_err),
                "class off (%s); set PLAYER_MANAGER_METHOD_RVA (current dump.cs)",
                why.c_str());
        else
            snprintf(g_pm_err, sizeof(g_pm_err), "class off (%s)", why.c_str());
        return R;
    }
    g_dbg_pm = pm; g_dbg_kD = pm;
    g_rp_base = 0;
    g_rp_rel  = false;

    uint64_t sf = find_pm_static_fields(pm);
    if (!sf) {
        snprintf(g_pm_err, sizeof(g_pm_err), "class=%llx sf-not-found",
            (unsigned long long)pm);
        logger::f("[esp] ERR: class=%llx static_fields NOT found in 0x80..0x200",
            (unsigned long long)pm);
        return R;
    }
    g_dbg_sf = sf;

    uint64_t list = rd_ref(sf + game_offsets::PLAYER_MANAGER_STATIC_FIELDS_LIST);
    if (!pm_list_ok(list, pm)) {
        snprintf(g_pm_err, sizeof(g_pm_err), "class=%llx sf=%llx list-bad",
            (unsigned long long)pm, (unsigned long long)sf);
        logger::f("[esp] ERR: sf=%llx list=%llx invalid",
            (unsigned long long)sf, (unsigned long long)list);
        return R;
    }

    uint64_t items = rd_ref(list + game_offsets::IL2CPP_LIST_ITEMS);
    int32_t count = refmem::read_mem<int32_t>(list + game_offsets::IL2CPP_LIST_SIZE);
    std::vector<uint64_t> u;
    for (int32_t i = 0; i < count; i++) {
        uint64_t p = rd_ref(items + game_offsets::IL2CPP_ARRAY_FIRST_ELEMENT + (uint64_t)i * 8);
        if (p) u.push_back(p);
    }

    R.players = u;
    g_dbg_maxn = (int)u.size();
    g_dbg_n2 = (int)u.size();
    if (!u.empty() && game_offsets::PLAYER_LIST_FIRST_IS_LOCAL)
        R.local = u[0];
    g_dbg_local = R.local;
    R.count = (int)u.size();
    R.list = (R.count > 0) ? 1 : 0;
    snprintf(g_pm_err, sizeof(g_pm_err), "OK pm=%llx sf=%llx sf_off=0x%llx n=%d (%s)",
        (unsigned long long)pm, (unsigned long long)sf,
        (unsigned long long)game_offsets::IL2CPP_CLASS_STATIC_FIELDS,
        (int)u.size(), why.c_str());
    static double pr_last = 0;
    {
        double pr_now = (double)time(nullptr);
        if (pr_now - pr_last > 5.0) {
            pr_last = pr_now;
            logger::f("[esp] Players=%d local=%llx pm=%llx sf=%llx (%s)",
                (int)u.size(), (unsigned long long)R.local,
                (unsigned long long)pm, (unsigned long long)sf, why.c_str());
        }
    }
    return R;
}
