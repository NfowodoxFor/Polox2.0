#pragma once

#include "game.hpp"
#include "../other/vector3.h"
#include "../other/string.h"
#include "../game/math.hpp"
#include "../protect/oxorany.hpp"
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <ctime>

namespace player {

    // World position. Verified @ 0x1E0 (live) for this build.
    inline Vector3 position(uint64_t p) noexcept {
        Vector3 v = rpm<Vector3>(p + oxorany(0x1E0));
        if (g_pos_ok(v.x, v.y, v.z)) return v;
        return v;
    }

    // Mirror NetworkBehaviour.isLocalPlayer (VERIFY offset 0x14 for this build).
    inline bool is_local(uint64_t p) noexcept {
        return rpm<bool>(p + oxorany(0x14));
    }

    // Nickname: DisplayName via PlayerVitals chain (reference):
//   p->vitals @ 0xC8 -> huc (Entity) @ 0x68 -> huC.DisplayName (string) @ 0x88.
// il2cpp String fields are REFERENCES: the field holds a pointer to the
// Il2CppString object, so we dereference first, then read the string struct.
    inline read_string name(uint64_t p) noexcept {
        read_string s{};
        uint64_t sp = 0;
        uint64_t vitals = rpm<uint64_t>(p + oxorany(0xC8));
        if (vitals) {
            uint64_t huc = rpm<uint64_t>(vitals + oxorany(0x68));
            if (huc) {
                uint64_t sp = rpm<uint64_t>(huc + oxorany(0x88));
                if (sp) s = rpm<read_string>(sp);
            }
        }
        if (s.as_utf8().empty()) {
            sp = rpm<uint64_t>(p + oxorany(0x278));   // userID (fallback)
            if (sp) s = rpm<read_string>(sp);
        }
        if (s.as_utf8().empty()) {
            sp = rpm<uint64_t>(p + oxorany(0x130));   // nicklabel (alt name)
            if (sp) s = rpm<read_string>(sp);
        }
        return s;
    }

    // Team: teamName SyncVar string @ 0x280 (a reference to the string object).
    inline read_string team_name(uint64_t p) noexcept {
        read_string s{};
        uint64_t sp = rpm<uint64_t>(p + oxorany(0x280));
        if (sp) s = rpm<read_string>(sp);
        return s;
    }

    // Health: reference chain — vitals @ 0xC8 -> huc (Entity) @ 0x68 -> huc.Health
    // (observable wrapper) @ 0x98 -> current value @ +0x0 (fallback +0x10).
    // maxHealth = vitals + 0x88 (GenericVitals.m_MaxHealth). Returns -1 when
    // unreadable so the renderer can skip the bar without hiding valid entities.
    inline int health(uint64_t p) noexcept {
        uint64_t vitals = rpm<uint64_t>(p + oxorany(0xC8));
        if (vitals) {
            float maxHealth = rpm<float>(vitals + oxorany(0x88));
            if (!(maxHealth > 0.f) || maxHealth > 10000.f) maxHealth = 100.f;
            uint64_t huc = rpm<uint64_t>(vitals + oxorany(0x68));
            if (huc) {
                uint64_t healthWrap = rpm<uint64_t>(huc + oxorany(0x98));
                if (healthWrap) {
                    float v0 = rpm<float>(healthWrap + oxorany(0x0));
                    float v1 = rpm<float>(healthWrap + oxorany(0x10));
                    float hv = (v0 >= 0.f && v0 <= maxHealth * 2.f + 1.f) ? v0 : v1;
                    if (hv < 0.f || hv > maxHealth * 2.f) hv = maxHealth;
                    return (int)hv;
                }
            }
        }
        return -1;
    }

    // ---- matrices / camera (based on proven Gandon Oxide logic) ----

    inline bool matrix_ok(const matrix& m) noexcept {
        const float* f = reinterpret_cast<const float*>(&m);
        bool nz = false;
        for (int i = 0; i < 16; i++) {
            if (!std::isfinite(f[i]) || std::fabs(f[i]) > 1e6f) return false;
            if (std::fabs(f[i]) > 1e-6f) nz = true;
        }
        return nz;
    }

    // row-major multiply a*b  (Gandon: mat_mul(projection, view))
    inline matrix mat_mul(const matrix& A, const matrix& B) noexcept {
        const float* a = reinterpret_cast<const float*>(&A);
        const float* b = reinterpret_cast<const float*>(&B);
        matrix R{}; float* r = reinterpret_cast<float*>(&R);
        for (int row = 0; row < 4; row++)
            for (int col = 0; col < 4; col++) {
                float s = 0.f;
                for (int k = 0; k < 4; k++) s += a[row * 4 + k] * b[k * 4 + col];
                r[row * 4 + col] = s;
            }
        return R;
    }

    // managed UnityEngine.Camera -> view*projection (row-major).
    // native pointer = m_CachedPtr @ 0x10; view @ 0x2F8; proj @ 0x140.
    inline matrix camera_vp(uint64_t managed_cam) noexcept {
        matrix out{};
        if (!managed_cam) return out;
        uint64_t native = rpm<uint64_t>(managed_cam + oxorany(0x10));
        if (!native) return out;
        matrix view = rpm<matrix>(native + oxorany(0x2F8));
        matrix proj = rpm<matrix>(native + oxorany(0x140));
        if (!matrix_ok(view) || !matrix_ok(proj)) return out;
        return mat_mul(proj, view);
    }

    // Structurally locate the active camera's view*projection matrix by
    // scanning native heap for a VIEW matrix (m44~=1, m14=m24=m34=m41=m42=m43~=0)
    // whose projection matrix sits 0x1B8 bytes before it (proj@0x140, view@0x2F8).
    // Validated by projecting `localPos` to screen center when provided. No
    // class name or RVA is needed.
    inline matrix camera_view_proj(Vector3 localPos) noexcept {
        static matrix cache{};
        static uint64_t cache_t = 0;
        static bool cache_ok = false;
        static std::vector<std::pair<uint64_t,uint64_t>>* c_ranges = nullptr;
        static size_t c_ridx = 0;
        static uint64_t c_roff = 0;
        static std::vector<matrix>* c_cands = nullptr;
        static int c_pid = -1;

        uint64_t now = (uint64_t)time(nullptr);
        if (cache_ok && now - cache_t < 10) return cache;
        if (proc::lib == 0 || !get_module_bounds("libil2cpp.so", g_dbg_mod_start, g_dbg_mod_end)) {
            cache_ok = false; cache_t = now; return cache;
        }
        if (!c_cands) c_cands = new std::vector<matrix>();
        if (!c_ranges || c_pid != proc::pid) {
            if (c_ranges) delete c_ranges;
            c_ranges = new std::vector<std::pair<uint64_t,uint64_t>>(get_heap_ranges());
            c_pid = proc::pid; c_ridx = 0; c_roff = 0; c_cands->clear();
        }

        const size_t chunksz = 0x40000;
        static std::vector<uint8_t> buf(chunksz);
        double t0 = scan_clock();
        bool exhausted = false;
        while (c_ridx < c_ranges->size()) {
            auto& r = (*c_ranges)[c_ridx];
            uint64_t total = r.second - r.first;
            if (c_roff >= total) { c_ridx++; c_roff = 0; continue; }
            uint64_t base = r.first + c_roff;
            uint64_t want = (total - c_roff < chunksz) ? (total - c_roff) : chunksz;
            ssize_t n = mem_read_n(base, buf.data(), want);
            c_roff += chunksz;
            if (n >= 64) {
                size_t rn = (size_t)n;
                for (size_t i = 0; i + 64 <= rn; i += 4) {
                    float m11, m44;
                    memcpy(&m11, buf.data() + i, 4);
                    memcpy(&m44, buf.data() + i + 60, 4);
                    if (!std::isfinite(m11) || !std::isfinite(m44)) continue;
                    if (std::fabs(m44 - 1.f) > 1e-2f) continue;     // view: m44 == 1
                    if (std::fabs(m11) < 1e-3f) continue;
                    float f[16]; memcpy(f, buf.data() + i, 64);
                    // View matrix (Unity column-major in memory): affine, so the
                    // LAST COLUMN top-three (m14/m24/m34) are ~0 and m44==1. The
                    // camera translation lives in the last ROW (m41/m42/m43) and is
                    // NONZERO -> do NOT require those to be zero.
                    if (std::fabs(f[3]) > 1e-2f) continue;   // m14
                    if (std::fabs(f[7]) > 1e-2f) continue;   // m24
                    if (std::fabs(f[11]) > 1e-2f) continue;  // m34
                    if (std::fabs(f[5]) < 1e-3f) continue;   // m22
                    if (std::fabs(f[10]) < 1e-3f) continue;  // m33
                    uint64_t V = base + i;
                    matrix view; memcpy(&view, f, 64);
                    // Projection matrix sits at a fixed (engine-version-dependent)
                    // offset from the view matrix inside the native Camera struct.
                    // Try several candidate spacings so a stale/ARM64 offset from
                    // another build can't break camera discovery.
                    static const int64_t proj_offs[] = {
                        -0x1B8, -0x140, 0x140, -0x100, 0x100,
                        -0x180, 0x180, -0xC0, 0xC0, -0x200, 0x200
                    };
                    for (int64_t po : proj_offs) {
                        int64_t addr = (int64_t)V + po;
                        if (addr < 0x1000) continue;
                        matrix proj = rpm<matrix>((uint64_t)addr);
                        if (!matrix_ok(proj)) continue;
                        if (!(std::fabs(proj.m44) < 0.01f && std::fabs(proj.m34) > 0.01f)) continue;
                        g_dbg_cam++;
                        c_cands->push_back(mat_mul(proj, view));
                        if (c_cands->size() >= 64) { exhausted = true; break; }
                    }
                    if (exhausted) break;
                }
            }
            if (scan_clock() - t0 > 0.3) break;
            if (exhausted) break;
        }
        if (c_ridx >= c_ranges->size()) exhausted = true;

        if (!c_cands->empty()) {
            matrix chosen = (*c_cands)[0];
            bool validated = false;
            if (localPos.x != 0.f || localPos.y != 0.f || localPos.z != 0.f) {
                float bestd = 1e18f; int besti = -1;
                for (size_t k = 0; k < c_cands->size(); k++) {
                    ImVec2 s; bool ok = world_to_screen(localPos, (*c_cands)[k], s);
                    if (ok && s.x >= 0 && s.x <= g_sw && s.y >= 0 && s.y <= g_sh) {
                        float dx = s.x - g_sw * 0.5f, dy = s.y - g_sh * 0.5f;
                        float d = dx * dx + dy * dy;
                        if (d < bestd) { bestd = d; besti = (int)k; }
                    }
                }
                if (besti >= 0) { chosen = (*c_cands)[besti]; validated = true; }
            } else {
                validated = true;  // no local pos yet; take first candidate
            }
            if (validated) {
                cache = chosen; cache_t = now; cache_ok = true;
                c_cands->clear(); c_ridx = 0; c_roff = 0;
                return chosen;
            }
        }
        if (exhausted) { c_ridx = 0; c_roff = 0; c_cands->clear(); }
        cache_t = now; cache_ok = false;
        return cache;
    }
}
