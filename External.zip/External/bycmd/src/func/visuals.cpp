#include "visuals.hpp"
#include "../game/game.hpp"
#include "../game/math.hpp"
#include "../game/player.hpp"
#include "../game/camera.hpp"
#include "../other/memory.hpp"
#include "../ui/theme/theme.hpp"
#include "../ui/cfg.hpp"
#include "../protect/oxorany.hpp"
#include "imgui.h"
#include "../ui/log.hpp"
#include <cmath>
#include <algorithm>
#include <cstdio>
#include <vector>

extern ImFont* espFont;

void visuals::draw() {
    camera::g_sw = g_screen_w;
    camera::g_sh = g_screen_h;

    bool any = cfg::esp::box || cfg::esp::name || cfg::esp::health || cfg::esp::distance || cfg::esp::skeleton || cfg::aimbot::enabled;

    PlayerList pl{};
    uint64_t list = 0, items = 0;
    int count = 0;
    if (any) {
        pl = resolve_player_list();
        list = pl.list; count = pl.count;
    }

    // ---- ALWAYS-ON debug (top-left of overlay) ----
    {
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        ImFont* f = (espFont ? espFont : ImGui::GetFont());
        char buf[256];
        uint32_t magic = rpm<uint32_t>(proc::lib);
        snprintf(buf, sizeof(buf),
                 "pid:%d lib:%llx magic:%lx (0=CHTENIE NE RABOTAET) arch:%s",
                 (int)proc::pid, (unsigned long long)proc::lib, (unsigned long)magic,
                 (rpm<uint16_t>(proc::lib + oxorany(0x12)) == 0x3E) ? "x86_64" : "?");
        dl->AddText(f, 14.f, ImVec2(20.f, 60.f), IM_COL32(0, 255, 128, 255), buf);

        snprintf(buf, sizeof(buf), "kD:%llx kD2:%llx sf:%llx pl:%d",
                 (unsigned long long)g_dbg_kD, (unsigned long long)g_dbg_kD2,
                 (unsigned long long)g_dbg_sf, count);
        dl->AddText(f, 14.f, ImVec2(20.f, 78.f), IM_COL32(0, 255, 128, 255), buf);

        snprintf(buf, sizeof(buf), "L0:%llx n0:%d | L1:%llx n1:%d | L2:%llx n2:%d | loc:%llx cam:%d",
                 (unsigned long long)g_dbg_lst[0], g_dbg_n0,
                 (unsigned long long)g_dbg_lst[1], g_dbg_n1,
                 (unsigned long long)g_dbg_lst[2], g_dbg_n2,
                 (unsigned long long)g_dbg_local, g_dbg_camok);
        dl->AddText(f, 14.f, ImVec2(20.f, 96.f), IM_COL32(255, 220, 0, 255), buf);

        snprintf(buf, sizeof(buf), "cam:%s cands:%d best:%llu su:%llu p@%llx v@%llx ord:%d tr:%d",
                    camera::g_valid ? "OK" : "0",
                    camera::g_dbg_cands,
                    (unsigned long long)camera::g_dbg_best,
                    (unsigned long long)camera::g_dbg_struct,
                    (unsigned long long)camera::g_proj_addr,
                    (unsigned long long)camera::g_view_addr,
                    camera::g_order,
                    camera::g_trans);
        dl->AddText(f, 14.f, ImVec2(20.f, 114.f), IM_COL32(0, 255, 128, 255), buf);

        snprintf(buf, sizeof(buf), "pm:%llx sf80:%llx sf88:%llx sz:%u nm:%s ns:%s",
                     (unsigned long long)g_dbg_pm,
                     (unsigned long long)g_dbg_sf80,
                     (unsigned long long)g_dbg_sf88,
                     g_dbg_sfsize,
                     g_dbg_name, g_dbg_ns);
        dl->AddText(f, 14.f, ImVec2(20.f, 114.f), IM_COL32(255, 200, 0, 255), buf);

        snprintf(buf, sizeof(buf),
            "blk:%llx | L0 lst:%llx it:%llx c:%d c2:%d e0:%llx",
            (unsigned long long)g_dbg_blk,
            (unsigned long long)g_dbg_lst[0], (unsigned long long)g_dbg_litems[0],
            g_dbg_lcnt[0], g_dbg_lcnt2[0], (unsigned long long)g_dbg_lelem0[0]);
        dl->AddText(f, 14.f, ImVec2(20.f, 168.f), IM_COL32(255, 160, 0, 255), buf);
        snprintf(buf, sizeof(buf),
            "L1 lst:%llx it:%llx c:%d c2:%d e0:%llx | L2 lst:%llx it:%llx c:%d c2:%d e0:%llx",
            (unsigned long long)g_dbg_lst[1], (unsigned long long)g_dbg_litems[1], g_dbg_lcnt[1], g_dbg_lcnt2[1], (unsigned long long)g_dbg_lelem0[1],
            (unsigned long long)g_dbg_lst[2], (unsigned long long)g_dbg_litems[2], g_dbg_lcnt[2], g_dbg_lcnt2[2], (unsigned long long)g_dbg_lelem0[2]);
        dl->AddText(f, 14.f, ImVec2(20.f, 186.f), IM_COL32(255, 160, 0, 255), buf);

        // Raw L0 / L1 object dumps (offsets +0x00..+0x40)
        for (int k = 0; k < 2; k++) {
            snprintf(buf, sizeof(buf),
                "RAW%d +0:%llx +8:%llx +10:%llx +18:%llx +20:%llx +28:%llx +30:%llx +38:%llx +40:%llx",
                k,
                (unsigned long long)g_dbg_raw[k][0], (unsigned long long)g_dbg_raw[k][1],
                (unsigned long long)g_dbg_raw[k][2], (unsigned long long)g_dbg_raw[k][3],
                (unsigned long long)g_dbg_raw[k][4], (unsigned long long)g_dbg_raw[k][5],
                (unsigned long long)g_dbg_raw[k][6], (unsigned long long)g_dbg_raw[k][7],
                (unsigned long long)g_dbg_raw[k][8]);
            dl->AddText(f, 14.f, ImVec2(20.f, (float)(204 + k * 18)), IM_COL32(180, 200, 255, 255), buf);
        }

        snprintf(buf, sizeof(buf), "lib:%llx-%llx maxn:%d sfoff:0x%x",
                     (unsigned long long)g_dbg_mod_start, (unsigned long long)g_dbg_mod_end,
                     g_dbg_maxn, g_static_fields_off);
        dl->AddText(f, 14.f, ImVec2(20.f, 132.f), IM_COL32(255, 200, 0, 255), buf);

        snprintf(buf, sizeof(buf), "scan: str:%d ref:%d named:%d sfok:%d",
                     g_dbg_strcount, g_dbg_refcount, g_dbg_named, g_dbg_sfok);
        dl->AddText(f, 14.f, ImVec2(20.f, 150.f), IM_COL32(0, 200, 255, 255), buf);
    }

    // ---- console logging (Diagnostics tab) ----
    // Runs unconditionally (before any early-return) so the log is useful even
    // when the game isn't loaded yet or the player list is empty.
    {
        static double last_log = 0;
        static int p_magic = -1, p_kd = 0, p_cnt = -1, p_cam = 0;
        int magic = (int)rpm<uint32_t>(proc::lib);
        double now = scan_clock();
        if (p_magic != (magic ? 1 : 0)) {
            if (magic) logger::f("[+] game memory READABLE (lib=%llx, ELF magic ok)", (unsigned long long)proc::lib);
            else        logger::f("[!] ERR: cannot read game memory (pid=%d lib=%llx magic=0)", (int)proc::pid, (unsigned long long)proc::lib);
            p_magic = magic ? 1 : 0;
        }
        if (p_kd == 0 && g_dbg_kD != 0) logger::f("[+] PlayerManager class found kD=%llx sf=%llx", (unsigned long long)g_dbg_kD, (unsigned long long)g_dbg_sf);
        if (p_kd != 0 && g_dbg_kD == 0) logger::f("[!] ERR: PlayerManager class lost");
        if (p_cnt == 0 && count > 0)    logger::f("[+] player list resolved cnt=%d (local=%llx cam=%llx)", count, (unsigned long long)pl.local, (unsigned long long)pl.camNative);
        if (p_cnt > 0 && count == 0)    logger::f("[!] player list empty / lost");
        if (p_cam == 0 && camera::g_valid) logger::f("[+] camera resolved p@%llx v@%llx ord=%d tr=%d (validated %d players)",
            (unsigned long long)camera::g_proj_addr, (unsigned long long)camera::g_view_addr, camera::g_order, camera::g_trans, camera::g_dbg_best);
        p_kd = (g_dbg_kD != 0) ? 1 : 0;
        p_cnt = count;
        p_cam = camera::g_valid ? 1 : 0;
    }

    if (!any) return;

    // Aimbot FOV circle — drawn independently of player/camera availability.
    if (cfg::aimbot::show_fov || cfg::aimbot::enabled) {
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        float fcx = camera::g_sw * 0.5f, fcy = camera::g_sh * 0.5f;
        dl->AddCircle(ImVec2(fcx, fcy), cfg::aimbot::fov, IM_COL32(255, 80, 80, 180), 32, 1.5f);
    }

    if (pl.players.empty()) return;

    // Players already resolved (instances found by heap scan). Read fresh positions.
    std::vector<uint64_t> players;
    std::vector<Vector3> positions;
    players.reserve(pl.players.size());
    positions.reserve(pl.players.size());
    for (uint64_t p : pl.players) {
        GVec3 w = get_player_position(p);
        Vector3 pos{ w.x, w.y, w.z };
        if (!camera::vec_ok(pos)) continue;
        players.push_back(p);
        positions.push_back(pos);
    }
    if (positions.empty()) {
        // No readable positions (e.g. lobby/menu) — still resolve the camera so
        // diagnostics stay live and the next match starts warm. The matrix scan
        // is validated only when real player positions exist.
        camera::resolve(positions);
        static int dl0 = 0; if (dl0 < 10) { dl0++;
            logger::f("[esp] DBG positions-empty (players=%zu local=%llx)", pl.players.size(), (unsigned long long)pl.local); }
        return;
    }

    static int dl1 = 0; if (dl1 < 10) { dl1++;
        for (size_t i = 0; i < positions.size() && i < 7; i++)
            logger::f("[esp] DBG pos%d=(%.1f,%.1f,%.1f) p=%llx", (int)i, positions[i].x, positions[i].y, positions[i].z, (unsigned long long)players[i]); }

    // Resolve the camera (finds + self-validates projection/view offsets).
    if (!camera::resolve(positions)) return;

    static int dl2 = 0; if (dl2 < 5) { dl2++;
        camera::Mat4 V = camera::view_matrix();
        camera::Mat4 P = rpm<camera::Mat4>(camera::g_proj_addr);
        logger::f("[esp] DBG view[4]=%.3f [5]=%.3f [12]=%.3f [13]=%.3f [14]=%.3f [15]=%.3f",
            V.m[4], V.m[5], V.m[12], V.m[13], V.m[14], V.m[15]);
        logger::f("[esp] DBG proj[0]=%.3f [5]=%.3f [10]=%.3f [11]=%.3f [14]=%.3f [15]=%.3f",
            P.m[0], P.m[5], P.m[10], P.m[11], P.m[14], P.m[15]);
    }

    // Local player = the one closest to the camera (don't draw a box on ourselves).
    camera::Mat4 view = camera::view_matrix();
    Vector3 campos{};
    bool have_cam = camera::camera_position_from_view(view, campos);
    int local_idx = -1;
    double bestd = INFINITY;
    for (size_t i = 0; i < positions.size(); i++) {
        if (!have_cam) { local_idx = 0; break; }
        float dx = positions[i].x - campos.x;
        float dy = positions[i].y - campos.y;
        float dz = positions[i].z - campos.z;
        double d = (double)(dx * dx + dy * dy + dz * dz);
        if (d < bestd) { bestd = d; local_idx = (int)i; }
    }

    // collect enemies (exclude local) with projected screen positions
    struct Ent { uint64_t ptr; Vector3 wpos; camera::Vec2 feet; camera::Vec2 head; camera::Vec2 chest; bool ok; };
    std::vector<Ent> ents;
    ents.reserve(players.size());
    for (size_t i = 0; i < players.size(); i++) {
        if ((int)i == local_idx) continue;
        const Vector3& wp = positions[i];
        Ent e; e.ptr = players[i]; e.wpos = wp;
        Vector3 head(wp.x, wp.y + 1.8f, wp.z);
        Vector3 chest(wp.x, wp.y + 1.0f, wp.z);
        e.ok = camera::w2s(wp, e.feet) && camera::w2s(head, e.head) && camera::w2s(chest, e.chest);
        if (e.ok) ents.push_back(e);
    }

    {
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        char buf[256];
        snprintf(buf, sizeof(buf), "ents:%d local:%d camvalid:%s best:%llu struct:%llu",
                 (int)ents.size(), local_idx,
                 camera::g_valid ? "OK" : "0",
                 (unsigned long long)camera::g_dbg_best, (unsigned long long)camera::g_dbg_struct);
        dl->AddText((espFont ? espFont : ImGui::GetFont()), 14.f, ImVec2(20.f, 114.f), IM_COL32(0,255,128,255), buf);
        for (size_t i = 0; i < ents.size() && i < 5; i++) {
            static int de = 0; if (de < 12) { de++;
                logger::f("[esp] ent%d w=(%.1f,%.1f,%.1f) scr=(%.0f,%.0f)",
                    (int)i, ents[i].wpos.x, ents[i].wpos.y, ents[i].wpos.z,
                    ents[i].feet.x, ents[i].feet.y);
            }
        }
    }

    // aimbot: nearest enemy to crosshair within FOV
    int aim_idx = -1;
    float aim_best = cfg::aimbot::fov * cfg::aimbot::fov;
    float scx = camera::g_sw * 0.5f, scy = camera::g_sh * 0.5f;
    for (size_t i = 0; i < ents.size(); i++) {
        float dx = ents[i].chest.x - scx, dy = ents[i].chest.y - scy;
        float d2 = dx * dx + dy * dy;
        if (d2 < aim_best) { aim_best = d2; aim_idx = (int)i; }
    }

    for (size_t i = 0; i < ents.size(); i++) {
        Ent& e = ents[i];

        float Distance = have_cam
            ? sqrtf((e.wpos.x - campos.x) * (e.wpos.x - campos.x) +
                    (e.wpos.y - campos.y) * (e.wpos.y - campos.y) +
                    (e.wpos.z - campos.z) * (e.wpos.z - campos.z))
            : 0.f;
        if (Distance > 1000.f) continue;

        if (cfg::esp::box) {
            float x1 = roundf(e.feet.x);
            float y1 = roundf(fminf(e.feet.y, e.head.y));
            float x2 = roundf(e.head.x);
            float y2 = roundf(fmaxf(e.feet.y, e.head.y));
            float bh = fabsf(y2 - y1);
            if (bh >= 2.f) {
                float bw = roundf(bh * 0.25f);
                float ccx = roundf((x1 + x2) * 0.5f);
                dbox(ImVec2(ccx - bw, y1), ImVec2(ccx + bw, y2), 1.f);
            }
        }

        if (cfg::esp::skeleton) draw_skeleton(e.wpos);

        float font_sz = 14.f;
        float bx = e.head.x, by = e.head.y;
        if (cfg::esp::name) {
            std::string ns = player::name(e.ptr).as_utf8();
            if (!ns.empty()) dnick(ns.c_str(), ImVec2(bx, by), bx, font_sz, 1.f);
        }
        if (cfg::esp::distance) ddist(Distance, bx + 5.f, by, font_sz, 1.f);
    }

    // aimbot visuals + (optional) aim application
    if (cfg::aimbot::show_fov || cfg::aimbot::enabled) {
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        if (aim_idx >= 0 && cfg::aimbot::enabled) {
            Ent& t = ents[aim_idx];
            dl->AddLine(ImVec2(scx, scy), ImVec2(t.chest.x, t.chest.y), IM_COL32(255, 0, 0, 220), 1.5f);
            dl->AddCircle(ImVec2(t.chest.x, t.chest.y), 6.f, IM_COL32(255, 0, 0, 255), 16, 2.f);

            if (cfg::aimbot::write && cfg::aimbot::rot_offset > 0.f && have_cam &&
                local_idx >= 0 && local_idx < (int)players.size()) {
                Vector3 aimAt = (cfg::aimbot::aim_head)
                    ? Vector3(t.wpos.x, t.wpos.y + 1.8f, t.wpos.z)
                    : Vector3(t.wpos.x, t.wpos.y + 1.0f, t.wpos.z);
                camera::write_aim(players[local_idx], campos, aimAt, (uint64_t)cfg::aimbot::rot_offset);
            }
        }
    }
}

void visuals::dbox(const ImVec2& t, const ImVec2& b, float a) {
    if (a < 0.01f) return;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();

    float x1 = t.x, y1 = t.y, x2 = b.x, y2 = b.y;
    float r = cfg::esp::box_rounding;

    ImU32 col = IM_COL32(
        static_cast<int>(cfg::esp::box_col.x * 255),
        static_cast<int>(cfg::esp::box_col.y * 255),
        static_cast<int>(cfg::esp::box_col.z * 255),
        static_cast<int>(cfg::esp::box_col.w * 255 * a)
    );

    if (cfg::esp::box_type == 0) {
        dl->AddRect(ImVec2(x1 + 2.f, y1 + 2.f), ImVec2(x2 + 2.f, y2 + 2.f), IM_COL32(0, 0, 0, (int)(100 * a)), r, 0, 2.f);
        dl->AddRect(ImVec2(x1 - 1.f, y1 - 1.f), ImVec2(x2 + 1.f, y2 + 1.f), IM_COL32(0, 0, 0, (int)(180 * a)), r, 0, 1.f);
        dl->AddRect(ImVec2(x1, y1), ImVec2(x2, y2), col, r, 0, 1.f);
    } else {
        float w = x2 - x1, h = y2 - y1;
        float sz = std::min(w, h) * 0.25f;
        float cr = std::min(r, sz * 0.5f);

        ImU32 s1 = IM_COL32(0, 0, 0, (int)(100 * a));
        ImU32 s2 = IM_COL32(0, 0, 0, (int)(180 * a));

        auto corner = [&](float cx, float cy, float dx, float dy) {
            if (cr > 0.5f) {
                float arc_cx = cx + dx * cr;
                float arc_cy = cy + dy * cr;

                float angle_start, angle_end;
                if (dx > 0 && dy > 0) { angle_start = 3.14159265f; angle_end = 4.71238898f; }
                else if (dx < 0 && dy > 0) { angle_start = 4.71238898f; angle_end = 6.28318530f; }
                else if (dx > 0 && dy < 0) { angle_start = 1.57079632f; angle_end = 3.14159265f; }
                else { angle_start = 0.f; angle_end = 1.57079632f; }

                dl->PathArcTo(ImVec2(arc_cx + 2.f * (dx > 0 ? 1 : -1), arc_cy + 2.f * (dy > 0 ? 1 : -1)), cr, angle_start, angle_end, 8);
                dl->PathStroke(s1, 0, 2.f);
                dl->AddLine(ImVec2(cx + dx * cr, cy + 2.f * (dy > 0 ? 1 : -1)), ImVec2(cx + dx * sz, cy + 2.f * (dy > 0 ? 1 : -1)), s1, 2.f);
                dl->AddLine(ImVec2(cx + 2.f * (dx > 0 ? 1 : -1), cy + dy * cr), ImVec2(cx + 2.f * (dx > 0 ? 1 : -1), cy + dy * sz), s1, 2.f);

                dl->PathArcTo(ImVec2(arc_cx, arc_cy), cr, angle_start, angle_end, 8);
                dl->PathStroke(s2, 0, 1.f);
                dl->AddLine(ImVec2(cx + dx * cr, cy), ImVec2(cx + dx * sz, cy), s2, 1.f);
                dl->AddLine(ImVec2(cx, cy + dy * cr), ImVec2(cx, cy + dy * sz), s2, 1.f);

                dl->PathArcTo(ImVec2(arc_cx, arc_cy), cr, angle_start, angle_end, 8);
                dl->PathStroke(col, 0, 1.f);
                dl->AddLine(ImVec2(cx + dx * cr, cy), ImVec2(cx + dx * sz, cy), col, 1.f);
                dl->AddLine(ImVec2(cx, cy + dy * cr), ImVec2(cx, cy + dy * sz), col, 1.f);
            } else {
                dl->AddLine(ImVec2(cx + 2.f * (dx > 0 ? 1 : -1), cy + 2.f * (dy > 0 ? 1 : -1)), ImVec2(cx + dx * sz + 2.f * (dx > 0 ? 1 : -1), cy + 2.f * (dy > 0 ? 1 : -1)), s1, 2.f);
                dl->AddLine(ImVec2(cx + 2.f * (dx > 0 ? 1 : -1), cy + 2.f * (dy > 0 ? 1 : -1)), ImVec2(cx + 2.f * (dx > 0 ? 1 : -1), cy + dy * sz + 2.f * (dy > 0 ? 1 : -1)), s1, 2.f);

                dl->AddLine(ImVec2(cx, cy), ImVec2(cx + dx * sz, cy), s2, 1.f);
                dl->AddLine(ImVec2(cx, cy), ImVec2(cx, cy + dy * sz), s2, 1.f);

                dl->AddLine(ImVec2(cx, cy), ImVec2(cx + dx * sz, cy), col, 1.f);
                dl->AddLine(ImVec2(cx, cy), ImVec2(cx, cy + dy * sz), col, 1.f);
            }
        };

        corner(x1, y1, 1, 1);
        corner(x2, y1, -1, 1);
        corner(x1, y2, 1, -1);
        corner(x2, y2, -1, -1);
    }
}

void visuals::dhp(int hp, const ImVec2& t, const ImVec2& b, float box_h, float a) {
    if (a < 0.01f) return;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();

    hp = std::clamp(hp, 0, 100);
    float pct = hp / 100.f;

    float bx = roundf(t.x - 6.f);
    float bw = 3.f;
    float bh = roundf(b.y - t.y);
    float fh = bh * pct;

    float top_y = t.y;
    float bot_y = b.y;
    float fill_top = roundf(bot_y - fh);

    dl->AddRectFilled(ImVec2(bx - 2.f, top_y - 2.f), ImVec2(bx + bw + 2.f, bot_y + 2.f), IM_COL32(0, 0, 0, (int)(120 * a)), 1.f);
    dl->AddRectFilled(ImVec2(bx - 1.f, top_y - 1.f), ImVec2(bx + bw + 1.f, bot_y + 1.f), IM_COL32(0, 0, 0, (int)(200 * a)), 0.f);
    dl->AddRect(ImVec2(bx - 1.f, top_y - 1.f), ImVec2(bx + bw + 1.f, bot_y + 1.f), IM_COL32(30, 30, 30, (int)(255 * a)), 0, 0, 1.f);

    ImU32 col_top = IM_COL32(
        static_cast<int>(cfg::esp::health_col.x * 255),
        static_cast<int>(cfg::esp::health_col.y * 255),
        static_cast<int>(cfg::esp::health_col.z * 255),
        static_cast<int>(cfg::esp::health_col.w * 255 * a)
    );
    ImU32 col_bot = IM_COL32(
        static_cast<int>(cfg::esp::health_col.x * 180),
        static_cast<int>(cfg::esp::health_col.y * 180),
        static_cast<int>(cfg::esp::health_col.z * 180),
        static_cast<int>(cfg::esp::health_col.w * 255 * a)
    );

    if (fh > 1.f) {
        dl->AddRectFilledMultiColor(ImVec2(bx, fill_top), ImVec2(bx + bw, bot_y), col_top, col_top, col_bot, col_bot);
    }

    if (hp < 100 && espFont && bh > 20.f) {
        char txt[8];
        snprintf(txt, sizeof(txt), "%d", hp);
        float fs = 10.f;
        ImVec2 ts = espFont->CalcTextSizeA(fs, FLT_MAX, 0.f, txt);
        float tx = roundf(bx + (bw - ts.x) * 0.5f);
        float ty = roundf(fill_top - ts.y * 0.5f);
        if (ty < top_y) ty = top_y;
        if (ty + ts.y > bot_y) ty = bot_y - ts.y;
        draw_text_outlined(dl, espFont, fs, ImVec2(tx, ty), IM_COL32(255, 255, 255, (int)(255 * a)), txt);
    }
}

void visuals::draw_skeleton(const Vector3& root) {
    // root = player feet world position. Build a proportional humanoid and
    // project each joint. No bone offsets needed.
    struct J { Vector3 w; camera::Vec2 s; bool ok; };
    auto P = [&](float dx, float dy, float dz) -> J {
        J j;
        Vector3 w{ root.x + dx, root.y + dy, root.z + dz };
        j.ok = camera::w2s(w, j.s);
        j.w = w;
        return j;
    };
    J pelvis = P(0, 0.9f, 0), chest = P(0, 1.4f, 0), neck = P(0, 1.55f, 0), head = P(0, 1.8f, 0);
    J shL = P(-0.25f, 1.4f, 0), shR = P(0.25f, 1.4f, 0);
    J haL = P(-0.30f, 0.9f, 0), haR = P(0.30f, 0.9f, 0);
    J hiL = P(-0.15f, 0.9f, 0), hiR = P(0.15f, 0.9f, 0);
    J foL = P(-0.15f, 0, 0),     foR = P(0.15f, 0, 0);

    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    ImU32 c = IM_COL32(
        (int)(cfg::esp::skeleton_col.x * 255),
        (int)(cfg::esp::skeleton_col.y * 255),
        (int)(cfg::esp::skeleton_col.z * 255),
        (int)(cfg::esp::skeleton_col.w * 255));

    auto line = [&](const J& a, const J& b) {
        if (a.ok && b.ok) dl->AddLine(ImVec2(a.s.x, a.s.y), ImVec2(b.s.x, b.s.y), c, 1.5f);
    };
    line(head, neck); line(neck, chest); line(chest, pelvis);
    line(chest, shL);  line(shL, haL);
    line(chest, shR);  line(shR, haR);
    line(pelvis, hiL); line(hiL, foL);
    line(pelvis, hiR); line(hiR, foR);
}

void visuals::dnick(const char* name, const ImVec2& box_min, float cx, float sz, float a) {
    if (!espFont || a < 0.01f || !name) return;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();

    ImVec2 ts = espFont->CalcTextSizeA(sz, FLT_MAX, 0.f, name);
    ImVec2 tp(roundf(cx - ts.x * 0.5f), roundf(box_min.y - ts.y - 4.f));

    ImU32 col = IM_COL32(
        static_cast<int>(cfg::esp::name_col.x * 255),
        static_cast<int>(cfg::esp::name_col.y * 255),
        static_cast<int>(cfg::esp::name_col.z * 255),
        static_cast<int>(cfg::esp::name_col.w * 255 * a)
    );
    draw_text_outlined(dl, espFont, sz, tp, col, name);
}

void visuals::ddist(float dist, float x, float y, float sz, float a) {
    if (!espFont || a < 0.01f) return;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();

    char txt[16];
    snprintf(txt, sizeof(txt), "%dm", static_cast<int>(dist));

    ImVec2 tp(roundf(x + 5.f), roundf(y));

    ImU32 col = IM_COL32(
        static_cast<int>(cfg::esp::distance_col.x * 255),
        static_cast<int>(cfg::esp::distance_col.y * 255),
        static_cast<int>(cfg::esp::distance_col.z * 255),
        static_cast<int>(cfg::esp::distance_col.w * 255 * a)
    );
    draw_text_outlined(dl, espFont, sz, tp, col, txt);
}

void visuals::draw_text_outlined(ImDrawList* dl, ImFont* font, float size, const ImVec2& pos, ImU32 color, const char* text) {
    if (!font || !dl) return;

    int a = (color >> IM_COL32_A_SHIFT) & 0xFF;
    int s1 = static_cast<int>(a * 0.4f);
    int s2 = static_cast<int>(a * 0.7f);

    dl->AddText(font, size, ImVec2(pos.x + 2.f, pos.y + 2.f), IM_COL32(0, 0, 0, s1), text);
    dl->AddText(font, size, ImVec2(pos.x + 1.f, pos.y + 1.f), IM_COL32(0, 0, 0, s2), text);
    dl->AddText(font, size, pos, color, text);
}
