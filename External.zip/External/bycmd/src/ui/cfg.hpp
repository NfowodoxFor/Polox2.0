#pragma once
#include "imgui.h"

namespace cfg {

namespace esp {
    inline bool box = true;
    inline bool name = true;
    inline bool health = false;
    inline bool distance = true;
    inline bool skeleton = true;
    inline int box_type = 0;
    inline float box_rounding = 0.f;
    inline ImVec4 box_col = ImVec4(162/255.f, 144/255.f, 225/255.f, 1.f);
    inline ImVec4 name_col = ImVec4(1.f, 1.f, 1.f, 1.f);
    inline ImVec4 health_col = ImVec4(162/255.f, 144/255.f, 225/255.f, 1.f);
    inline ImVec4 distance_col = ImVec4(162/255.f, 144/255.f, 225/255.f, 1.f);
    inline ImVec4 skeleton_col = ImVec4(255/255.f, 255/255.f, 255/255.f, 1.f);
}

namespace aimbot {
    inline bool enabled = false;
    inline bool show_fov = false;
    inline float fov = 400.f;        // screen-radius (px) to search targets
    inline bool aim_head = true;     // aim at head vs chest
    inline bool write = false;       // apply aim by writing look rotation (m_CameraTargetRot)
    inline float rot_offset = 0x40;    // offset in mouseLook for m_CameraTargetRot (0x40 = 64)
    inline int aim_key = 0;          // reserved (0 = always on)
}

}



