#pragma once

#include <string>
#include <vector>
#include <cstdio>
#include <cstdarg>
#include <cstring>

namespace logger {

inline std::vector<std::string> g_lines;
inline FILE* g_fp = nullptr;
inline const char* g_path = nullptr;

// Lazily open a log file. Tries a few locations so it works on Android
// (rooted /sdcard or /data/local/tmp) and on a normal PC (cwd).
inline void open_file() {
    if (g_fp) return;
    const char* cands[] = {
        "/data/local/tmp/bycmd_esp.log",
        "/sdcard/bycmd_esp.log",
        "/storage/emulated/0/bycmd_esp.log",
        "./bycmd_esp.log"
    };
    for (const char* p : cands) {
        g_fp = fopen(p, "w");   // truncate each run (no stale-history confusion)
        if (g_fp) { g_path = p; break; }
    }
    if (g_fp) printf("[bycmd] LOG FILE: %s\n", g_path);
    else       printf("[bycmd] LOG FILE: FAILED to open any path (no write permission?)\n");
}

inline void push(const std::string& s) {
    g_lines.push_back(s);
    if (g_lines.size() > 600) g_lines.erase(g_lines.begin(), g_lines.begin() + g_lines.size() - 600);
    open_file();
    if (g_fp) {
        fputs(s.c_str(), g_fp);
        fputc('\n', g_fp);
        fflush(g_fp);   // flush every line so the file is live even if the cheat crashes
    }
    // Mirror every log line to the console (root terminal) too.
    fputs(s.c_str(), stdout);
    fputc('\n', stdout);
    fflush(stdout);
}

inline void f(const char* fmt, ...) {
    char buf[600];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (n > 0) {
        size_t len = (size_t)n < sizeof(buf) ? (size_t)n : sizeof(buf) - 1;
        push(std::string(buf, len));
    }
}

inline void clear() { g_lines.clear(); }

// Call ONCE at startup so the file exists immediately and the path is printed.
inline void init() {
    open_file();
    if (g_fp) {
        f("[esp] === logger started, file=%s ===", g_path ? g_path : "?");
        f("[bycmd] BUILD esp-fix18 (Dump14 camera GC-chain + teamName/health)");
    }
}

} // namespace logger
