#pragma once

#include <cstdio>
#include <cstdarg>

// Простой логгер в файл /data/local/tmp/bycmd_log.txt
// (путь, откуда запускается скрипт на устройстве)
struct esp_logger {
    FILE* f = nullptr;
    bool inited = false;

    void ensure() {
        if (inited) return;
        inited = true;
        f = fopen("/data/local/tmp/bycmd_log.txt", "a");
        if (f) {
            fprintf(f, "=== bycmd ESP log start ===\n");
            fflush(f);
        }
    }

    void write(const char* fmt, ...) {
        ensure();
        if (!f) return;
        va_list ap;
        va_start(ap, fmt);
        vfprintf(f, fmt, ap);
        va_end(ap);
        fflush(f);
    }
};

inline esp_logger g_log;
