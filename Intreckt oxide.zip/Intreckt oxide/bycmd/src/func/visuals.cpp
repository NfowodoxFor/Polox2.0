#include "visuals.hpp"
#include "../game/game.hpp"
#include "../game/math.hpp"
#include "../game/player.hpp"
#include "../game/call.hpp"
#include "../ui/theme/theme.hpp"
#include "../ui/cfg.hpp"
#include "../protect/oxorany.hpp"
#include "imgui.h"
#include <cmath>
#include <algorithm>
#include <vector>

extern ImFont* espFont;

void visuals::draw() {
    static int frame = 0;
    frame++;
    bool verbose = false; // подробный лог отключён

    bool any = cfg::esp::box || cfg::esp::name || cfg::esp::health || cfg::esp::distance;
    if (!any) return;

    // PlayerManager класс + static_fields (детект оффсета, без сканирования камеры)
    uint64_t pmClass = get_player_manager_class();
    if (!pmClass) {
        g_log.write("draw: pmClass == 0 (find_class не нашёл класс)\n");
        return;
    }
    uint64_t sf = get_player_manager_static_fields();
    if (!sf) {
        g_log.write("draw: static_fields == 0 (pmClass=%llx)\n", (unsigned long long)pmClass);
        return;
    }
    uint64_t PlayerList = rpm<uint64_t>(sf + game_offsets::PLAYER_CLIENT_LIST_OFFSET);
    if (!PlayerList) {
        g_log.write("draw: clientPlayerList == 0 (sf=%llx)\n", (unsigned long long)sf);
        return;
    }

    // List<PlayerManager>: _items @ +0x10, _size @ +0x18
    int PlayerCount = rpm<int>(PlayerList + oxorany(0x18));
    if (PlayerCount <= 0 || PlayerCount > 128) {
        g_log.write("draw: bad PlayerCount=%d (PlayerList=%llx)\n", PlayerCount, (unsigned long long)PlayerList);
        return;
    }
    uint64_t Items = rpm<uint64_t>(PlayerList + oxorany(0x10));
    if (!Items) {
        g_log.write("draw: Items == 0 (PlayerList=%llx)\n", (unsigned long long)PlayerList);
        return;
    }
    if (verbose)
        g_log.write("draw: pmClass=%llx sf=%llx PlayerList=%llx PlayerCount=%d Items=%llx\n",
            (unsigned long long)pmClass, (unsigned long long)sf, (unsigned long long)PlayerList, PlayerCount, (unsigned long long)Items);

    // Камера через вызов Camera.get_main() (RVA из дампа)
    // --- Оффсет элементов массива Il2CppArray: в x64 данные начинаются с +0x20 ---
    uint64_t elemOff = 0x20;
    {
        uint64_t p0 = rpm<uint64_t>(Items + 0x20);
        uint64_t k0 = p0 ? rpm<uint64_t>(p0 + 0x0) : 0;
        if (k0 != pmClass) {
            uint64_t p1 = rpm<uint64_t>(Items + 0x18);
            uint64_t k1 = p1 ? rpm<uint64_t>(p1 + 0x0) : 0;
            elemOff = (k1 == pmClass) ? 0x18 : 0x20;
        }
        g_log.write("draw: array elemOff=%llx\n", (unsigned long long)elemOff);
    }

    std::vector<uint64_t> players;
    players.reserve(PlayerCount);
    uint64_t localPlayer = 0;
    for (int i = 0; i < PlayerCount; i++) {
        uint64_t Player = rpm<uint64_t>(Items + elemOff + (uint64_t)i * 8);
        if (!Player) continue;
        if (rpm<uint64_t>(Player + 0x0) != pmClass) continue; // отсеиваем мусорные указатели
        players.push_back(Player);
        if (!localPlayer && i == 0) localPlayer = Player; // первый обычно локальный
            if (verbose) {
                Vector3 pp = player::position(Player);
                g_log.write("draw: player[%d] p=%llx pos=(%f,%f,%f) hp=%d\n",
                    i, (unsigned long long)Player, pp.x, pp.y, pp.z, player::health(Player));
            }
    }
    if (players.empty()) {
        g_log.write("draw: no valid players (elemOff=%llx)\n", (unsigned long long)elemOff);
        return;
    }

    // Камера: реальный UnityEngine.Camera (managed) -> native-структура с матрицами
    uint64_t cam = remote::get_main_camera();
    if (!cam) cam = player::get_camera_from_fpmanager(players[0]);
    if (!cam) {
        g_log.write("draw: NO CAMERA\n");
        return;
    }

    // Проекция: основной путь — WorldToScreenPoint реального Unity.Camera (this валиден,
    // падало раньше только из-за кастомного fpManager-камера как this).
    bool useW2S = (cam != 0) && !remote::g_disabled;

    // Запасной матричный путь: view/proj по оффсетам native-камеры.
    uint64_t cameraPtr = rpm<uint64_t>(cam + 0x10);
    matrix viewMatrix{}, projMatrix{}, vp{};
    bool haveVP = false;
    if (!useW2S && cameraPtr) {
        mem_read(cameraPtr + game_offsets::CAMERA_VIEW_MATRIX, &viewMatrix, sizeof(matrix));
        mem_read(cameraPtr + game_offsets::CAMERA_PROJECTION_MATRIX, &projMatrix, sizeof(matrix));
        float* v = reinterpret_cast<float*>(&viewMatrix);
        float* p = reinterpret_cast<float*>(&projMatrix);
        if (v[0] != 0.f && p[0] != 0.f && std::isfinite(v[0]) && std::isfinite(p[0])) {
            vp = multiply_matrix(projMatrix, viewMatrix);
            haveVP = true;
        }
    }

    Vector3 LocalPosition = localPlayer ? player::position(localPlayer) : Vector3(0, 0, 0);

    for (uint64_t Player : players) {
        if (Player == localPlayer) continue;

        Vector3 PlayerPosition = player::position(Player);
        if (PlayerPosition.x == 0.f && PlayerPosition.y == 0.f && PlayerPosition.z == 0.f) continue;

        int Health = player::health(Player);

        float Distance = calculate_distance(PlayerPosition, LocalPosition);
        if (Distance > 50000.f) continue;

        Vector3 HeadPosition(PlayerPosition.x, PlayerPosition.y + 1.67f, PlayerPosition.z);

        ImVec2 ScreenHead, ScreenFoot;
        bool HeadVisible = false, FootVisible = false;

        if (useW2S) {
            float hx, hy, hz, fx, fy, fz;
            if (player::project_w2s(cam, HeadPosition, hx, hy, hz)) {
                ScreenHead = ImVec2(hx, hy);
                HeadVisible = (hz > 0.f && hx >= 0.f && hx <= g_sw && hy >= 0.f && hy <= g_sh);
            }
            if (player::project_w2s(cam, PlayerPosition, fx, fy, fz)) {
                ScreenFoot = ImVec2(fx, fy);
                FootVisible = (fz > 0.f && fx >= 0.f && fx <= g_sw && fy >= 0.f && fy <= g_sh);
            }
        }
        if ((!HeadVisible || !FootVisible) && haveVP) {
            HeadVisible = world_to_screen(HeadPosition, vp, ScreenHead);
            FootVisible = world_to_screen(PlayerPosition, vp, ScreenFoot);
        }
        if (!HeadVisible || !FootVisible) continue;

        float x1 = roundf(ScreenHead.x);
        float y1 = roundf(fminf(ScreenHead.y, ScreenFoot.y));
        float x2 = roundf(ScreenFoot.x);
        float y2 = roundf(fmaxf(ScreenHead.y, ScreenFoot.y));

        float bh = fabsf(y2 - y1);
        float bw = roundf(bh * 0.25f);
        float cx = roundf((x1 + x2) * 0.5f);

        ImVec2 BoxMin(cx - bw, y1);
        ImVec2 BoxMax(cx + bw, y2);

        float inv_dist = 1.f / (Distance + 0.1f);
        float font_sz = std::clamp(400.f * inv_dist, 10.f, 18.f);

        if (cfg::esp::box) {
            dbox(BoxMin, BoxMax, 1.f);
        }

        if (cfg::esp::health) {
            dhp(Health, BoxMin, BoxMax, bh, 1.f);
        }

        if (cfg::esp::name) {
            read_string PlayerName = player::name(Player);
            std::string ns = PlayerName.as_utf8();
            if (!ns.empty()) {
                dnick(ns.c_str(), BoxMin, cx, font_sz, 1.f);
            }
        }

        if (cfg::esp::distance) {
            ddist(Distance, BoxMax.x, BoxMin.y, font_sz, 1.f);
        }
    }
}

void visuals::dbox(const ImVec2& t, const ImVec2& b, float a) {
    if (a < 0.01f) return;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();

    float x1 = t.x, y1 = t.y, x2 = b.x, y2 = b.y;
    float r = cfg::esp::box_rounding;

    ImU32 col = IM_COL32(
        static_cast<int>(cfg::esp::box_col.x * 255),
        static_cast<int>(cfg::esp::box_col.y * 255),
        static_cast<int>(cfg::esp::box_col.z * 255),
        static_cast<int>(cfg::esp::box_col.w * 255 * a)
    );

    if (cfg::esp::box_type == 0) {
        dl->AddRect(ImVec2(x1 + 2.f, y1 + 2.f), ImVec2(x2 + 2.f, y2 + 2.f), IM_COL32(0, 0, 0, (int)(100 * a)), r, 0, 2.f);
        dl->AddRect(ImVec2(x1 - 1.f, y1 - 1.f), ImVec2(x2 + 1.f, y2 + 1.f), IM_COL32(0, 0, 0, (int)(180 * a)), r, 0, 1.f);
        dl->AddRect(ImVec2(x1, y1), ImVec2(x2, y2), col, r, 0, 1.f);
    } else {
        float w = x2 - x1, h = y2 - y1;
        float sz = std::min(w, h) * 0.25f;
        float cr = std::min(r, sz * 0.5f);

        ImU32 s1 = IM_COL32(0, 0, 0, (int)(100 * a));
        ImU32 s2 = IM_COL32(0, 0, 0, (int)(180 * a));

        auto corner = [&](float cx, float cy, float dx, float dy) {
            if (cr > 0.5f) {
                float arc_cx = cx + dx * cr;
                float arc_cy = cy + dy * cr;

                float angle_start, angle_end;
                if (dx > 0 && dy > 0) { angle_start = 3.14159265f; angle_end = 4.71238898f; }
                else if (dx < 0 && dy > 0) { angle_start = 4.71238898f; angle_end = 6.28318530f; }
                else if (dx > 0 && dy < 0) { angle_start = 1.57079632f; angle_end = 3.14159265f; }
                else { angle_start = 0.f; angle_end = 1.57079632f; }

                dl->PathArcTo(ImVec2(arc_cx + 2.f * (dx > 0 ? 1 : -1), arc_cy + 2.f * (dy > 0 ? 1 : -1)), cr, angle_start, angle_end, 8);
                dl->PathStroke(s1, 0, 2.f);
                dl->AddLine(ImVec2(cx + dx * cr, cy + 2.f * (dy > 0 ? 1 : -1)), ImVec2(cx + dx * sz, cy + 2.f * (dy > 0 ? 1 : -1)), s1, 2.f);
                dl->AddLine(ImVec2(cx + 2.f * (dx > 0 ? 1 : -1), cy + dy * cr), ImVec2(cx + 2.f * (dx > 0 ? 1 : -1), cy + dy * sz), s1, 2.f);

                dl->PathArcTo(ImVec2(arc_cx, arc_cy), cr, angle_start, angle_end, 8);
                dl->PathStroke(s2, 0, 1.f);
                dl->AddLine(ImVec2(cx + dx * cr, cy), ImVec2(cx + dx * sz, cy), s2, 1.f);
                dl->AddLine(ImVec2(cx, cy + dy * cr), ImVec2(cx, cy + dy * sz), s2, 1.f);

                dl->PathArcTo(ImVec2(arc_cx, arc_cy), cr, angle_start, angle_end, 8);
                dl->PathStroke(col, 0, 1.f);
                dl->AddLine(ImVec2(cx + dx * cr, cy), ImVec2(cx + dx * sz, cy), col, 1.f);
                dl->AddLine(ImVec2(cx, cy + dy * cr), ImVec2(cx, cy + dy * sz), col, 1.f);
            } else {
                dl->AddLine(ImVec2(cx + 2.f * (dx > 0 ? 1 : -1), cy + 2.f * (dy > 0 ? 1 : -1)), ImVec2(cx + dx * sz + 2.f * (dx > 0 ? 1 : -1), cy + 2.f * (dy > 0 ? 1 : -1)), s1, 2.f);
                dl->AddLine(ImVec2(cx + 2.f * (dx > 0 ? 1 : -1), cy + 2.f * (dy > 0 ? 1 : -1)), ImVec2(cx + 2.f * (dx > 0 ? 1 : -1), cy + dy * sz + 2.f * (dy > 0 ? 1 : -1)), s1, 2.f);

                dl->AddLine(ImVec2(cx, cy), ImVec2(cx + dx * sz, cy), s2, 1.f);
                dl->AddLine(ImVec2(cx, cy), ImVec2(cx, cy + dy * sz), s2, 1.f);

                dl->AddLine(ImVec2(cx, cy), ImVec2(cx + dx * sz, cy), col, 1.f);
                dl->AddLine(ImVec2(cx, cy), ImVec2(cx, cy + dy * sz), col, 1.f);
            }
        };

        corner(x1, y1, 1, 1);
        corner(x2, y1, -1, 1);
        corner(x1, y2, 1, -1);
        corner(x2, y2, -1, -1);
    }
}

void visuals::dhp(int hp, const ImVec2& t, const ImVec2& b, float box_h, float a) {
    if (a < 0.01f) return;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();

    hp = std::clamp(hp, 0, 100);
    float pct = hp / 100.f;

    float bx = roundf(t.x - 6.f);
    float bw = 3.f;
    float bh = roundf(b.y - t.y);
    float fh = bh * pct;

    float top_y = t.y;
    float bot_y = b.y;
    float fill_top = roundf(bot_y - fh);

    dl->AddRectFilled(ImVec2(bx - 2.f, top_y - 2.f), ImVec2(bx + bw + 2.f, bot_y + 2.f), IM_COL32(0, 0, 0, (int)(120 * a)), 1.f);
    dl->AddRectFilled(ImVec2(bx - 1.f, top_y - 1.f), ImVec2(bx + bw + 1.f, bot_y + 1.f), IM_COL32(0, 0, 0, (int)(200 * a)), 0.f);
    dl->AddRect(ImVec2(bx - 1.f, top_y - 1.f), ImVec2(bx + bw + 1.f, bot_y + 1.f), IM_COL32(30, 30, 30, (int)(255 * a)), 0, 0, 1.f);

    ImU32 col_top = IM_COL32(
        static_cast<int>(cfg::esp::health_col.x * 255),
        static_cast<int>(cfg::esp::health_col.y * 255),
        static_cast<int>(cfg::esp::health_col.z * 255),
        static_cast<int>(cfg::esp::health_col.w * 255 * a)
    );
    ImU32 col_bot = IM_COL32(
        static_cast<int>(cfg::esp::health_col.x * 180),
        static_cast<int>(cfg::esp::health_col.y * 180),
        static_cast<int>(cfg::esp::health_col.z * 180),
        static_cast<int>(cfg::esp::health_col.w * 255 * a)
    );

    if (fh > 1.f) {
        dl->AddRectFilledMultiColor(ImVec2(bx, fill_top), ImVec2(bx + bw, bot_y), col_top, col_top, col_bot, col_bot);
    }

    if (hp < 100 && espFont && bh > 20.f) {
        char txt[8];
        snprintf(txt, sizeof(txt), "%d", hp);
        float fs = 10.f;
        ImVec2 ts = espFont->CalcTextSizeA(fs, FLT_MAX, 0.f, txt);
        float tx = roundf(bx + (bw - ts.x) * 0.5f);
        float ty = roundf(fill_top - ts.y * 0.5f);
        if (ty < top_y) ty = top_y;
        if (ty + ts.y > bot_y) ty = bot_y - ts.y;
        draw_text_outlined(dl, espFont, fs, ImVec2(tx, ty), IM_COL32(255, 255, 255, (int)(255 * a)), txt);
    }
}

void visuals::dnick(const char* name, const ImVec2& box_min, float cx, float sz, float a) {
    if (!espFont || a < 0.01f || !name) return;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();

    ImVec2 ts = espFont->CalcTextSizeA(sz, FLT_MAX, 0.f, name);
    ImVec2 tp(roundf(cx - ts.x * 0.5f), roundf(box_min.y - ts.y - 4.f));

    ImU32 col = IM_COL32(
        static_cast<int>(cfg::esp::name_col.x * 255),
        static_cast<int>(cfg::esp::name_col.y * 255),
        static_cast<int>(cfg::esp::name_col.z * 255),
        static_cast<int>(cfg::esp::name_col.w * 255 * a)
    );
    draw_text_outlined(dl, espFont, sz, tp, col, name);
}

void visuals::ddist(float dist, float x, float y, float sz, float a) {
    if (!espFont || a < 0.01f) return;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();

    char txt[16];
    snprintf(txt, sizeof(txt), "%dm", static_cast<int>(dist));

    ImVec2 tp(roundf(x + 5.f), roundf(y));

    ImU32 col = IM_COL32(
        static_cast<int>(cfg::esp::distance_col.x * 255),
        static_cast<int>(cfg::esp::distance_col.y * 255),
        static_cast<int>(cfg::esp::distance_col.z * 255),
        static_cast<int>(cfg::esp::distance_col.w * 255 * a)
    );
    draw_text_outlined(dl, espFont, sz, tp, col, txt);
}

void visuals::draw_text_outlined(ImDrawList* dl, ImFont* font, float size, const ImVec2& pos, ImU32 color, const char* text) {
    if (!font || !dl) return;

    int a = (color >> IM_COL32_A_SHIFT) & 0xFF;
    int s1 = static_cast<int>(a * 0.4f);
    int s2 = static_cast<int>(a * 0.7f);

    dl->AddText(font, size, ImVec2(pos.x + 2.f, pos.y + 2.f), IM_COL32(0, 0, 0, s1), text);
    dl->AddText(font, size, ImVec2(pos.x + 1.f, pos.y + 1.f), IM_COL32(0, 0, 0, s2), text);
    dl->AddText(font, size, pos, color, text);
}
