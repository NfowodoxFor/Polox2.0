#pragma once

#include "../other/memory.hpp"
#include "game_offsets.h"
#include "../other/logger.hpp"

#include <cstdint>
#include <cstring>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

// ============================================================================
//  Remote function call via ptrace (x86_64 / BlueStacks).
//  Used to call IL2CPP methods (Camera.get_main, WorldToScreenPoint) inside the
//  game process WITHOUT scanning the binary.
// ============================================================================

#ifdef __aarch64__
#error "remote::call is only implemented for x86_64 (BlueStacks target)"
#endif

namespace remote {

struct user_regs_x86 {
    unsigned long r15, r14, r13, r12, rbp, rbx, r11, r10, r9, r8;
    unsigned long rax, rcx, rdx, rsi, rdi, orig_rax;
    unsigned long rip, cs, eflags, rsp, ss;
    unsigned long fs_base, gs_base, ds, es, fs, gs;
};

struct user_fpregs_x86 {
    unsigned short cwd, sw, tw, opcode;
    unsigned long long fip, fdp;
    unsigned int mxcsr, mxcsr_mask;
    unsigned int st_space[32];
    unsigned int xmm_space[64]; // xmm0 = [0..3], xmm1 = [4..7] ...
    unsigned int padding[24];
};

// PTRACE requests (x86_64)
enum {
    PTRACE_TRACEME = 0,
    PTRACE_PEEKTEXT = 1,
    PTRACE_PEEKDATA = 2,
    PTRACE_POKETEXT = 4,
    PTRACE_POKEDATA = 5,
    PTRACE_CONT = 7,
    PTRACE_ATTACH = 16,
    PTRACE_DETACH = 17,
    PTRACE_GETREGS = 12,
    PTRACE_SETREGS = 13,
    PTRACE_GETFPREGS = 14,
    PTRACE_SETFPREGS = 15,
};

inline bool g_disabled = false; // becomes true if a call ever crashed the game

static inline long sys_ptrace(long request, int pid, void* addr, void* data) {
    return sys::sc6(101 /* SYS_ptrace x86_64 */,
                    request, (long)pid, (long)addr, (long)data, 0, 0);
}

// PEEK/POKE are inherently word (8-byte) operations and require 8-byte alignment
// on x86_64. We read/write the aligned word and patch the relevant bytes.
static inline uint64_t peek_q(uint64_t addr) {
    return (uint64_t)sys_ptrace(PTRACE_PEEKTEXT, proc::pid, (void*)(addr & ~7ULL), nullptr);
}
static inline void poke_q(uint64_t addr, uint64_t val) {
    sys_ptrace(PTRACE_POKETEXT, proc::pid, (void*)(addr & ~7ULL), (void*)val);
}

// Returns false if it could not install the call-rax shellcode at `host`.
static inline bool install_shellcode(uint64_t host, uint64_t& orig_word) {
    uint64_t ha = host & ~7ULL;
    int bo = (int)(host - ha);
    uint64_t orig = peek_q(ha);
    if ((int64_t)orig == -1) {
        g_log.write("[remote] PEEKTEXT failed at host=%llx (errno)\n", (unsigned long long)host);
        return false;
    }
    uint64_t shell = orig;
    unsigned char* sp = (unsigned char*)&shell;
    sp[bo + 0] = 0xFF; // call rax
    sp[bo + 1] = 0xD0;
    sp[bo + 2] = 0xCC; // int3
    poke_q(ha, shell);
    orig_word = orig;
    return true;
}
static inline void restore_shellcode(uint64_t host, uint64_t orig_word) {
    poke_q(host & ~7ULL, orig_word);
}

// call func(rdi = arg0) -> rax  (for plain value-returning functions)
static inline std::uint64_t call1(std::uint64_t func, std::uint64_t arg0, bool* ok = nullptr) {
    if (ok) *ok = false;
    if (g_disabled) return 0;
    if (proc::pid <= 0 || proc::lib == 0 || func == 0) {
        g_log.write("[remote] call1: bad args pid=%d lib=%llx func=%llx\n",
            proc::pid, (unsigned long long)proc::lib, (unsigned long long)func);
        return 0;
    }

    if (sys_ptrace(PTRACE_ATTACH, proc::pid, nullptr, nullptr) < 0) {
        g_disabled = true;
        g_log.write("[remote] call1: ptrace ATTACH failed (pid=%d). self-ptrace likely blocked.\n", proc::pid);
        return 0;
    }
    int st = 0;
    waitpid(proc::pid, &st, 0); // consume SIGSTOP from attach

    user_regs_x86 r;  std::memset(&r, 0, sizeof r);
    user_fpregs_x86 f; std::memset(&f, 0, sizeof f);
    if (sys_ptrace(PTRACE_GETREGS, proc::pid, &r, &r) < 0 ||
        sys_ptrace(PTRACE_GETFPREGS, proc::pid, &f, &f) < 0) {
        sys_ptrace(PTRACE_DETACH, proc::pid, nullptr, nullptr);
        g_log.write("[remote] call1: GETREGS failed\n");
        return 0;
    }
    user_regs_x86 r0 = r;
    user_fpregs_x86 f0 = f;
    std::uint64_t ret = 0;

    std::uint64_t host = proc::lib + game_offsets::CALL_HOST_RVA;
    std::uint64_t orig = 0;
    if (!install_shellcode(host, orig)) {
        sys_ptrace(PTRACE_DETACH, proc::pid, nullptr, nullptr);
        return 0;
    }

    user_regs_x86 nr = r0;
    nr.rax = func;
    nr.rdi = arg0;
    nr.rip = host;
    if (sys_ptrace(PTRACE_SETREGS, proc::pid, &nr, &nr) < 0) goto restore;
    if (sys_ptrace(PTRACE_CONT, proc::pid, nullptr, nullptr) < 0) goto restore;

    waitpid(proc::pid, &st, 0);

    {
        int stopsig = (st >> 8) & 0x7f;
        bool stopped = ((st & 0x7f) == 0x7f);
        bool signaled = ((st & 0x7f) != 0x7f) && ((st & 0x7f) != 0);
        if (stopped && stopsig == 5 /*SIGTRAP*/) {
            sys_ptrace(PTRACE_GETREGS, proc::pid, &r, &r);
            ret = r.rax;
            if (ok) *ok = true;
        } else if (signaled || stopsig == 11 /*SIGSEGV*/) {
            g_disabled = true;
            g_log.write("[remote] call1: target fault (sig=%d). disabling ptrace calls.\n", stopsig);
        } else {
            g_log.write("[remote] call1: unexpected stop st=%d stopsig=%d\n", st, stopsig);
        }
    }

restore:
    restore_shellcode(host, orig);
    sys_ptrace(PTRACE_SETREGS, proc::pid, &r0, &r0);
    sys_ptrace(PTRACE_SETFPREGS, proc::pid, &f0, &f0);
    sys_ptrace(PTRACE_DETACH, proc::pid, nullptr, nullptr);
    return ret;
}

// call func(this, Vector3) -> Vector3  (IL2CPP struct-by-hidden-pointer convention).
//   rdi = this
//   rsi = retbuf  (hidden pointer to result Vector3, in target process)
//   rdx = argbuf  (hidden pointer to input Vector3, in target process)
// Buffers live on the target thread's stack (valid, writable memory).
static inline bool call_w2s(std::uint64_t func, std::uint64_t thisptr,
                            float x, float y, float z,
                            float& ox, float& oy, float& oz) {
    ox = oy = oz = 0.f;
    if (g_disabled) return false;
    if (proc::pid <= 0 || proc::lib == 0 || func == 0) return false;

    if (sys_ptrace(PTRACE_ATTACH, proc::pid, nullptr, nullptr) < 0) {
        g_disabled = true;
        g_log.write("[remote] call_w2s: ptrace ATTACH failed (pid=%d). self-ptrace likely blocked.\n", proc::pid);
        return false;
    }
    int st = 0;
    waitpid(proc::pid, &st, 0);

    user_regs_x86 r;  std::memset(&r, 0, sizeof r);
    user_fpregs_x86 f; std::memset(&f, 0, sizeof f);
    if (sys_ptrace(PTRACE_GETREGS, proc::pid, &r, &r) < 0 ||
        sys_ptrace(PTRACE_GETFPREGS, proc::pid, &f, &f) < 0) {
        sys_ptrace(PTRACE_DETACH, proc::pid, nullptr, nullptr);
        return false;
    }
    user_regs_x86 r0 = r;
    user_fpregs_x86 f0 = f;
    bool ok = false;
    user_regs_x86 nr;

    std::uint64_t host = proc::lib + game_offsets::CALL_HOST_RVA;
    std::uint64_t orig = 0;
    if (!install_shellcode(host, orig)) {
        sys_ptrace(PTRACE_DETACH, proc::pid, nullptr, nullptr);
        return false;
    }

    // Buffer addresses on the target thread's stack (16-byte aligned, below current rsp).
    std::uint64_t sp = r0.rsp & ~15ULL;
    std::uint64_t retbuf = sp - 0x400;
    std::uint64_t argbuf = sp - 0x500;
    float in[3] = { x, y, z };
    if (!mem_write(argbuf, in, sizeof(in))) {
        g_log.write("[remote] call_w2s: mem_write argbuf failed\n");
        goto restore2;
    }

    nr = r0;
    nr.rax = func;
    // System V sret convention: a function returning a 12-byte struct (Vector3)
    // takes the result buffer as rdi, then `this` in rsi, the input struct (also
    // passed by hidden pointer) in rdx, and the IL2CPP RuntimeMethod* in rcx.
    nr.rdi = retbuf;   // sret: result Vector3
    nr.rsi = thisptr;  // this (Camera)
    nr.rdx = argbuf;   // input Vector3 (by hidden pointer)
    nr.rcx = 0;        // RuntimeMethod* (unused for non-generic)
    nr.rip = host;

    if (sys_ptrace(PTRACE_SETREGS, proc::pid, &nr, &nr) < 0) goto restore2;
    if (sys_ptrace(PTRACE_CONT, proc::pid, nullptr, nullptr) < 0) goto restore2;

    waitpid(proc::pid, &st, 0);

    {
        int stopsig = (st >> 8) & 0x7f;
        bool stopped = ((st & 0x7f) == 0x7f);
        bool signaled = ((st & 0x7f) != 0x7f) && ((st & 0x7f) != 0);
        if (stopped && stopsig == 5) {
            float out[3];
            if (mem_read(retbuf, out, sizeof(out))) {
                ox = out[0]; oy = out[1]; oz = out[2];
                ok = true;
            } else {
                g_log.write("[remote] call_w2s: mem_read retbuf failed\n");
            }
        } else if (signaled || stopsig == 11) {
            g_disabled = true;
            g_log.write("[remote] call_w2s: target fault (sig=%d). disabling ptrace calls.\n", stopsig);
        } else {
            g_log.write("[remote] call_w2s: unexpected stop st=%d stopsig=%d\n", st, stopsig);
        }
    }

restore2:
    restore_shellcode(host, orig);
    sys_ptrace(PTRACE_SETREGS, proc::pid, &r0, &r0);
    sys_ptrace(PTRACE_SETFPREGS, proc::pid, &f0, &f0);
    sys_ptrace(PTRACE_DETACH, proc::pid, nullptr, nullptr);
    return ok && !g_disabled;
}

// Camera.get_main() -> managed Camera* (статический метод, ret в rax).
// Кэшируем; при сбое ptrace отключаемся (g_disabled).
static inline std::uint64_t get_main_camera() {
    static std::uint64_t s_cam = 0;
    if (s_cam) return s_cam;
    bool ok = false;
    g_disabled = false; // call_w2s ранее упал из-за кастомного this; get_main безопасен
    std::uint64_t f = proc::lib + game_offsets::CAMERA_GET_MAIN_RVA;
    std::uint64_t cam = call1(f, 0, &ok);
    g_log.write("[remote] get_main: func=%llx ok=%d cam=%llx disabled=%d\n",
        (unsigned long long)f, (int)ok, (unsigned long long)cam, (int)g_disabled);
    if (ok && cam) { s_cam = cam; return cam; }
    g_disabled = false;
    f = proc::lib + game_offsets::CAMERA_GET_CURRENT_RVA;
    cam = call1(f, 0, &ok);
    g_log.write("[remote] get_current: func=%llx ok=%d cam=%llx disabled=%d\n",
        (unsigned long long)f, (int)ok, (unsigned long long)cam, (int)g_disabled);
    if (ok && cam) { s_cam = cam; return cam; }
    return 0;
}

} // namespace remote
