#pragma once

#include <cmath>
#include <cstring>
#include "../other/vector3.h"
#include "../other/memory.hpp"
#include "game.hpp"
#include "../ui/theme/theme.hpp"
#include "imgui.h"
#include "game_offsets.h"

// ============================================================
//  Умножение МАТРИЦ в ROW-MAJOR раскладке (Unity / IL2CPP).
//  Unity хранит Matrix4x4 в памяти построчно:
//  m00,m01,m02,m03, m10,m11,m12,m13, ... (16 float подряд).
//  Индекс в плоском массиве: idx = row*4 + col.
//  Результат C = A * B  (row-major): C[r][c] = sum_k A[r][k]*B[k][c].
// ============================================================
inline matrix multiply_matrix(const matrix& a, const matrix& b) {
    matrix r{};
    const float* A = reinterpret_cast<const float*>(&a);
    const float* B = reinterpret_cast<const float*>(&b);
    float* R = reinterpret_cast<float*>(&r);
    for (int row = 0; row < 4; row++)
        for (int col = 0; col < 4; col++) {
            float s = 0.f;
            for (int k = 0; k < 4; k++) s += A[row * 4 + k] * B[k * 4 + col];
            R[row * 4 + col] = s;
        }
    return r;
}

// ============================================================
//  VIEWPROJECTION из NATIVE-камеры (UnityEngine.Camera.m_CachedPtr).
//  Матрицы в памяти native-камеры: view @ OFFSET_VIEW_MATRIX, proj @ OFFSET_PROJECTION_MATRIX.
//  VP = Projection * View.
// ============================================================
inline bool get_view_projection_matrix(uint64_t cameraNative, matrix& out) {
    if (!cameraNative) return false;
    matrix view{}, proj{};
    if (!mem_read(cameraNative + game_offsets::CAMERA_VIEW_MATRIX, &view, sizeof(matrix))) return false;
    if (!mem_read(cameraNative + game_offsets::CAMERA_PROJECTION_MATRIX, &proj, sizeof(matrix))) return false;
    out = multiply_matrix(proj, view);
    return true;
}

// ============================================================
//  WORLD -> SCREEN (ROW-MAJOR).
//  clip[row] = sum_col M[row][col] * v[col]
// ============================================================
inline bool world_to_screen(const Vector3& pos, const matrix& vp, ImVec2& out) noexcept {
    const float* m = reinterpret_cast<const float*>(&vp);

    float clipX = m[0] * pos.x + m[1] * pos.y + m[2] * pos.z + m[3];
    float clipY = m[4] * pos.x + m[5] * pos.y + m[6] * pos.z + m[7];
    float clipW = m[12] * pos.x + m[13] * pos.y + m[14] * pos.z + m[15];

    if (!std::isfinite(clipW) || clipW <= 0.0001f) {
        out = ImVec2(-10000.f, -10000.f);
        return false;
    }

    float ndcX = clipX / clipW;
    float ndcY = clipY / clipW;

    out.x = (ndcX + 1.0f) * 0.5f * g_sw;
    out.y = (1.0f - ndcY) * 0.5f * g_sh;
    return true;
}

// ============================================================
//  ДИСТАНЦИЯ
// ============================================================
inline float calculate_distance(const Vector3& a, const Vector3& b) noexcept {
    float dx = a.x - b.x;
    float dy = a.y - b.y;
    float dz = a.z - b.z;
    return sqrtf(dx * dx + dy * dy + dz * dz);
}
