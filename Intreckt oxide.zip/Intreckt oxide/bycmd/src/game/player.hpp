#pragma once

#include "game.hpp"
#include "math.hpp"
#include "call.hpp"
#include "../other/vector3.h"
#include "../other/string.h"
#include "../other/logger.hpp"
#include "../protect/oxorany.hpp"
#include "../ui/theme/theme.hpp"
#include <cstring>
#include <string>
#include <cmath>

namespace player {
    // Здоровье игрока лежит внутри vitals (PlayerManager.vitals @ 0xc8):
    //   EntityVitals.m_MaxHealth @ 0x88  (это МАКСИМУМ, стабильное число)
    //   текущее здоровье — через synced-Stat (auto-property, оффсета в дампе нет).
    // Оффсет для ЧТЕНИЯ текущего HP подбирается по логу (см. dump_vitals).
    // PLAYER_HEALTH_OFFSET = 0x88 показывает макс. здоровье как запасной вариант.
    static const uint64_t VITALS_OFFSET = 0xc8;
    static const uint64_t HEALTH_OFFSET = 0x88; // m_MaxHealth (запасной)

    // Мировая позиция: в дампе player[0] реальная Vector3 найдена по оффсету 0x100
    //   (-11723.25, 0, -11723.0625 — настоящие координаты, а не указатели).
    // Также пробуем lastTickPosition@0x1d0, lastSavedPosition@0x1dc, lastDeathPosition@0x1e8.
    // Берём первую конечную ненулевую. Реальный оффсет подбирается по логу (position_dbg).
    inline Vector3 position(uint64_t p) noexcept {
        static const uint64_t cands[] = {0x100, 0x1d0, 0x1dc, 0x1e8};
        for (uint64_t c : cands) {
            Vector3 v = rpm<Vector3>(p + c);
            if (std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z) &&
                !(v.x == 0.f && v.y == 0.f && v.z == 0.f))
                return v;
        }
        return rpm<Vector3>(p + cands[0]);
    }

    inline void position_dbg(uint64_t p) noexcept {
        static const uint64_t cands[] = {0x100, 0x1d0, 0x1dc, 0x1e8};
        char buf[256];
        int n = 0;
        for (uint64_t c : cands) {
            Vector3 v = rpm<Vector3>(p + c);
            n += snprintf(buf + n, sizeof(buf) - n, " +0x%03llx=(%f,%f,%f)",
                (unsigned long long)c, v.x, v.y, v.z);
        }
        g_log.write("poscand p=%llx%s\n", (unsigned long long)p, buf);
    }

    // Никнейм: PlayerManager.nicklabel (wY) @ 0x130 -> private string KYe @ 0xa8
    inline read_string name(uint64_t p) noexcept {
        uint64_t nick = rpm<uint64_t>(p + oxorany(0x130));
        if (!nick) return {};
        uint64_t strPtr = rpm<uint64_t>(nick + oxorany(0xa8));
        if (!strPtr) return {};
        return rpm<read_string>(strPtr);
    }

    // Дамп окна float внутри vitals, чтобы подобрать реальный оффсет текущего HP.
    // Тот float, что уменьшается при получении урона и лежит в диапазоне 0..max — и есть HP.
    inline void dump_vitals(uint64_t p) noexcept {
        uint64_t vitals = rpm<uint64_t>(p + VITALS_OFFSET);
        if (!vitals) return;
        // читаем сам объект vitals + предполагаемый Stat-объект внутри
        float w[64];
        for (int pass = 0; pass < 2; pass++) {
            uint64_t base = (pass == 0) ? vitals : vitals; // оффсеты внутри vitals
            if (!mem_read(base, w, sizeof(w))) continue;
            g_log.write("vitals dump p=%llx vitals=%llx:",
                (unsigned long long)p, (unsigned long long)vitals);
            for (int k = 0; k < 64; k += 4) {
                g_log.write("  +0x%02X: %f %f %f %f",
                    k * 4, w[k], w[k + 1], w[k + 2], w[k + 3]);
            }
        }
    }

    // Здоровье: читаем float внутри vitals.
    inline int health(uint64_t p) noexcept {
        uint64_t vitals = rpm<uint64_t>(p + VITALS_OFFSET);
        if (!vitals) return 0;
        float h = rpm<float>(vitals + HEALTH_OFFSET);
        if (std::isnan(h) || h < 0.f || h > 1000.f) return 0;
        return (int)h;
    }

    // Камера через вызов Camera.get_main() (без сканирования).
    inline uint64_t get_camera() noexcept {
        return remote::get_main_camera();
    }

    // Запасной путь к камере БЕЗ ptrace: fpManager игрока -> m_WorldCamera.
    // (Оффсеты из дампа: PlayerManager.fpManager @ 0x90, FPManager.m_WorldCamera @ 0x20,
    //  но перебираем несколько на случай расхождения версий.)
    inline uint64_t get_camera_from_fpmanager(uint64_t player) noexcept {
        uint64_t fpm = rpm<uint64_t>(player + 0x90);
        if (!fpm) return 0;
        static const uint64_t offs[] = {0x20, 0x18, 0x28, 0x10, 0x30, 0x38, 0x40};
        for (uint64_t o : offs) {
            uint64_t cam = rpm<uint64_t>(fpm + o);
            if (!cam) continue;
            uint64_t native = rpm<uint64_t>(cam + 0x10); // m_CachedPtr
            if (native && (native & 7) == 0 && native > 0x1000 && native < 0x800000000000ULL)
                return cam;
        }
        return 0;
    }

    // Проверка, что 16 float похожи на перспективную проекционную матрицу.
    // Unity Matrix4x4 в памяти ROW-MAJOR: m00,m01,m02,m03, m10,m11,m12,m13, m20,m21,m22,m23, m30,m31,m32,m33.
    //   m33==0 (idx15), m32==-1 (idx14), m23!=0 (idx11), m22<0 (idx10), m00>0 (idx0), m11>0 (idx5).
    static inline bool is_proj_matrix(const float m[16]) {
        auto fin = [](float v){ return std::isfinite(v); };
        if (!fin(m[0])||!fin(m[5])||!fin(m[10])||!fin(m[11])||!fin(m[14])||!fin(m[15])) return false;
        if (m[15] < -0.001f || m[15] > 0.001f) return false;   // m33 == 0
        if (m[14] < -1.001f || m[14] > -0.999f) return false;  // m32 == -1
        if (m[0] <= 0.f || m[5] <= 0.f) return false;          // положительный масштаб
        if (m[11] == 0.f) return false;                        // m23 != 0
        if (m[10] >= 0.f) return false;                        // m22 отрицательный (RH)
        if (m[1]||m[2]||m[3]||m[4]||m[6]||m[7]||m[8]||m[9]||m[12]||m[13]) return false;
        return true;
    }

    // Матрица view-projection — читаем строго по оффсетам из NATIVE Unity.Camera
    // (CAMERA_VIEW_MATRIX / CAMERA_PROJECTION_MATRIX). Запасной путь, когда
    // ptrace-W2S недоступен. Без сканирования памяти.
    inline bool get_camera_matrix(uint64_t cam, matrix& out) noexcept {
        if (!cam) return false;
        uint64_t native = rpm<uint64_t>(cam + game_offsets::MANAGED_CACHED_PTR);
        if (!native) return false;
        matrix view{}, proj{};
        if (!mem_read(native + game_offsets::CAMERA_VIEW_MATRIX, &view, sizeof(matrix))) return false;
        if (!mem_read(native + game_offsets::CAMERA_PROJECTION_MATRIX, &proj, sizeof(matrix))) return false;
        float* v = reinterpret_cast<float*>(&view);
        float* p = reinterpret_cast<float*>(&proj);
        if (v[0] == 0.f || p[0] == 0.f || !std::isfinite(v[0]) || !std::isfinite(p[0])) return false;
        out = multiply_matrix(proj, view);
        return true;
    }

    inline matrix view_matrix(uint64_t cam) noexcept {
        matrix m{};
        get_camera_matrix(cam, m);
        return m;
    }

    // Проекция через WorldToScreenPoint (использует данный оффсет пользователя).
    // Возвращает экранные координаты (origin top-left): x = x, y = screenH - y.
    inline bool project_w2s(uint64_t cam, const Vector3& world,
                            float& sx, float& sy, float& dist) noexcept {
        if (!cam) return false;
        float ox = 0, oy = 0, oz = 0;
        uint64_t f = proc::lib + game_offsets::CAMERA_WORLD_TO_SCREEN_RVA;
        if (!remote::call_w2s(f, cam, world.x, world.y, world.z, ox, oy, oz))
            return false;
        sx = ox;
        sy = g_sh - oy;   // Unity: y отсчитывается снизу вверх
        dist = oz;        // oz > 0 — точка перед камерой
        return true;
    }
}
