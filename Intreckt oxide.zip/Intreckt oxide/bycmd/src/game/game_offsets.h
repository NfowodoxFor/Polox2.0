#pragma once

#include <cstdint>

// ============================================================
//  Oxide Survival Island — IL2CPP offsets (from dump.cs, подтверждённые)
//  Module: libil2cpp.so. Все *_RVA — это адреса в образе (lib + RVA).
// ============================================================

namespace game_offsets {

// ---- Player list ----------------------------------------------------------
// PlayerManager : NetworkBehaviour (namespace Oxide)
//   clientPlayerList (List<PlayerManager>) — статик-поле @ +0x10 внутри static_fields
inline constexpr std::uint64_t PLAYER_MANAGER_NAMESPACE   = 0; // не используется (find_class убран)
inline constexpr std::uint64_t PLAYER_CLIENT_LIST_OFFSET   = 0x10; // clientPlayerList в static_fields

// ---- Player object fields ------------------------------------------------
// public float health; // 0x380  (класс с OnStartLocalPlayer)
inline constexpr std::uint64_t PLAYER_HEALTH_OFFSET = 0x380;
// PlayerManager.lastTickPosition (Vector3) @ 0x1d0
inline constexpr std::uint64_t PLAYER_POSITION_OFFSET = 0x1d0;

// ---- Camera (UnityEngine.Camera) -----------------------------------------
// Camera.get_main() — статик-метод, возвращает main Camera* (managed)
inline constexpr std::uint64_t CAMERA_GET_MAIN_RVA     = 0xBF537B2;
// Camera.get_current() — статик-метод, возвращает текущую Camera*
inline constexpr std::uint64_t CAMERA_GET_CURRENT_RVA  = 0xBF5382B;
// Camera.WorldToScreenPoint(Vector3) — инстанс-метод, проецирует мир->экран
inline constexpr std::uint64_t CAMERA_WORLD_TO_SCREEN_RVA = 0xBF52D41;
// set_fieldOfView — используется как "хост" для шеллкода вызова (не вызывается в игре)
inline constexpr std::uint64_t CALL_HOST_RVA = 0xBF4D503;

// Managed UnityEngine.Object.m_CachedPtr (native object) @ 0x10
inline constexpr std::uint64_t MANAGED_CACHED_PTR = 0x10;

// Матрицы во VIEW/NATIVE-камере (row-major), если берём их напрямую:
inline constexpr std::uint64_t CAMERA_VIEW_MATRIX       = 0x10;
inline constexpr std::uint64_t CAMERA_PROJECTION_MATRIX = 0x50;

inline constexpr bool MATRICES_ARE_COLUMN_MAJOR = false; // row-major
inline constexpr bool PROJECTION_TIMES_VIEW     = true;  // clip = P * V
inline constexpr float PLAYER_HEIGHT            = 1.8f;

} // namespace game_offsets
