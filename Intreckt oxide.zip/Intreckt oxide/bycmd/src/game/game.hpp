#pragma once

#include "../other/memory.hpp"
#include "../other/logger.hpp"
#include "../protect/oxorany.hpp"
#include "game_offsets.h"
#include <stdint.h>
#include <vector>
#include <cstring>
#include <cstdlib>

struct matrix {
    float m11, m12, m13, m14;
    float m21, m22, m23, m24;
    float m31, m32, m33, m34;
    float m41, m42, m43, m44;
};

namespace offsets {
    // Адрес класса Oxide.PlayerManager заполняется в рантайме через find_class().
    inline uint64_t player_manager = 0;
}

// ============================================================
//  Поиск Il2CppClass по имени/namespace (сканируем libil2cpp.so)
//  Il2CppClass: name @ +0x10, namespaze @ +0x18, static_fields — оффсет
//  версии-зависимый, поэтому детектим его отдельно (см. ниже).
// ============================================================

inline int il2cpp_hexd(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

inline bool module_bounds(uint64_t& start, uint64_t& end) {
    if (proc::pid <= 0) return false;

    char mp[64]; int ps = 0;
    const char* a = oxorany("/proc/"); while (*a) mp[ps++] = *a++;
    int pid = proc::pid; char pds[16]; int pl = 0; int tm = pid;
    while (tm > 0) { pds[pl++] = '0' + (tm % 10); tm /= 10; }
    for (int i = pl - 1; i >= 0; i--) mp[ps++] = pds[i];
    const char* b = oxorany("/maps"); while (*b) mp[ps++] = *b++;
    mp[ps] = '\0';

    int mfd = sys::openat(AT_FDCWD, mp, O_RDONLY);
    if (mfd < 0) return false;

    start = 0; end = 0; bool found = false;
    char buf[8192]; long tr = 0;

    while (true) {
        long nr = sys::read(mfd, buf + tr, sizeof(buf) - tr - 1);
        if (nr <= 0) break;
        tr += nr; buf[tr] = '\0';

        char* ls = buf;
        while (true) {
            char* le = ls;
            while (*le && *le != '\n') le++;
            if (*le == '\0') break;
            *le = '\0';

            uint64_t st = 0, en = 0; char* pt = ls; int hv;
            while ((hv = il2cpp_hexd(*pt)) >= 0) { st = st * 16 + hv; pt++; }
            if (*pt != '-') goto nl;
            pt++;
            while ((hv = il2cpp_hexd(*pt)) >= 0) { en = en * 16 + hv; pt++; }
            while (*pt == ' ') pt++;
            if (pt[0] == 'r' && pt[3] == 'p') {
                while (*pt == ' ') pt++;
                while (*pt && *pt != '/') pt++;
                if (*pt == '/') {
                    const char* lu = oxorany("libil2cpp.so");
                    int ll = 0; while (lu[ll]) ll++;
                    char* ph = pt;
                    while (*ph) {
                        bool mt = true;
                        for (int i = 0; i < ll && ph[i]; i++) if (ph[i] != lu[i]) { mt = false; break; }
                        if (mt) {
                            if (start == 0 || st < start) start = st;
                            if (en > end) end = en;
                            found = true;
                            break;
                        }
                        ph++;
                    }
                }
            }
        nl:
            ls = le + 1;
        }

        if (ls < buf + tr) { int rm = (int)((buf + tr) - ls); for (int i = 0; i < rm; i++) buf[i] = ls[i]; tr = rm; }
        else tr = 0;
    }

    sys::close(mfd);
    return found && end > start;
}

struct map_region { uint64_t s, e; bool r; };

inline bool collect_regions(std::vector<map_region>& out) {
    if (proc::pid <= 0) return false;

    char mp[64]; int ps = 0;
    const char* a = oxorany("/proc/"); while (*a) mp[ps++] = *a++;
    int tm = proc::pid; char pds[16]; int pl = 0;
    while (tm > 0) { pds[pl++] = '0' + (tm % 10); tm /= 10; }
    for (int i = pl - 1; i >= 0; i--) mp[ps++] = pds[i];
    const char* b = oxorany("/maps"); while (*b) mp[ps++] = *b++;
    mp[ps] = '\0';

    int mfd = sys::openat(AT_FDCWD, mp, O_RDONLY);
    if (mfd < 0) return false;

    char buf[8192]; long tr = 0;
    while (true) {
        long nr = sys::read(mfd, buf + tr, sizeof(buf) - tr - 1);
        if (nr <= 0) break;
        tr += nr; buf[tr] = '\0';
        char* ls = buf;
        while (*ls) {
            char* le = ls; while (*le && *le != '\n') le++;
            if (*le == '\0') break;
            *le = '\0';
            uint64_t st = 0, en = 0; char* pt = ls; int hv;
            while ((hv = il2cpp_hexd(*pt)) >= 0) { st = st * 16 + hv; pt++; }
            if (*pt == '-') {
                pt++;
                while ((hv = il2cpp_hexd(*pt)) >= 0) { en = en * 16 + hv; pt++; }
                while (*pt == ' ') pt++;
                bool readable = (pt[0] == 'r');
                out.push_back({ st, en, readable });
            }
            *le = '\n';
            ls = le + 1;
        }
        if (ls < buf + tr) { int rm = (int)((buf + tr) - ls); for (int i = 0; i < rm; i++) buf[i] = ls[i]; tr = rm; }
        else tr = 0;
    }
    sys::close(mfd);
    return !out.empty();
}

// global-metadata.dat начинается с сигнатуры 0xFAB11BAF
inline bool metadata_bounds(uint64_t& mb, uint64_t& me) {
    std::vector<map_region> regs;
    if (!collect_regions(regs)) return false;
    for (auto& r : regs) {
        if (!r.r) continue;
        uint32_t sig = 0;
        if (!mem_read(r.s, &sig, 4)) continue;
        if (sig == 0xFAB11BAF) { mb = r.s; me = r.e; return true; }
    }
    return false;
}

inline uint64_t find_class(const char* name, const char* nsz) {
    static uint64_t cached = 0;
    static bool found = false;
    if (found) return cached;
    if (proc::lib == 0) return 0;

    uint64_t mb, me;
    if (!metadata_bounds(mb, me)) {
        static int t = 0;
        if ((t++ & 127) == 0) g_log.write("find_class: metadata.dat not ready yet\n");
        return 0;
    }

    static int tick = 0;
    if ((tick++ % 120) != 0) return 0; // throttle: сканируем не каждый кадр

    g_log.write("find_class: scanning, metadata=%llx..%llx name=%s ns=%s\n",
        (unsigned long long)mb, (unsigned long long)me, name, nsz);

    std::vector<map_region> regs;
    if (!collect_regions(regs)) return 0;

    size_t nlen = strlen(name), nslen = strlen(nsz);
    const size_t CH = 4 * 1024 * 1024;
    std::vector<char> buf(CH + 8);

    int scanned = 0;
    for (auto& r : regs) {
        uint64_t span = r.e - r.s;
        if (!r.r || span < 0x20 || span > 2ULL * 1024 * 1024 * 1024) continue;

        for (uint64_t pos = r.s; pos + 8 <= r.e; pos += CH) {
            uint64_t want = (pos + CH + 8 <= r.e) ? (CH + 8) : (r.e - pos);
            if (want < 8) break;
            if (!mem_read(pos, buf.data(), want)) continue;

            size_t lim = (want >= CH) ? CH : want;
            for (size_t o = 0; o + 8 <= lim; o += 8) {
                uint64_t q;
                memcpy(&q, buf.data() + o, 8);
                if (q < mb || q >= me) continue;   // name должен указывать в metadata

                uint64_t qaddr = pos + o;
                uint64_t candidate = qaddr - 0x10;  // Il2CppClass.name @ +0x10

                char nb[64];
                if (!mem_read(q, nb, sizeof(nb))) continue;
                nb[63] = '\0';
                if (strcmp(nb, name) != 0) continue;

                uint64_t nsp = rpm<uint64_t>(candidate + 0x18);
                if (nsp < mb || nsp >= me) continue;
                char nsb[32];
                if (!mem_read(nsp, nsb, sizeof(nsb))) continue;
                nsb[31] = '\0';
                if (strncmp(nsb, nsz, nslen) != 0) continue;

                found = true; cached = candidate;
                g_log.write("find_class: FOUND %s class=%llx\n",
                    name, (unsigned long long)candidate);
                return cached;
            }
        }
        scanned++;
    }
    g_log.write("find_class: %s NOT FOUND (scanned %d regions)\n", name, scanned);
    return 0;
}

inline uint64_t get_player_manager_class() {
    return find_class("PlayerManager", "Oxide");
}

// Детект static_fields внутри Il2CppClass (оффсет версии-зависим).
// Валидируем: activePlayerList @ +0x8 и clientPlayerList @ +0x10 должны быть
// валидными указателями (на x64 адреса могут быть > 0x8000000000).
inline uint64_t get_player_manager_static_fields() {
    static uint64_t cached_sf = 0;
    static bool valid = false;
    if (valid) return cached_sf;
    uint64_t cls = get_player_manager_class();
    if (!cls) return 0;
    static const uint64_t offs[] = {
        0xB8, 0xC0, 0xC8, 0xD0, 0xD8, 0xE0, 0xE8, 0xF0, 0xF8,
        0x100, 0x108, 0x110, 0x118, 0x120, 0x128, 0x130, 0x140, 0x150, 0x160,
        0x90, 0x98, 0xA0, 0xA8, 0x58, 0x50
    };
    const uint64_t LO = 0x1000ULL;
    const uint64_t HI = 0x800000000000ULL; // 2^47 — потолок user-space на Android x64
    for (uint64_t off : offs) {
        uint64_t sf = rpm<uint64_t>(cls + off);
        if (!sf || sf < LO || sf >= HI) continue;
        uint64_t apl = rpm<uint64_t>(sf + 0x8);  // activePlayerList
        uint64_t pl  = rpm<uint64_t>(sf + game_offsets::PLAYER_CLIENT_LIST_OFFSET); // clientPlayerList @ +0x10
        bool ok_apl = (apl && (apl & 7) == 0 && apl >= LO && apl < HI);
        bool ok_pl  = (pl  && (pl  & 7) == 0 && pl  >= LO && pl  < HI);
        if (ok_apl && ok_pl) {
            cached_sf = sf; valid = true;
            g_log.write("static_fields: cls=%llx off=%llx sf=%llx activePL=%llx clientPL=%llx\n",
                (unsigned long long)cls, (unsigned long long)off,
                (unsigned long long)sf, (unsigned long long)apl, (unsigned long long)pl);
            return sf;
        }
    }
    g_log.write("static_fields: NOT FOUND for cls=%llx\n", (unsigned long long)cls);
    return 0;
}

inline uint64_t get_player_manager() {
    return get_player_manager_class();
}
